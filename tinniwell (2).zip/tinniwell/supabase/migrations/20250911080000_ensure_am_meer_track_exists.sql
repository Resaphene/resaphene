-- ============================================================================
-- MIGRATION: Ensure "Am Meer" Track Exists and is Accessible
-- Date: 2025-09-11 08:00:00
-- Issue: User reports "Am Meer" track is not available despite upload
-- ============================================================================

-- ============================================================================
-- 1. CHECK AND INSERT MISSING "Am Meer" TRACK
-- ============================================================================

-- Insert "Am Meer" track if it doesn't exist
INSERT INTO public.tracks (
  id,
  title,
  storage_path,
  duration_sec,
  mime_type,
  file_size_bytes,
  created_at,
  updated_at
)
SELECT 
  gen_random_uuid(),
  'Am Meer',
  'therapy-audio/Am Meer.mp3',
  280,  -- Approximate duration in seconds
  'audio/mpeg',
  0,    -- Will be updated when file is properly uploaded
  CURRENT_TIMESTAMP,
  CURRENT_TIMESTAMP
WHERE NOT EXISTS (
  SELECT 1 FROM public.tracks WHERE title = 'Am Meer'
);

-- ============================================================================
-- 2. ENSURE ALL THREE TRACKS ARE PRESENT
-- ============================================================================

-- Verify all expected tracks exist
DO $$
DECLARE
    track_count INTEGER;
    missing_tracks TEXT[];
BEGIN
    -- Count existing tracks
    SELECT COUNT(*) INTO track_count FROM public.tracks 
    WHERE title IN ('Am Meer', 'Visionen', 'Indian Summer');
    
    -- Find missing tracks
    SELECT array_agg(expected_track) INTO missing_tracks
    FROM (
        SELECT unnest(ARRAY['Am Meer', 'Visionen', 'Indian Summer']) AS expected_track
    ) expected
    WHERE expected_track NOT IN (
        SELECT title FROM public.tracks
    );
    
    -- Report status
    IF track_count = 3 THEN
        RAISE NOTICE 'SUCCESS: All 3 therapy audio tracks are now available';
    ELSE
        RAISE NOTICE 'WARNING: Only % of 3 expected tracks found. Missing: %', track_count, array_to_string(missing_tracks, ', ');
    END IF;
END $$;

-- ============================================================================
-- 3. UPDATE ACTIVE TRACK TO FIRST AVAILABLE
-- ============================================================================

-- Set the first available track as active if no active track is set
DO $$
DECLARE
    first_track_id UUID;
    first_track_title TEXT;
    active_setting_exists BOOLEAN;
BEGIN
    -- Check if active_track setting exists
    SELECT EXISTS(
        SELECT 1 FROM public.admin_settings 
        WHERE setting_key = 'active_track'
    ) INTO active_setting_exists;
    
    -- Get first available track
    SELECT id, title INTO first_track_id, first_track_title
    FROM public.tracks 
    ORDER BY created_at ASC 
    LIMIT 1;
    
    -- Set active track if none exists
    IF first_track_id IS NOT NULL THEN
        IF NOT active_setting_exists THEN
            INSERT INTO public.admin_settings (
                setting_key,
                setting_value,
                active_track_id,
                created_at,
                updated_at
            ) VALUES (
                'active_track',
                first_track_title,
                first_track_id,
                CURRENT_TIMESTAMP,
                CURRENT_TIMESTAMP
            );
            
            RAISE NOTICE 'Set active track to: %', first_track_title;
        ELSE
            RAISE NOTICE 'Active track setting already exists';
        END IF;
    END IF;
END $$;

-- ============================================================================
-- 4. VERIFY TRACK ACCESSIBILITY
-- ============================================================================

-- Test track retrieval functions
DO $$
DECLARE
    track_info RECORD;
    available_tracks_count INTEGER;
BEGIN
    -- Test get_active_track_info function
    BEGIN
        SELECT * INTO track_info FROM public.get_active_track_info() LIMIT 1;
        RAISE NOTICE 'Active track accessible: % (Duration: %s)', track_info.title, track_info.duration_sec;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE NOTICE 'WARNING: get_active_track_info failed - %', SQLERRM;
    END;
    
    -- Test get_available_tracks function
    BEGIN
        SELECT COUNT(*) INTO available_tracks_count FROM public.get_available_tracks();
        RAISE NOTICE 'Available tracks count: %', available_tracks_count;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE NOTICE 'WARNING: get_available_tracks failed - %', SQLERRM;
    END;
END $$;

-- ============================================================================
-- 5. FINAL VERIFICATION REPORT
-- ============================================================================

-- Display all tracks for verification
SELECT 
    title,
    storage_path,
    duration_sec,
    created_at,
    CASE 
        WHEN id IN (SELECT active_track_id FROM public.admin_settings WHERE setting_key = 'active_track')
        THEN '✓ ACTIVE'
        ELSE '  Available'
    END as status
FROM public.tracks 
ORDER BY created_at ASC;

-- Success message
SELECT 'MIGRATION COMPLETED: Therapy audio tracks verified and accessible' as result;