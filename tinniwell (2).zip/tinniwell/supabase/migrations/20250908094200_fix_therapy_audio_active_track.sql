-- Location: supabase/migrations/20250908094200_fix_therapy_audio_active_track.sql
-- Schema Analysis: Existing admin_settings and tracks tables
-- Integration Type: Modificative - Update existing admin_settings record
-- Dependencies: public.admin_settings, public.tracks

-- Fix the therapy audio issue by setting an active track
-- The admin_settings table has a record with setting_key = 'active_track' but active_track_id = null
-- This causes the get_active_track_signed_url function to return an error

DO $$
DECLARE
    first_track_id UUID;
    admin_setting_id UUID;
BEGIN
    -- Get the first available track from the tracks table
    SELECT id INTO first_track_id
    FROM public.tracks
    ORDER BY created_at ASC
    LIMIT 1;

    -- Get the admin_settings record for active_track
    SELECT id INTO admin_setting_id
    FROM public.admin_settings
    WHERE setting_key = 'active_track';

    -- Update the admin_settings record to reference the first track
    IF first_track_id IS NOT NULL AND admin_setting_id IS NOT NULL THEN
        UPDATE public.admin_settings
        SET active_track_id = first_track_id,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = admin_setting_id;

        RAISE NOTICE 'Successfully set active track ID: %', first_track_id;
    ELSE
        -- If no tracks exist, create a default message
        IF first_track_id IS NULL THEN
            RAISE NOTICE 'No tracks found in the tracks table. Please upload audio files to therapy-audio storage and add track records.';
        END IF;
        
        IF admin_setting_id IS NULL THEN
            RAISE NOTICE 'No admin_settings record found for active_track. This should exist from previous migrations.';
        END IF;
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Error setting active track: %', SQLERRM;
END $$;

-- Verify the fix by showing the current active track
DO $$
DECLARE
    track_title TEXT;
    track_path TEXT;
BEGIN
    SELECT t.title, t.storage_path 
    INTO track_title, track_path
    FROM public.admin_settings ads
    INNER JOIN public.tracks t ON ads.active_track_id = t.id
    WHERE ads.setting_key = 'active_track'
    AND ads.active_track_id IS NOT NULL;

    IF track_title IS NOT NULL THEN
        RAISE NOTICE 'Active track set successfully: % (Path: %)', track_title, track_path;
    ELSE
        RAISE NOTICE 'Active track could not be set. Check tracks table for available records.';
    END IF;
END $$;