-- Fix active track reference in admin_settings
-- The current active_track_id points to a non-existent track
-- Update it to point to one of the existing tracks

DO $$
DECLARE
    existing_track_id uuid;
BEGIN
    -- Get the first available track ID
    SELECT id INTO existing_track_id 
    FROM public.tracks 
    ORDER BY created_at DESC 
    LIMIT 1;
    
    -- Update the active_track setting if we found a track
    IF existing_track_id IS NOT NULL THEN
        UPDATE public.admin_settings 
        SET 
            active_track_id = existing_track_id,
            setting_value = (SELECT title FROM public.tracks WHERE id = existing_track_id),
            updated_at = CURRENT_TIMESTAMP
        WHERE setting_key = 'active_track';
        
        -- If no active_track setting exists, create it
        IF NOT FOUND THEN
            INSERT INTO public.admin_settings (setting_key, setting_value, active_track_id)
            SELECT 'active_track', title, id
            FROM public.tracks 
            ORDER BY created_at DESC 
            LIMIT 1;
        END IF;
    END IF;
END $$;

-- Verify the fix by checking if active track exists
DO $$
DECLARE
    track_exists boolean;
    track_title text;
BEGIN
    SELECT EXISTS(
        SELECT 1 
        FROM public.admin_settings ads
        INNER JOIN public.tracks t ON ads.active_track_id = t.id
        WHERE ads.setting_key = 'active_track'
    ), t.title
    INTO track_exists, track_title
    FROM public.admin_settings ads
    INNER JOIN public.tracks t ON ads.active_track_id = t.id
    WHERE ads.setting_key = 'active_track'
    LIMIT 1;
    
    IF track_exists THEN
        RAISE NOTICE 'Active track successfully set to: %', track_title;
    ELSE
        RAISE WARNING 'No active track found after fix attempt';
    END IF;
END $$;