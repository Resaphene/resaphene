-- =========================================================
-- Migration: Add Missing "Am Meer" Track to Database
-- Purpose: Add the missing "Am Meer.mp3" track that exists in storage
-- Timestamp: 2025-09-10 10:56:44
-- =========================================================

-- Insert the missing "Am Meer" track
INSERT INTO public.tracks (
    title,
    storage_path,
    duration_sec,
    mime_type,
    file_size_bytes
) VALUES (
    'Am Meer',
    'therapy-audio/Am Meer.mp3',
    280,  -- Approximate duration for therapy track
    'audio/mpeg',
    0  -- Will be updated when file is properly uploaded
)
ON CONFLICT (title) DO NOTHING;  -- Prevent duplicate if track already exists

-- Verify the track was inserted
DO $$
DECLARE
    track_count INTEGER;
BEGIN
    SELECT COUNT(*) INTO track_count FROM public.tracks WHERE title = 'Am Meer';
    
    IF track_count = 0 THEN
        RAISE EXCEPTION 'Failed to insert "Am Meer" track';
    ELSE
        RAISE NOTICE 'Successfully added "Am Meer" track to database';
    END IF;
END $$;