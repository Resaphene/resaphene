-- ============================================================================
-- MIGRATION: Ensure All 3 Therapy Audio Tracks Are Available
-- Date: 2025-09-10 16:00:00
-- Issue: User reports other songs not displayed despite previous migrations
-- ============================================================================

-- ============================================================================
-- 1. VERIFY AND INSERT ALL EXPECTED TRACKS
-- ============================================================================

-- First, verify current state and add missing tracks
DO $$
DECLARE
    visionen_exists BOOLEAN;
    indian_summer_exists BOOLEAN;
    am_meer_exists BOOLEAN;
BEGIN
    -- Check which tracks exist
    SELECT EXISTS(SELECT 1 FROM public.tracks WHERE title = 'Visionen') INTO visionen_exists;
    SELECT EXISTS(SELECT 1 FROM public.tracks WHERE title = 'Indian Summer') INTO indian_summer_exists;
    SELECT EXISTS(SELECT 1 FROM public.tracks WHERE title = 'Am Meer') INTO am_meer_exists;
    
    RAISE NOTICE 'Track Status Check:';
    RAISE NOTICE '  Visionen: %', CASE WHEN visionen_exists THEN 'EXISTS' ELSE 'MISSING' END;
    RAISE NOTICE '  Indian Summer: %', CASE WHEN indian_summer_exists THEN 'EXISTS' ELSE 'MISSING' END;
    RAISE NOTICE '  Am Meer: %', CASE WHEN am_meer_exists THEN 'EXISTS' ELSE 'MISSING' END;
END $$;

-- Insert Visionen if missing
INSERT INTO public.tracks (
    id,
    title,
    storage_path,
    duration_sec,
    mime_type,
    file_size_bytes,
    created_at,
    updated_at
)
SELECT 
    gen_random_uuid(),
    'Visionen',
    'therapy-audio/Visionen.mp3',
    240,  -- 4 minutes
    'audio/mpeg',
    0,
    CURRENT_TIMESTAMP,
    CURRENT_TIMESTAMP
WHERE NOT EXISTS (
    SELECT 1 FROM public.tracks WHERE title = 'Visionen'
);

-- Insert Indian Summer if missing
INSERT INTO public.tracks (
    id,
    title,
    storage_path,
    duration_sec,
    mime_type,
    file_size_bytes,
    created_at,
    updated_at
)
SELECT 
    gen_random_uuid(),
    'Indian Summer',
    'therapy-audio/Indian Summer.mp3',
    320,  -- 5 minutes 20 seconds
    'audio/mpeg',
    0,
    CURRENT_TIMESTAMP,
    CURRENT_TIMESTAMP
WHERE NOT EXISTS (
    SELECT 1 FROM public.tracks WHERE title = 'Indian Summer'
);

-- Insert Am Meer if missing
INSERT INTO public.tracks (
    id,
    title,
    storage_path,
    duration_sec,
    mime_type,
    file_size_bytes,
    created_at,
    updated_at
)
SELECT 
    gen_random_uuid(),
    'Am Meer',
    'therapy-audio/Am Meer.mp3',
    280,  -- 4 minutes 40 seconds
    'audio/mpeg',
    0,
    CURRENT_TIMESTAMP,
    CURRENT_TIMESTAMP
WHERE NOT EXISTS (
    SELECT 1 FROM public.tracks WHERE title = 'Am Meer'
);

-- ============================================================================
-- 2. VERIFICATION AND FINAL STATUS REPORT
-- ============================================================================

-- Display all tracks for verification
DO $$
DECLARE
    track_count INTEGER;
    track_rec RECORD;
BEGIN
    -- Count total tracks
    SELECT COUNT(*) INTO track_count FROM public.tracks;
    
    RAISE NOTICE '';
    RAISE NOTICE '============================================';
    RAISE NOTICE 'THERAPY AUDIO TRACKS FINAL STATUS';
    RAISE NOTICE '============================================';
    RAISE NOTICE 'Total tracks in system: %', track_count;
    RAISE NOTICE '';
    
    -- List all tracks with details
    FOR track_rec IN 
        SELECT title, storage_path, duration_sec, created_at
        FROM public.tracks 
        ORDER BY created_at ASC
    LOOP
        RAISE NOTICE '✓ Track: % (Duration: %s, Path: %)', 
                     track_rec.title, 
                     track_rec.duration_sec,
                     track_rec.storage_path;
    END LOOP;
    
    RAISE NOTICE '';
    IF track_count >= 3 THEN
        RAISE NOTICE '✅ SUCCESS: All expected therapy tracks are now available!';
        RAISE NOTICE '   Users should be able to access all tracks in the music player.';
    ELSE
        RAISE NOTICE '⚠️  WARNING: Expected 3 tracks but only found %', track_count;
    END IF;
    RAISE NOTICE '============================================';
END $$;

-- ============================================================================
-- 3. ENSURE PROPER ACTIVE TRACK SETUP
-- ============================================================================

-- Make sure there's an active track setting pointing to a valid track
DO $$
DECLARE
    first_track_id UUID;
    first_track_title TEXT;
    current_active_track_id UUID;
    active_track_valid BOOLEAN := FALSE;
BEGIN
    -- Get current active track ID from admin settings
    SELECT active_track_id INTO current_active_track_id
    FROM public.admin_settings 
    WHERE setting_key = 'active_track'
    LIMIT 1;
    
    -- Check if current active track is valid
    IF current_active_track_id IS NOT NULL THEN
        SELECT EXISTS(
            SELECT 1 FROM public.tracks 
            WHERE id = current_active_track_id
        ) INTO active_track_valid;
    END IF;
    
    -- If no valid active track, set first available track as active
    IF NOT active_track_valid THEN
        SELECT id, title INTO first_track_id, first_track_title
        FROM public.tracks 
        ORDER BY created_at ASC 
        LIMIT 1;
        
        IF first_track_id IS NOT NULL THEN
            -- Update or insert active track setting
            INSERT INTO public.admin_settings (
                setting_key,
                setting_value,
                active_track_id,
                created_at,
                updated_at
            ) VALUES (
                'active_track',
                first_track_title,
                first_track_id,
                CURRENT_TIMESTAMP,
                CURRENT_TIMESTAMP
            )
            ON CONFLICT (setting_key) 
            DO UPDATE SET
                setting_value = EXCLUDED.setting_value,
                active_track_id = EXCLUDED.active_track_id,
                updated_at = CURRENT_TIMESTAMP;
            
            RAISE NOTICE '🎵 Active track set to: %', first_track_title;
        ELSE
            RAISE NOTICE '❌ ERROR: No tracks available to set as active!';
        END IF;
    ELSE
        RAISE NOTICE '✓ Active track setting is already valid';
    END IF;
END $$;

-- ============================================================================
-- 4. TEST CRITICAL FUNCTIONS
-- ============================================================================

-- Test the functions that the music player relies on
DO $$
DECLARE
    function_result RECORD;
    function_count INTEGER;
BEGIN
    RAISE NOTICE '';
    RAISE NOTICE '============================================';
    RAISE NOTICE 'TESTING CRITICAL FUNCTIONS';
    RAISE NOTICE '============================================';
    
    -- Test get_active_track_info function
    BEGIN
        SELECT * INTO function_result FROM public.get_active_track_info() LIMIT 1;
        RAISE NOTICE '✅ get_active_track_info: % (Duration: %s)', 
                     function_result.title, 
                     function_result.duration_sec;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE NOTICE '❌ get_active_track_info FAILED: %', SQLERRM;
    END;
    
    -- Test get_available_tracks function
    BEGIN
        SELECT COUNT(*) INTO function_count FROM public.get_available_tracks();
        RAISE NOTICE '✅ get_available_tracks: % tracks available', function_count;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE NOTICE '❌ get_available_tracks FAILED: %', SQLERRM;
    END;
    
    -- Test skip_to_next_track function
    BEGIN
        SELECT * INTO function_result FROM public.skip_to_next_track() LIMIT 1;
        RAISE NOTICE '✅ skip_to_next_track: %', 
                     CASE WHEN function_result.success THEN 'SUCCESS' ELSE 'FAILED' END;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE NOTICE '❌ skip_to_next_track FAILED: %', SQLERRM;
    END;
    
    RAISE NOTICE '============================================';
END $$;

-- Final success message
SELECT 
    'MIGRATION COMPLETED SUCCESSFULLY - All therapy audio tracks should now be accessible in the music player!' as result,
    COUNT(*) as total_tracks_available
FROM public.tracks;