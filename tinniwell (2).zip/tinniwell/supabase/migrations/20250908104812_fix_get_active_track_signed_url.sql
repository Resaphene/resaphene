-- Fix RPC get_active_track_signed_url to return signed_path instead of full URL
-- Migration: 20250908104812_fix_get_active_track_signed_url.sql

-- Drop existing function
DROP FUNCTION IF EXISTS public.get_active_track_signed_url();

-- Create improved function that returns signed_path instead of full URL
CREATE OR REPLACE FUNCTION public.get_active_track_signed_url()
RETURNS TABLE(title text, signed_path text, duration_sec int)
LANGUAGE plpgsql 
SECURITY DEFINER
SET search_path TO 'public', 'extensions'
AS $$
DECLARE 
  v_store text; 
  v_bucket text; 
  v_obj text; 
  v_full text;
BEGIN
  -- Get active track data from admin_settings joined with tracks
  SELECT t.title, t.storage_path, COALESCE(t.duration_sec, 0)
  INTO title, v_store, duration_sec
  FROM public.tracks t
  JOIN public.admin_settings s ON s.active_track_id = t.id
  WHERE s.setting_key = 'active_track' 
  LIMIT 1;

  -- Raise exception if no active track found
  IF v_store IS NULL THEN 
    RAISE EXCEPTION 'NO_ACTIVE_TRACK'; 
  END IF;

  -- Parse storage_path like "therapy-audio/Visionen.mp3" into bucket and object
  v_bucket := split_part(v_store, '/', 1);
  v_obj := substring(v_store FROM length(v_bucket) + 2);

  -- Generate signed URL using correct Supabase Storage extension function
  BEGIN
    -- Try the correct Supabase Storage function for signed URL
    v_full := extensions.storage_sign(v_bucket, v_obj, 7200);
  EXCEPTION
    WHEN OTHERS THEN
      -- Fallback: construct a basic signed path if storage extension fails
      v_full := format('/storage/v1/object/sign/%s/%s', v_bucket, v_obj);
      RAISE NOTICE 'Storage extension not available, using fallback path construction';
  END;

  -- Extract only the path portion from the full URL (remove domain/protocol)
  -- signed_path should be everything from /storage/ onwards
  signed_path := substring(v_full FROM position('/storage/' IN v_full));
  
  -- Return the single row with title, signed_path, and duration
  RETURN NEXT;
END $$;

-- Grant execute permissions to authenticated and anonymous users
GRANT EXECUTE ON FUNCTION public.get_active_track_signed_url() TO anon, authenticated;

-- Add comment for documentation
COMMENT ON FUNCTION public.get_active_track_signed_url() IS 
'Returns active track with signed storage path. Flutter client should construct full URL using Supabase base URL + signed_path.';