-- Location: supabase/migrations/20250907160514_add_subscription_trial_system.sql
-- Schema Analysis: TinniWell therapy app with user_profiles, licenses, and medical profile tables
-- Integration Type: Addition - Adding subscription and trial management system
-- Dependencies: Existing user_profiles table

-- Step 1: Create subscription status enum
CREATE TYPE public.subscription_status AS ENUM ('trial', 'active', 'canceled', 'expired', 'past_due');

-- Step 2: Create user_subscriptions table for managing subscriptions and trials
CREATE TABLE public.user_subscriptions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    subscription_status public.subscription_status DEFAULT 'trial'::public.subscription_status,
    trial_started_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    trial_ends_at TIMESTAMPTZ DEFAULT (CURRENT_TIMESTAMP + INTERVAL '28 days'), -- 4 weeks trial
    subscription_started_at TIMESTAMPTZ,
    subscription_ends_at TIMESTAMPTZ,
    last_payment_date TIMESTAMPTZ,
    stripe_customer_id TEXT,
    stripe_subscription_id TEXT,
    plan_id TEXT DEFAULT 'premium',
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Step 3: Create indexes for performance
CREATE INDEX idx_user_subscriptions_user_id ON public.user_subscriptions(user_id);
CREATE INDEX idx_user_subscriptions_status ON public.user_subscriptions(subscription_status);
CREATE INDEX idx_user_subscriptions_trial_ends ON public.user_subscriptions(trial_ends_at);

-- Step 4: Create function to check trial status
CREATE OR REPLACE FUNCTION public.check_trial_status(user_uuid UUID)
RETURNS TABLE(
    status TEXT,
    trial_remaining_days INTEGER,
    is_expired BOOLEAN,
    can_access_premium BOOLEAN
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
AS $func$
DECLARE
    sub_record public.user_subscriptions%ROWTYPE;
    days_remaining INTEGER;
BEGIN
    -- Get subscription record for user
    SELECT * INTO sub_record
    FROM public.user_subscriptions us
    WHERE us.user_id = user_uuid
    ORDER BY us.created_at DESC
    LIMIT 1;

    -- If no subscription record exists, user has no access
    IF sub_record IS NULL THEN
        RETURN QUERY SELECT 
            'no_subscription'::TEXT,
            0::INTEGER,
            true::BOOLEAN,
            false::BOOLEAN;
        RETURN;
    END IF;

    -- Calculate remaining trial days
    days_remaining := EXTRACT(DAY FROM (sub_record.trial_ends_at - CURRENT_TIMESTAMP))::INTEGER;
    
    -- Handle different subscription statuses
    CASE sub_record.subscription_status
        WHEN 'trial' THEN
            IF CURRENT_TIMESTAMP > sub_record.trial_ends_at THEN
                RETURN QUERY SELECT 
                    'trial_expired'::TEXT,
                    0::INTEGER,
                    true::BOOLEAN,
                    false::BOOLEAN;
            ELSE
                RETURN QUERY SELECT 
                    'trial'::TEXT,
                    GREATEST(days_remaining, 0)::INTEGER,
                    false::BOOLEAN,
                    true::BOOLEAN;
            END IF;
        
        WHEN 'active' THEN
            RETURN QUERY SELECT 
                'active'::TEXT,
                0::INTEGER,
                false::BOOLEAN,
                true::BOOLEAN;
        
        WHEN 'expired', 'canceled' THEN
            RETURN QUERY SELECT 
                sub_record.subscription_status::TEXT,
                0::INTEGER,
                true::BOOLEAN,
                false::BOOLEAN;
        
        ELSE
            RETURN QUERY SELECT 
                'unknown'::TEXT,
                0::INTEGER,
                true::BOOLEAN,
                false::BOOLEAN;
    END CASE;
END;
$func$;

-- Step 5: Create function to activate trial for new users
CREATE OR REPLACE FUNCTION public.activate_trial_for_user(user_uuid UUID)
RETURNS public.user_subscriptions
LANGUAGE plpgsql
SECURITY DEFINER
AS $func$
DECLARE
    new_subscription public.user_subscriptions%ROWTYPE;
BEGIN
    -- Check if user already has a subscription
    SELECT * INTO new_subscription
    FROM public.user_subscriptions
    WHERE user_id = user_uuid
    LIMIT 1;
    
    -- If subscription exists, return it
    IF FOUND THEN
        RETURN new_subscription;
    END IF;
    
    -- Create new trial subscription
    INSERT INTO public.user_subscriptions (
        user_id,
        subscription_status,
        trial_started_at,
        trial_ends_at
    ) VALUES (
        user_uuid,
        'trial'::public.subscription_status,
        CURRENT_TIMESTAMP,
        CURRENT_TIMESTAMP + INTERVAL '28 days'
    ) RETURNING * INTO new_subscription;
    
    RETURN new_subscription;
END;
$func$;

-- Step 6: Create function to upgrade to premium
CREATE OR REPLACE FUNCTION public.upgrade_to_premium(
    user_uuid UUID,
    stripe_customer_id_param TEXT DEFAULT NULL,
    stripe_subscription_id_param TEXT DEFAULT NULL
)
RETURNS public.user_subscriptions
LANGUAGE plpgsql
SECURITY DEFINER
AS $func$
DECLARE
    updated_subscription public.user_subscriptions%ROWTYPE;
BEGIN
    -- Update existing subscription to active
    UPDATE public.user_subscriptions
    SET 
        subscription_status = 'active'::public.subscription_status,
        subscription_started_at = CURRENT_TIMESTAMP,
        subscription_ends_at = CURRENT_TIMESTAMP + INTERVAL '1 month',
        stripe_customer_id = COALESCE(stripe_customer_id_param, stripe_customer_id),
        stripe_subscription_id = COALESCE(stripe_subscription_id_param, stripe_subscription_id),
        last_payment_date = CURRENT_TIMESTAMP,
        updated_at = CURRENT_TIMESTAMP
    WHERE user_id = user_uuid
    RETURNING * INTO updated_subscription;
    
    -- If no existing subscription, create one
    IF NOT FOUND THEN
        INSERT INTO public.user_subscriptions (
            user_id,
            subscription_status,
            subscription_started_at,
            subscription_ends_at,
            stripe_customer_id,
            stripe_subscription_id,
            last_payment_date
        ) VALUES (
            user_uuid,
            'active'::public.subscription_status,
            CURRENT_TIMESTAMP,
            CURRENT_TIMESTAMP + INTERVAL '1 month',
            stripe_customer_id_param,
            stripe_subscription_id_param,
            CURRENT_TIMESTAMP
        ) RETURNING * INTO updated_subscription;
    END IF;
    
    RETURN updated_subscription;
END;
$func$;

-- Step 7: Create trigger to automatically create trial for new users
CREATE OR REPLACE FUNCTION public.handle_new_user_trial()
RETURNS TRIGGER
SECURITY DEFINER
LANGUAGE plpgsql
AS $trigger$
BEGIN
    -- Create trial subscription for new user
    PERFORM public.activate_trial_for_user(NEW.id);
    RETURN NEW;
END;
$trigger$;

-- Create trigger that fires after user profile creation
CREATE TRIGGER on_user_profile_trial_creation
    AFTER INSERT ON public.user_profiles
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_new_user_trial();

-- Step 8: Enable RLS on user_subscriptions table
ALTER TABLE public.user_subscriptions ENABLE ROW LEVEL SECURITY;

-- Step 9: Create RLS policies using Pattern 2 (Simple User Ownership)
CREATE POLICY "users_manage_own_user_subscriptions"
ON public.user_subscriptions
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- Allow admin access using Pattern 6 Option A (auth metadata)
CREATE OR REPLACE FUNCTION public.is_admin_from_auth()
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $admin_func$
SELECT EXISTS (
    SELECT 1 FROM auth.users au
    WHERE au.id = auth.uid() 
    AND (au.raw_user_meta_data->>'role' = 'admin' 
         OR au.raw_app_meta_data->>'role' = 'admin')
)
$admin_func$;

CREATE POLICY "admin_full_access_user_subscriptions"
ON public.user_subscriptions
FOR ALL
TO authenticated
USING (public.is_admin_from_auth())
WITH CHECK (public.is_admin_from_auth());

-- Step 10: Create updated_at trigger for user_subscriptions
CREATE TRIGGER update_user_subscriptions_updated_at
    BEFORE UPDATE ON public.user_subscriptions
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at();

-- Step 11: Mock data for existing users (create trial subscriptions)
DO $$
DECLARE
    existing_user_id UUID;
BEGIN
    -- Create trial subscriptions for existing users
    FOR existing_user_id IN 
        SELECT id FROM public.user_profiles 
        WHERE NOT EXISTS (
            SELECT 1 FROM public.user_subscriptions 
            WHERE user_id = public.user_profiles.id
        )
    LOOP
        PERFORM public.activate_trial_for_user(existing_user_id);
    END LOOP;
    
    RAISE NOTICE 'Trial subscriptions created for existing users';
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Error creating trial subscriptions: %', SQLERRM;
END $$;