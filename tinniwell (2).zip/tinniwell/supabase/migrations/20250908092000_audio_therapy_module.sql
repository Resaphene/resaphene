-- Location: supabase/migrations/20250908092000_audio_therapy_module.sql
-- Schema Analysis: TinniWell therapy app with existing user_profiles and therapy tables
-- Integration Type: NEW_MODULE - Audio Therapy Module
-- Dependencies: user_profiles (existing)

-- Step 1: Create therapy-audio storage bucket (private for security)
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
    'therapy-audio',
    'therapy-audio', 
    false, -- Private bucket as per user requirements
    52428800, -- 50MB limit for audio files
    ARRAY['audio/mpeg', 'audio/mp3', 'audio/wav', 'audio/m4a', 'audio/aac', 'audio/ogg']
);

-- Step 2: Create tracks table for audio file management
CREATE TABLE public.tracks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    storage_path TEXT NOT NULL,
    duration_sec INTEGER NOT NULL,
    file_size_bytes INTEGER DEFAULT 0,
    mime_type TEXT DEFAULT 'audio/mpeg',
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Step 3: Create admin_settings table for active track management  
CREATE TABLE public.admin_settings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    setting_key TEXT NOT NULL UNIQUE,
    setting_value TEXT,
    active_track_id UUID REFERENCES public.tracks(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Step 4: Create indexes
CREATE INDEX idx_tracks_title ON public.tracks(title);
CREATE INDEX idx_tracks_duration ON public.tracks(duration_sec);
CREATE INDEX idx_admin_settings_key ON public.admin_settings(setting_key);
CREATE INDEX idx_admin_settings_active_track ON public.admin_settings(active_track_id);

-- Step 5: Enable RLS on tables
ALTER TABLE public.tracks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_settings ENABLE ROW LEVEL SECURITY;

-- Step 6: Create RLS policies for storage bucket
-- Only authenticated users can view files (needed for signed URLs)
CREATE POLICY "authenticated_users_view_therapy_audio"
ON storage.objects
FOR SELECT
TO authenticated
USING (bucket_id = 'therapy-audio');

-- Only admins can upload/manage audio files
CREATE POLICY "admins_manage_therapy_audio"
ON storage.objects
FOR ALL
TO authenticated
USING (
    bucket_id = 'therapy-audio'
    AND EXISTS (
        SELECT 1 FROM auth.users au
        WHERE au.id = auth.uid()
        AND (au.raw_user_meta_data->>'role' = 'admin' 
             OR au.raw_app_meta_data->>'role' = 'admin')
    )
)
WITH CHECK (
    bucket_id = 'therapy-audio'
    AND EXISTS (
        SELECT 1 FROM auth.users au  
        WHERE au.id = auth.uid()
        AND (au.raw_user_meta_data->>'role' = 'admin'
             OR au.raw_app_meta_data->>'role' = 'admin')
    )
);

-- Step 7: RLS policies for tracks table
-- Public read access for tracks metadata (users need to see track info)
CREATE POLICY "users_can_view_tracks"
ON public.tracks
FOR SELECT
TO authenticated
USING (true);

-- Only admins can modify tracks
CREATE POLICY "admins_manage_tracks"
ON public.tracks
FOR ALL
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM auth.users au
        WHERE au.id = auth.uid()
        AND (au.raw_user_meta_data->>'role' = 'admin'
             OR au.raw_app_meta_data->>'role' = 'admin')
    )
)
WITH CHECK (
    EXISTS (
        SELECT 1 FROM auth.users au
        WHERE au.id = auth.uid()
        AND (au.raw_user_meta_data->>'role' = 'admin'
             OR au.raw_app_meta_data->>'role' = 'admin')
    )
);

-- Step 8: RLS policies for admin_settings table  
-- Users can read admin settings (needed to get active track)
CREATE POLICY "users_can_read_admin_settings"
ON public.admin_settings
FOR SELECT
TO authenticated
USING (true);

-- Only admins can modify admin settings
CREATE POLICY "admins_manage_admin_settings"
ON public.admin_settings
FOR ALL
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM auth.users au
        WHERE au.id = auth.uid()
        AND (au.raw_user_meta_data->>'role' = 'admin'
             OR au.raw_app_meta_data->>'role' = 'admin')
    )
)
WITH CHECK (
    EXISTS (
        SELECT 1 FROM auth.users au
        WHERE au.id = auth.uid()
        AND (au.raw_user_meta_data->>'role' = 'admin'
             OR au.raw_app_meta_data->>'role' = 'admin')
    )
);

-- Step 9: Create RPC function to get active track with signed URL
CREATE OR REPLACE FUNCTION public.get_active_track_signed_url()
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $function$
DECLARE
    active_track_record RECORD;
    signed_url_response JSON;
    result JSON;
BEGIN
    -- Get the active track from admin_settings
    SELECT t.id, t.title, t.storage_path, t.duration_sec, t.mime_type
    INTO active_track_record
    FROM public.admin_settings ads
    INNER JOIN public.tracks t ON ads.active_track_id = t.id
    WHERE ads.setting_key = 'active_track'
    AND ads.active_track_id IS NOT NULL
    LIMIT 1;
    
    -- If no active track found, return error
    IF active_track_record.id IS NULL THEN
        RETURN json_build_object(
            'error', true,
            'message', 'Kein aktiver Therapie-Inhalt verfügbar'
        );
    END IF;
    
    -- Create signed URL for the track (1 hour expiry)
    SELECT INTO signed_url_response
        extensions.storage_create_signed_url(
            'therapy-audio',
            active_track_record.storage_path,
            3600 -- 1 hour expiry
        );
    
    -- Build final result
    result := json_build_object(
        'error', false,
        'title', active_track_record.title,
        'signed_url', signed_url_response,
        'duration_sec', active_track_record.duration_sec,
        'mime_type', active_track_record.mime_type
    );
    
    RETURN result;
    
EXCEPTION
    WHEN OTHERS THEN
        RETURN json_build_object(
            'error', true,
            'message', 'Fehler beim Laden des Therapie-Inhalts'
        );
END;
$function$;

-- Step 10: Create trigger function for updated_at columns
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $function$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$function$;

-- Add update triggers
CREATE TRIGGER update_tracks_updated_at
    BEFORE UPDATE ON public.tracks
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_admin_settings_updated_at
    BEFORE UPDATE ON public.admin_settings
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

-- Step 11: Insert sample data for testing
DO $$
DECLARE
    track_id UUID := gen_random_uuid();
    settings_id UUID := gen_random_uuid();
BEGIN
    -- Insert sample track
    INSERT INTO public.tracks (id, title, storage_path, duration_sec, mime_type)
    VALUES (
        track_id,
        'Entspannungsmusik für Tinnitus-Therapie',
        'therapy-tracks/sample-relaxation-track.mp3',
        300, -- 5 minutes
        'audio/mpeg'
    );
    
    -- Set it as active track in admin settings
    INSERT INTO public.admin_settings (id, setting_key, setting_value, active_track_id)
    VALUES (
        settings_id,
        'active_track',
        'Sample relaxation track for therapy sessions',
        track_id
    );
    
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Sample data insertion failed: %', SQLERRM;
END $$;

-- Step 12: Create cleanup function for development
CREATE OR REPLACE FUNCTION public.cleanup_audio_therapy_data()
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $function$
BEGIN
    -- Delete in dependency order
    DELETE FROM public.admin_settings WHERE setting_key LIKE '%track%';
    DELETE FROM public.tracks WHERE title LIKE '%Sample%' OR title LIKE '%Test%';
    
    RAISE NOTICE 'Audio therapy test data cleaned up successfully';
END;
$function$;