-- Location: supabase/migrations/20250907142659_tinniwell_tinnitus_therapy_complete.sql
-- Schema Analysis: Fresh project with no existing schema
-- Integration Type: Complete schema creation
-- Dependencies: None (fresh project)

-- Module: TinniWell - Complete Tinnitus Therapy Management System
-- Features: User management, therapy sessions, progress tracking, license management

-- 1. Types and Enums
CREATE TYPE public.user_role AS ENUM ('patient', 'doctor', 'admin');
CREATE TYPE public.therapy_mode AS ENUM ('ausblendung', 'ueberlagerung', 'gegentakt');
CREATE TYPE public.session_status AS ENUM ('active', 'completed', 'paused', 'cancelled');
CREATE TYPE public.license_status AS ENUM ('pending', 'active', 'expired', 'revoked');
CREATE TYPE public.symptom_severity AS ENUM ('mild', 'moderate', 'severe', 'very_severe');

-- 2. Core Tables (no foreign keys first)
CREATE TABLE public.user_profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id),
    email TEXT NOT NULL UNIQUE,
    full_name TEXT NOT NULL,
    role public.user_role DEFAULT 'patient'::public.user_role,
    date_of_birth DATE,
    phone_number TEXT,
    avatar_url TEXT,
    medical_id TEXT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT true
);

-- 3. Medical Information Tables
CREATE TABLE public.medical_profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    tinnitus_onset_date DATE,
    tinnitus_cause TEXT,
    hearing_loss_degree TEXT,
    affected_ear TEXT CHECK (affected_ear IN ('left', 'right', 'both')),
    dominant_frequency_hz INTEGER,
    volume_level INTEGER CHECK (volume_level BETWEEN 0 AND 100),
    medical_notes TEXT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 4. License Management
CREATE TABLE public.licenses (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    license_key TEXT NOT NULL UNIQUE,
    license_status public.license_status DEFAULT 'pending'::public.license_status,
    activated_at TIMESTAMPTZ,
    expires_at TIMESTAMPTZ,
    device_info JSONB,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 5. Therapy Sessions
CREATE TABLE public.therapy_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    therapy_mode public.therapy_mode NOT NULL,
    frequency_hz INTEGER NOT NULL,
    intensity_level INTEGER CHECK (intensity_level BETWEEN 0 AND 100),
    duration_minutes INTEGER NOT NULL,
    session_status public.session_status DEFAULT 'active'::public.session_status,
    started_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMPTZ,
    effectiveness_rating INTEGER CHECK (effectiveness_rating BETWEEN 1 AND 5),
    notes TEXT,
    session_data JSONB,
    audio_file_path TEXT
);

-- 6. Progress Tracking
CREATE TABLE public.symptom_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    severity_level INTEGER CHECK (severity_level BETWEEN 1 AND 10),
    symptoms_description TEXT,
    mood_before INTEGER CHECK (mood_before BETWEEN 1 AND 10),
    mood_after INTEGER CHECK (mood_after BETWEEN 1 AND 10),
    triggers TEXT,
    environmental_factors TEXT,
    logged_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 7. Treatment Plans
CREATE TABLE public.treatment_plans (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    doctor_id UUID REFERENCES public.user_profiles(id) ON DELETE SET NULL,
    plan_name TEXT NOT NULL,
    recommended_frequency_hz INTEGER,
    recommended_intensity INTEGER CHECK (recommended_intensity BETWEEN 0 AND 100),
    recommended_duration_minutes INTEGER,
    recommended_therapy_mode public.therapy_mode,
    sessions_per_week INTEGER,
    plan_duration_weeks INTEGER,
    special_instructions TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 8. Progress Statistics
CREATE TABLE public.progress_statistics (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    date_recorded DATE DEFAULT CURRENT_DATE,
    total_sessions_count INTEGER DEFAULT 0,
    average_session_duration DECIMAL(5,2),
    average_effectiveness_rating DECIMAL(3,2),
    symptom_improvement_percentage DECIMAL(5,2),
    compliance_rate DECIMAL(5,2),
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 9. User Documents
CREATE TABLE public.user_documents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    document_name TEXT NOT NULL,
    document_type TEXT NOT NULL,
    file_path TEXT NOT NULL,
    file_size_bytes BIGINT,
    uploaded_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    is_medical_record BOOLEAN DEFAULT false
);

-- 10. Essential Indexes
CREATE INDEX idx_user_profiles_email ON public.user_profiles(email);
CREATE INDEX idx_user_profiles_role ON public.user_profiles(role);
CREATE INDEX idx_medical_profiles_user_id ON public.medical_profiles(user_id);
CREATE INDEX idx_licenses_user_id ON public.licenses(user_id);
CREATE INDEX idx_licenses_license_key ON public.licenses(license_key);
CREATE INDEX idx_therapy_sessions_user_id ON public.therapy_sessions(user_id);
CREATE INDEX idx_therapy_sessions_started_at ON public.therapy_sessions(started_at);
CREATE INDEX idx_symptom_logs_user_id ON public.symptom_logs(user_id);
CREATE INDEX idx_symptom_logs_logged_at ON public.symptom_logs(logged_at);
CREATE INDEX idx_treatment_plans_user_id ON public.treatment_plans(user_id);
CREATE INDEX idx_progress_statistics_user_id ON public.progress_statistics(user_id);
CREATE INDEX idx_user_documents_user_id ON public.user_documents(user_id);

-- 11. Functions (MUST BE BEFORE RLS POLICIES)
CREATE OR REPLACE FUNCTION public.is_doctor_or_admin()
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
SELECT EXISTS (
    SELECT 1 FROM auth.users au
    WHERE au.id = auth.uid() 
    AND (au.raw_user_meta_data->>'role' IN ('doctor', 'admin')
         OR au.raw_app_meta_data->>'role' IN ('doctor', 'admin'))
)
$$;

CREATE OR REPLACE FUNCTION public.can_access_patient_data(patient_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
SELECT CASE
    WHEN auth.uid() = patient_id THEN true
    WHEN public.is_doctor_or_admin() THEN true
    ELSE false
END
$$;

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
SECURITY DEFINER
LANGUAGE plpgsql
AS $$
BEGIN
  INSERT INTO public.user_profiles (id, email, full_name, role)
  VALUES (
    NEW.id, 
    NEW.email, 
    COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)),
    COALESCE(NEW.raw_user_meta_data->>'role', 'patient')::public.user_role
  );
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.update_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;

-- 12. Enable RLS
ALTER TABLE public.user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.medical_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.licenses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.therapy_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.symptom_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.treatment_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.progress_statistics ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_documents ENABLE ROW LEVEL SECURITY;

-- 13. RLS Policies (Following correct patterns)

-- Pattern 1: Core user table (user_profiles) - Simple only, no functions
CREATE POLICY "users_manage_own_user_profiles"
ON public.user_profiles
FOR ALL
TO authenticated
USING (id = auth.uid())
WITH CHECK (id = auth.uid());

-- Pattern 6A: Role-based access using auth metadata for doctors/admins
CREATE POLICY "doctors_admins_view_all_profiles"
ON public.user_profiles
FOR SELECT
TO authenticated
USING (public.is_doctor_or_admin());

-- Pattern 2: Simple user ownership for medical profiles
CREATE POLICY "users_manage_own_medical_profiles"
ON public.medical_profiles
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- Doctors can view all medical profiles
CREATE POLICY "doctors_view_medical_profiles"
ON public.medical_profiles
FOR SELECT
TO authenticated
USING (public.is_doctor_or_admin());

-- Pattern 2: Simple user ownership for licenses
CREATE POLICY "users_manage_own_licenses"
ON public.licenses
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- Admins can manage all licenses
CREATE POLICY "admins_manage_all_licenses"
ON public.licenses
FOR ALL
TO authenticated
USING (public.is_doctor_or_admin())
WITH CHECK (public.is_doctor_or_admin());

-- Pattern 2: Simple user ownership for therapy sessions
CREATE POLICY "users_manage_own_therapy_sessions"
ON public.therapy_sessions
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- Doctors can view all sessions
CREATE POLICY "doctors_view_therapy_sessions"
ON public.therapy_sessions
FOR SELECT
TO authenticated
USING (public.is_doctor_or_admin());

-- Pattern 2: Simple user ownership for symptom logs
CREATE POLICY "users_manage_own_symptom_logs"
ON public.symptom_logs
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- Doctors can view symptom logs
CREATE POLICY "doctors_view_symptom_logs"
ON public.symptom_logs
FOR SELECT
TO authenticated
USING (public.is_doctor_or_admin());

-- Treatment plans - patients can view, doctors can manage
CREATE POLICY "users_view_own_treatment_plans"
ON public.treatment_plans
FOR SELECT
TO authenticated
USING (user_id = auth.uid() OR public.is_doctor_or_admin());

CREATE POLICY "doctors_insert_treatment_plans"
ON public.treatment_plans
FOR INSERT
TO authenticated
WITH CHECK (public.is_doctor_or_admin());

CREATE POLICY "doctors_update_treatment_plans"
ON public.treatment_plans
FOR UPDATE
TO authenticated
USING (public.is_doctor_or_admin())
WITH CHECK (public.is_doctor_or_admin());

CREATE POLICY "doctors_delete_treatment_plans"
ON public.treatment_plans
FOR DELETE
TO authenticated
USING (public.is_doctor_or_admin());

-- Pattern 2: Simple user ownership for progress statistics
CREATE POLICY "users_view_own_progress_statistics"
ON public.progress_statistics
FOR SELECT
TO authenticated
USING (user_id = auth.uid() OR public.is_doctor_or_admin());

CREATE POLICY "system_insert_progress_statistics"
ON public.progress_statistics
FOR INSERT
TO authenticated
WITH CHECK (user_id = auth.uid());

CREATE POLICY "system_update_progress_statistics"
ON public.progress_statistics
FOR UPDATE
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

CREATE POLICY "system_delete_progress_statistics"
ON public.progress_statistics
FOR DELETE
TO authenticated
USING (user_id = auth.uid());

-- Pattern 2: Simple user ownership for documents
CREATE POLICY "users_manage_own_user_documents"
ON public.user_documents
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- Doctors can view medical documents
CREATE POLICY "doctors_view_medical_documents"
ON public.user_documents
FOR SELECT
TO authenticated
USING (public.is_doctor_or_admin() AND is_medical_record = true);

-- 14. Triggers
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

CREATE TRIGGER update_user_profiles_updated_at
  BEFORE UPDATE ON public.user_profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER update_medical_profiles_updated_at
  BEFORE UPDATE ON public.medical_profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER update_treatment_plans_updated_at
  BEFORE UPDATE ON public.treatment_plans
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

-- 15. Mock Data
DO $$
DECLARE
    patient_auth_id UUID := gen_random_uuid();
    doctor_auth_id UUID := gen_random_uuid();
    admin_auth_id UUID := gen_random_uuid();
    treatment_plan_id UUID := gen_random_uuid();
    session1_id UUID := gen_random_uuid();
    session2_id UUID := gen_random_uuid();
BEGIN
    -- Create auth users with required fields matching mock credentials from login
    INSERT INTO auth.users (
        id, instance_id, aud, role, email, encrypted_password, email_confirmed_at,
        created_at, updated_at, raw_user_meta_data, raw_app_meta_data,
        is_sso_user, is_anonymous, confirmation_token, confirmation_sent_at,
        recovery_token, recovery_sent_at, email_change_token_new, email_change,
        email_change_sent_at, email_change_token_current, email_change_confirm_status,
        reauthentication_token, reauthentication_sent_at, phone, phone_change,
        phone_change_token, phone_change_sent_at
    ) VALUES
        (patient_auth_id, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated',
         'patient@tinniwell.de', crypt('patient123', gen_salt('bf', 10)), now(), now(), now(),
         '{"full_name": "Max Mustermann", "role": "patient"}'::jsonb, '{"provider": "email", "providers": ["email"]}'::jsonb,
         false, false, '', null, '', null, '', '', null, '', 0, '', null, null, '', '', null),
        (doctor_auth_id, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated',
         'doctor@tinniwell.de', crypt('doctor123', gen_salt('bf', 10)), now(), now(), now(),
         '{"full_name": "Dr. Sarah Weber", "role": "doctor"}'::jsonb, '{"provider": "email", "providers": ["email"]}'::jsonb,
         false, false, '', null, '', null, '', '', null, '', 0, '', null, null, '', '', null),
        (admin_auth_id, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated',
         'admin@tinniwell.de', crypt('admin123', gen_salt('bf', 10)), now(), now(), now(),
         '{"full_name": "Admin User", "role": "admin"}'::jsonb, '{"provider": "email", "providers": ["email"]}'::jsonb,
         false, false, '', null, '', null, '', '', null, '', 0, '', null, null, '', '', null);

    -- Medical profiles
    INSERT INTO public.medical_profiles (user_id, tinnitus_onset_date, tinnitus_cause, hearing_loss_degree, affected_ear, dominant_frequency_hz, volume_level, medical_notes)
    VALUES (
        patient_auth_id, 
        '2023-01-15', 
        'Lärmtrauma durch Konzert',
        'Leichtgradig',
        'both',
        8000,
        65,
        'Patient berichtet von konstantem Klingeln, verstärkt in ruhiger Umgebung'
    );

    -- Licenses
    INSERT INTO public.licenses (user_id, license_key, license_status, activated_at, expires_at)
    VALUES (
        patient_auth_id,
        'TW-' || substr(md5(random()::text), 1, 8) || '-' || substr(md5(random()::text), 1, 4),
        'active'::public.license_status,
        now(),
        now() + interval '1 year'
    );

    -- Treatment plan
    INSERT INTO public.treatment_plans (id, user_id, doctor_id, plan_name, recommended_frequency_hz, recommended_intensity, recommended_duration_minutes, recommended_therapy_mode, sessions_per_week, plan_duration_weeks, special_instructions)
    VALUES (
        treatment_plan_id,
        patient_auth_id,
        doctor_auth_id,
        'Individueller Tinnitus-Therapieplan',
        8000,
        60,
        30,
        'ausblendung'::public.therapy_mode,
        5,
        12,
        'Therapie täglich durchführen, Intensität langsam steigern'
    );

    -- Therapy sessions
    INSERT INTO public.therapy_sessions (id, user_id, therapy_mode, frequency_hz, intensity_level, duration_minutes, session_status, started_at, completed_at, effectiveness_rating, notes)
    VALUES 
        (session1_id, patient_auth_id, 'ausblendung'::public.therapy_mode, 8000, 55, 32, 'completed'::public.session_status, now() - interval '2 hours', now() - interval '1.5 hours', 4, 'Gute Entspannung erreicht, deutliche Verbesserung spürbar'),
        (session2_id, patient_auth_id, 'ueberlagerung'::public.therapy_mode, 7500, 60, 28, 'completed'::public.session_status, now() - interval '1 day 3 hours', now() - interval '1 day 2.5 hours', 5, 'Sehr effektive Sitzung, Symptome deutlich reduziert');

    -- Symptom logs
    INSERT INTO public.symptom_logs (user_id, severity_level, symptoms_description, mood_before, mood_after, triggers, environmental_factors)
    VALUES 
        (patient_auth_id, 7, 'Starkes Klingeln im rechten Ohr', 3, 6, 'Stress bei der Arbeit', 'Ruhige Büroumgebung'),
        (patient_auth_id, 5, 'Mäßiges Rauschen beidseitig', 5, 8, 'Keine besonderen Trigger', 'Entspannte Atmosphäre zu Hause'),
        (patient_auth_id, 4, 'Leichtes Summen links', 6, 8, 'Nach Therapiesitzung', 'Ruhiges Wohnzimmer'),
        (patient_auth_id, 6, 'Pulsierender Tinnitus', 4, 7, 'Nach körperlicher Anstrengung', 'Nach dem Sport');

    -- Progress statistics
    INSERT INTO public.progress_statistics (user_id, date_recorded, total_sessions_count, average_session_duration, average_effectiveness_rating, symptom_improvement_percentage, compliance_rate)
    VALUES (
        patient_auth_id,
        CURRENT_DATE,
        47,
        30.5,
        4.2,
        73.5,
        87.3
    );

    -- User documents
    INSERT INTO public.user_documents (user_id, document_name, document_type, file_path, is_medical_record)
    VALUES 
        (patient_auth_id, 'Audiogramm_2024.pdf', 'medical_report', 'documents/' || patient_auth_id || '/medical_records/audiogramm_2024.pdf', true),
        (patient_auth_id, 'HNO_Befund.pdf', 'medical_report', 'documents/' || patient_auth_id || '/medical_records/hno_befund.pdf', true);

EXCEPTION
    WHEN foreign_key_violation THEN
        RAISE NOTICE 'Foreign key error during mock data insertion: %', SQLERRM;
    WHEN unique_violation THEN
        RAISE NOTICE 'Unique constraint error during mock data insertion: %', SQLERRM;
    WHEN OTHERS THEN
        RAISE NOTICE 'Unexpected error during mock data insertion: %', SQLERRM;
END $$;

-- 16. Cleanup function for development
CREATE OR REPLACE FUNCTION public.cleanup_mock_data()
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    mock_user_ids_to_delete UUID[];
BEGIN
    -- Get mock user IDs
    SELECT ARRAY_AGG(id) INTO mock_user_ids_to_delete
    FROM auth.users
    WHERE email IN ('patient@tinniwell.de', 'doctor@tinniwell.de', 'admin@tinniwell.de');

    -- Delete in dependency order (children first)
    DELETE FROM public.user_documents WHERE user_id = ANY(mock_user_ids_to_delete);
    DELETE FROM public.progress_statistics WHERE user_id = ANY(mock_user_ids_to_delete);
    DELETE FROM public.symptom_logs WHERE user_id = ANY(mock_user_ids_to_delete);
    DELETE FROM public.therapy_sessions WHERE user_id = ANY(mock_user_ids_to_delete);
    DELETE FROM public.treatment_plans WHERE user_id = ANY(mock_user_ids_to_delete);
    DELETE FROM public.licenses WHERE user_id = ANY(mock_user_ids_to_delete);
    DELETE FROM public.medical_profiles WHERE user_id = ANY(mock_user_ids_to_delete);
    DELETE FROM public.user_profiles WHERE id = ANY(mock_user_ids_to_delete);
    
    -- Delete auth.users last
    DELETE FROM auth.users WHERE id = ANY(mock_user_ids_to_delete);
    
    RAISE NOTICE 'Mock data cleanup completed successfully';
EXCEPTION
    WHEN foreign_key_violation THEN
        RAISE NOTICE 'Foreign key constraint prevents deletion: %', SQLERRM;
    WHEN OTHERS THEN
        RAISE NOTICE 'Cleanup failed: %', SQLERRM;
END $$;

COMMENT ON TABLE public.user_profiles IS 'User profiles for TinniWell application with role-based access';
COMMENT ON TABLE public.medical_profiles IS 'Medical information specific to tinnitus condition';
COMMENT ON TABLE public.therapy_sessions IS 'Therapy sessions with different modes and effectiveness tracking';
COMMENT ON TABLE public.symptom_logs IS 'Patient symptom tracking with severity and mood indicators';
COMMENT ON TABLE public.treatment_plans IS 'Doctor-prescribed treatment plans for patients';
COMMENT ON TABLE public.progress_statistics IS 'Aggregated progress statistics for analytics';