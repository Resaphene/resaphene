-- Add the 3 uploaded therapy audio tracks
INSERT INTO public.tracks (
  id,
  title, 
  storage_path,
  duration_sec,
  mime_type,
  file_size_bytes,
  created_at,
  updated_at
) VALUES 
(
  gen_random_uuid(),
  'Am Meer',
  'Am Meer.mp3',
  180, -- Estimated 3 minutes
  'audio/mpeg',
  0, -- File size will be updated when accessed
  CURRENT_TIMESTAMP,
  CURRENT_TIMESTAMP
),
(
  gen_random_uuid(),
  'Visionen',
  'Visionen.mp3', 
  240, -- Estimated 4 minutes
  'audio/mpeg',
  0, -- File size will be updated when accessed
  CURRENT_TIMESTAMP,
  CURRENT_TIMESTAMP
),
(
  gen_random_uuid(),
  'Indian Summer',
  'Indian Summer.mp3',
  210, -- Estimated 3.5 minutes
  'audio/mpeg', 
  0, -- File size will be updated when accessed
  CURRENT_TIMESTAMP,
  CURRENT_TIMESTAMP
);

-- Update the admin_settings to set one of the new tracks as active if no active track is set
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM public.admin_settings 
    WHERE active_track_id IS NOT NULL
  ) THEN
    UPDATE public.admin_settings 
    SET active_track_id = (
      SELECT id FROM public.tracks 
      WHERE title = 'Am Meer' 
      LIMIT 1
    )
    WHERE id IS NOT NULL;
  END IF;
END $$;