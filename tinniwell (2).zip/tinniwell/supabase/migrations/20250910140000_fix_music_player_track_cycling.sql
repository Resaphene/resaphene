-- Location: supabase/migrations/20250910140000_fix_music_player_track_cycling.sql
-- Schema Analysis: Existing tracks table with 2 tracks, admin_settings for active track management
-- Integration Type: Extension - Adding missing track and fixing navigation functions
-- Dependencies: tracks, admin_settings tables

-- Add the missing "Am Meer" track
DO $$
DECLARE
    am_meer_track_id UUID := gen_random_uuid();
BEGIN
    -- Insert the missing "Am Meer" track
    INSERT INTO public.tracks (id, title, storage_path, duration_sec, mime_type, file_size_bytes)
    VALUES (
        am_meer_track_id,
        'Am Meer',
        'therapy-audio/AmMeer.mp3',
        290, -- 4 minutes 50 seconds
        'audio/mpeg',
        0
    );

    -- Update admin settings to use Am Meer as active track for testing
    UPDATE public.admin_settings 
    SET active_track_id = am_meer_track_id,
        setting_value = 'Am Meer',
        updated_at = CURRENT_TIMESTAMP
    WHERE setting_key = 'active_track';

    RAISE NOTICE 'Added missing Am Meer track and set as active';
EXCEPTION
    WHEN unique_violation THEN
        RAISE NOTICE 'Am Meer track already exists';
    WHEN OTHERS THEN
        RAISE NOTICE 'Error adding Am Meer track: %', SQLERRM;
END $$;

-- Fix track navigation functions for proper cycling through all available tracks

-- Drop existing functions to recreate with better logic
DROP FUNCTION IF EXISTS public.get_next_track();
DROP FUNCTION IF EXISTS public.get_previous_track();
-- Fix: Drop the existing get_available_tracks function to resolve return type conflict
DROP FUNCTION IF EXISTS public.get_available_tracks();

-- Create improved get_next_track function with proper cycling
CREATE OR REPLACE FUNCTION public.get_next_track()
RETURNS TABLE(track_id uuid, title text, storage_path text, duration_sec integer)
LANGUAGE plpgsql
STABLE SECURITY DEFINER
AS $$
DECLARE
    current_track_id UUID;
    next_track RECORD;
BEGIN
    -- Get current active track ID
    SELECT active_track_id INTO current_track_id
    FROM public.admin_settings
    WHERE setting_key = 'active_track';

    -- If no active track is set, get the first track by creation order
    IF current_track_id IS NULL THEN
        SELECT t.id, t.title, t.storage_path, t.duration_sec
        INTO next_track
        FROM public.tracks t
        ORDER BY t.created_at ASC
        LIMIT 1;
        
        IF next_track IS NOT NULL THEN
            RETURN QUERY SELECT next_track.id, next_track.title, next_track.storage_path, next_track.duration_sec;
            RETURN;
        END IF;
    END IF;

    -- Get the next track in sequence (by creation order)
    SELECT t.id, t.title, t.storage_path, t.duration_sec
    INTO next_track
    FROM public.tracks t
    WHERE t.created_at > (
        SELECT created_at FROM public.tracks WHERE id = current_track_id
    )
    ORDER BY t.created_at ASC
    LIMIT 1;

    -- If no next track found (we're at the end), cycle back to the first track
    IF next_track IS NULL THEN
        SELECT t.id, t.title, t.storage_path, t.duration_sec
        INTO next_track
        FROM public.tracks t
        ORDER BY t.created_at ASC
        LIMIT 1;
    END IF;

    -- Return the next track
    IF next_track IS NOT NULL THEN
        RETURN QUERY SELECT next_track.id, next_track.title, next_track.storage_path, next_track.duration_sec;
    END IF;
END;
$$;

-- Create improved get_previous_track function with proper cycling
CREATE OR REPLACE FUNCTION public.get_previous_track()
RETURNS TABLE(track_id uuid, title text, storage_path text, duration_sec integer)
LANGUAGE plpgsql
STABLE SECURITY DEFINER
AS $$
DECLARE
    current_track_id UUID;
    prev_track RECORD;
BEGIN
    -- Get current active track ID
    SELECT active_track_id INTO current_track_id
    FROM public.admin_settings
    WHERE setting_key = 'active_track';

    -- If no active track is set, get the last track by creation order
    IF current_track_id IS NULL THEN
        SELECT t.id, t.title, t.storage_path, t.duration_sec
        INTO prev_track
        FROM public.tracks t
        ORDER BY t.created_at DESC
        LIMIT 1;
        
        IF prev_track IS NOT NULL THEN
            RETURN QUERY SELECT prev_track.id, prev_track.title, prev_track.storage_path, prev_track.duration_sec;
            RETURN;
        END IF;
    END IF;

    -- Get the previous track in sequence (by creation order)
    SELECT t.id, t.title, t.storage_path, t.duration_sec
    INTO prev_track
    FROM public.tracks t
    WHERE t.created_at < (
        SELECT created_at FROM public.tracks WHERE id = current_track_id
    )
    ORDER BY t.created_at DESC
    LIMIT 1;

    -- If no previous track found (we're at the beginning), cycle to the last track
    IF prev_track IS NULL THEN
        SELECT t.id, t.title, t.storage_path, t.duration_sec
        INTO prev_track
        FROM public.tracks t
        ORDER BY t.created_at DESC
        LIMIT 1;
    END IF;

    -- Return the previous track
    IF prev_track IS NOT NULL THEN
        RETURN QUERY SELECT prev_track.id, prev_track.title, prev_track.storage_path, prev_track.duration_sec;
    END IF;
END;
$$;

-- Create a function to get all available tracks for users to see what's available
CREATE OR REPLACE FUNCTION public.get_available_tracks()
RETURNS TABLE(track_id uuid, title text, storage_path text, duration_sec integer, is_active boolean)
LANGUAGE sql
STABLE SECURITY DEFINER
AS $$
SELECT 
    t.id,
    t.title,
    t.storage_path,
    t.duration_sec,
    (t.id = ads.active_track_id) as is_active
FROM public.tracks t
CROSS JOIN public.admin_settings ads
WHERE ads.setting_key = 'active_track'
ORDER BY t.created_at ASC;
$$;

-- Create a function to set a specific track as active (for better user control)
CREATE OR REPLACE FUNCTION public.set_active_track_by_title(track_title TEXT)
RETURNS TABLE(success boolean, title text, storage_path text, duration_sec integer, message text)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    target_track RECORD;
BEGIN
    -- Find the track by title
    SELECT t.id, t.title, t.storage_path, t.duration_sec
    INTO target_track
    FROM public.tracks t
    WHERE t.title = track_title
    LIMIT 1;

    -- Check if track was found
    IF target_track IS NULL THEN
        RETURN QUERY SELECT 
            false, 
            ''::TEXT, 
            ''::TEXT, 
            0, 
            ('Track not found: ' || track_title)::TEXT;
        RETURN;
    END IF;

    -- Update active track
    UPDATE public.admin_settings 
    SET active_track_id = target_track.id,
        setting_value = target_track.title,
        updated_at = CURRENT_TIMESTAMP
    WHERE setting_key = 'active_track';

    -- Return success with track info
    RETURN QUERY SELECT 
        true,
        target_track.title,
        target_track.storage_path,
        target_track.duration_sec,
        ('Successfully set active track to: ' || target_track.title)::TEXT;
END;
$$;

-- Add some additional verification and logging
DO $$
DECLARE
    track_count INTEGER;
    current_active_track TEXT;
BEGIN
    -- Count total tracks
    SELECT COUNT(*) INTO track_count FROM public.tracks;
    
    -- Get current active track
    SELECT setting_value INTO current_active_track 
    FROM public.admin_settings 
    WHERE setting_key = 'active_track';

    RAISE NOTICE 'Music player fix completed:';
    RAISE NOTICE '- Total tracks available: %', track_count;
    RAISE NOTICE '- Current active track: %', COALESCE(current_active_track, 'None');
    RAISE NOTICE '- Track navigation functions updated for proper cycling';
    RAISE NOTICE '- All songs now available to all users via skip buttons';
END $$;