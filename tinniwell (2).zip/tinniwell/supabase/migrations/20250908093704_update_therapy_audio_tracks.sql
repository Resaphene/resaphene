-- Update therapy audio tracks with correct storage paths
-- This migration adds the missing audio files to the tracks table with proper therapy-audio storage folder references

-- First, add a unique constraint on title to prevent duplicates
ALTER TABLE public.tracks ADD CONSTRAINT tracks_title_unique UNIQUE (title);

-- Insert missing audio tracks with therapy-audio storage folder paths
INSERT INTO public.tracks (title, storage_path, duration_sec, mime_type, file_size_bytes) VALUES
  ('Am Meer', 'therapy-audio/Am Meer.mp3', 280, 'audio/mpeg', 0),
  ('Indian Summer', 'therapy-audio/Indian Summer.mp3', 320, 'audio/mpeg', 0)
ON CONFLICT (title) DO UPDATE SET
  storage_path = EXCLUDED.storage_path,
  duration_sec = EXCLUDED.duration_sec,
  mime_type = EXCLUDED.mime_type,
  updated_at = CURRENT_TIMESTAMP;

-- Update the existing Visionen track to ensure correct storage path (in case it was incorrect)
UPDATE public.tracks 
SET 
  storage_path = 'therapy-audio/Visionen.mp3',
  updated_at = CURRENT_TIMESTAMP
WHERE title = 'Visionen';

-- Add a comment for documentation
COMMENT ON TABLE public.tracks IS 'Audio tracks for therapy sessions stored in therapy-audio bucket';