-- Location: supabase/migrations/20250910104602_add_track_skip_functionality.sql
-- Schema Analysis: Existing tracks and admin_settings tables with audio therapy data
-- Integration Type: Extension - Adding skip functionality to existing track system
-- Dependencies: tracks, admin_settings tables (already exist)

-- Add functions for track navigation (skip previous/next)

-- Function to get next track in sequence
CREATE OR REPLACE FUNCTION public.get_next_track()
RETURNS TABLE(
    track_id UUID,
    title TEXT,
    storage_path TEXT,
    duration_sec INTEGER
)
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
SELECT 
    t.id,
    t.title,
    t.storage_path,
    t.duration_sec
FROM public.tracks t
LEFT JOIN public.admin_settings ads ON ads.active_track_id = t.id AND ads.setting_key = 'active_track'
WHERE t.id != COALESCE(ads.active_track_id, '00000000-0000-0000-0000-000000000000'::uuid)
ORDER BY t.created_at ASC
LIMIT 1;
$$;

-- Function to get previous track in sequence
CREATE OR REPLACE FUNCTION public.get_previous_track()
RETURNS TABLE(
    track_id UUID,
    title TEXT,
    storage_path TEXT,
    duration_sec INTEGER
)
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
SELECT 
    t.id,
    t.title,
    t.storage_path,
    t.duration_sec
FROM public.tracks t
LEFT JOIN public.admin_settings ads ON ads.active_track_id = t.id AND ads.setting_key = 'active_track'
WHERE t.id != COALESCE(ads.active_track_id, '00000000-0000-0000-0000-000000000000'::uuid)
ORDER BY t.created_at DESC
LIMIT 1;
$$;

-- Function to skip to next track
CREATE OR REPLACE FUNCTION public.skip_to_next_track()
RETURNS TABLE(
    success BOOLEAN,
    title TEXT,
    storage_path TEXT,
    duration_sec INTEGER,
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $func$
DECLARE
    next_track RECORD;
BEGIN
    -- Get next track
    SELECT * INTO next_track FROM public.get_next_track();
    
    IF next_track IS NULL THEN
        RETURN QUERY SELECT false, ''::TEXT, ''::TEXT, 0, 'No next track available'::TEXT;
        RETURN;
    END IF;
    
    -- Update active track
    UPDATE public.admin_settings 
    SET active_track_id = next_track.track_id,
        setting_value = next_track.title,
        updated_at = CURRENT_TIMESTAMP
    WHERE setting_key = 'active_track';
    
    -- Return success with track info
    RETURN QUERY SELECT 
        true,
        next_track.title,
        next_track.storage_path,
        next_track.duration_sec,
        ('Switched to: ' || next_track.title)::TEXT;
END;
$func$;

-- Function to skip to previous track
CREATE OR REPLACE FUNCTION public.skip_to_previous_track()
RETURNS TABLE(
    success BOOLEAN,
    title TEXT,
    storage_path TEXT,
    duration_sec INTEGER,
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $func$
DECLARE
    prev_track RECORD;
BEGIN
    -- Get previous track
    SELECT * INTO prev_track FROM public.get_previous_track();
    
    IF prev_track IS NULL THEN
        RETURN QUERY SELECT false, ''::TEXT, ''::TEXT, 0, 'No previous track available'::TEXT;
        RETURN;
    END IF;
    
    -- Update active track
    UPDATE public.admin_settings 
    SET active_track_id = prev_track.track_id,
        setting_value = prev_track.title,
        updated_at = CURRENT_TIMESTAMP
    WHERE setting_key = 'active_track';
    
    -- Return success with track info
    RETURN QUERY SELECT 
        true,
        prev_track.title,
        prev_track.storage_path,
        prev_track.duration_sec,
        ('Switched to: ' || prev_track.title)::TEXT;
END;
$func$;

-- Function to get all available tracks for UI display
CREATE OR REPLACE FUNCTION public.get_available_tracks()
RETURNS TABLE(
    track_id UUID,
    title TEXT,
    duration_sec INTEGER,
    is_active BOOLEAN
)
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
SELECT 
    t.id,
    t.title,
    t.duration_sec,
    (t.id = ads.active_track_id) as is_active
FROM public.tracks t
LEFT JOIN public.admin_settings ads ON ads.setting_key = 'active_track'
ORDER BY t.created_at ASC;
$$;