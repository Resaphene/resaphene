-- Location: supabase/migrations/20250910142553_remove_admin_music_activation.sql
-- Schema Analysis: Existing tracks, admin_settings tables with audio track management
-- Integration Type: Modificative - Remove admin dependency for music activation
-- Dependencies: tracks, admin_settings tables
-- Module: Audio Management (Removing Admin Controls)

-- Step 1: Create new function to get all available tracks (replaces admin-controlled active track)
CREATE OR REPLACE FUNCTION public.get_all_available_tracks()
RETURNS TABLE(
    track_id UUID,
    title TEXT,
    duration_sec INTEGER,
    storage_path TEXT,
    mime_type TEXT,
    created_at TIMESTAMPTZ
)
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
SELECT 
    t.id,
    t.title,
    t.duration_sec,
    t.storage_path,
    t.mime_type,
    t.created_at
FROM public.tracks t
ORDER BY t.created_at ASC;
$$;

-- Step 2: Create function to get next available track (automatic cycling)
CREATE OR REPLACE FUNCTION public.get_next_available_track(current_track_title TEXT DEFAULT NULL)
RETURNS TABLE(
    track_id UUID,
    title TEXT,
    duration_sec INTEGER,
    storage_path TEXT,
    success BOOLEAN,
    message TEXT
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
AS $$
DECLARE
    next_track_record RECORD;
    first_track_record RECORD;
    current_found BOOLEAN := FALSE;
BEGIN
    -- If no current track specified, get first track
    IF current_track_title IS NULL THEN
        SELECT t.id, t.title, t.duration_sec, t.storage_path
        INTO next_track_record
        FROM public.tracks t
        ORDER BY t.created_at ASC
        LIMIT 1;
        
        IF FOUND THEN
            track_id := next_track_record.id;
            title := next_track_record.title;
            duration_sec := next_track_record.duration_sec;
            storage_path := next_track_record.storage_path;
            success := true;
            message := 'First track selected: ' || next_track_record.title;
            RETURN NEXT;
        ELSE
            track_id := NULL;
            title := NULL;
            duration_sec := NULL;
            storage_path := NULL;
            success := false;
            message := 'No tracks available';
            RETURN NEXT;
        END IF;
        RETURN;
    END IF;

    -- Store first track for wrap-around
    SELECT t.id, t.title, t.duration_sec, t.storage_path
    INTO first_track_record
    FROM public.tracks t
    ORDER BY t.created_at ASC
    LIMIT 1;

    -- Find next track after current
    FOR next_track_record IN 
        SELECT t.id, t.title, t.duration_sec, t.storage_path
        FROM public.tracks t
        ORDER BY t.created_at ASC
    LOOP
        IF current_found THEN
            -- Return this track (it's the next one)
            track_id := next_track_record.id;
            title := next_track_record.title;
            duration_sec := next_track_record.duration_sec;
            storage_path := next_track_record.storage_path;
            success := true;
            message := 'Next track: ' || next_track_record.title;
            RETURN NEXT;
            RETURN;
        END IF;
        
        -- Check if this is the current track
        IF next_track_record.title = current_track_title THEN
            current_found := true;
        END IF;
    END LOOP;

    -- If we reached here, either wrap around to first or current track not found
    IF current_found AND first_track_record.id IS NOT NULL THEN
        -- Wrap around to first track
        track_id := first_track_record.id;
        title := first_track_record.title;
        duration_sec := first_track_record.duration_sec;
        storage_path := first_track_record.storage_path;
        success := true;
        message := 'Wrapped to first track: ' || first_track_record.title;
        RETURN NEXT;
    ELSE
        -- Current track not found, return first available
        track_id := first_track_record.id;
        title := first_track_record.title;
        duration_sec := first_track_record.duration_sec;
        storage_path := first_track_record.storage_path;
        success := true;
        message := 'Current track not found, using first: ' || COALESCE(first_track_record.title, 'None');
        RETURN NEXT;
    END IF;
END;
$$;

-- Step 3: Create function to get previous available track
CREATE OR REPLACE FUNCTION public.get_previous_available_track(current_track_title TEXT DEFAULT NULL)
RETURNS TABLE(
    track_id UUID,
    title TEXT,
    duration_sec INTEGER,
    storage_path TEXT,
    success BOOLEAN,
    message TEXT
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
AS $$
DECLARE
    prev_track_record RECORD;
    last_track_record RECORD;
    current_track_record RECORD;
BEGIN
    -- If no current track specified, get last track
    IF current_track_title IS NULL THEN
        SELECT t.id, t.title, t.duration_sec, t.storage_path
        INTO prev_track_record
        FROM public.tracks t
        ORDER BY t.created_at DESC
        LIMIT 1;
        
        IF FOUND THEN
            track_id := prev_track_record.id;
            title := prev_track_record.title;
            duration_sec := prev_track_record.duration_sec;
            storage_path := prev_track_record.storage_path;
            success := true;
            message := 'Last track selected: ' || prev_track_record.title;
            RETURN NEXT;
        ELSE
            track_id := NULL;
            title := NULL;
            duration_sec := NULL;
            storage_path := NULL;
            success := false;
            message := 'No tracks available';
            RETURN NEXT;
        END IF;
        RETURN;
    END IF;

    -- Store last track for wrap-around
    SELECT t.id, t.title, t.duration_sec, t.storage_path
    INTO last_track_record
    FROM public.tracks t
    ORDER BY t.created_at DESC
    LIMIT 1;

    -- Find current track position
    SELECT t.id, t.title, t.duration_sec, t.storage_path
    INTO current_track_record
    FROM public.tracks t
    WHERE t.title = current_track_title;

    IF NOT FOUND THEN
        -- Current track not found, return last available
        track_id := last_track_record.id;
        title := last_track_record.title;
        duration_sec := last_track_record.duration_sec;
        storage_path := last_track_record.storage_path;
        success := true;
        message := 'Current track not found, using last: ' || COALESCE(last_track_record.title, 'None');
        RETURN NEXT;
        RETURN;
    END IF;

    -- Find previous track
    SELECT t.id, t.title, t.duration_sec, t.storage_path
    INTO prev_track_record
    FROM public.tracks t
    WHERE t.created_at < (SELECT created_at FROM public.tracks WHERE title = current_track_title)
    ORDER BY t.created_at DESC
    LIMIT 1;

    IF FOUND THEN
        -- Return previous track
        track_id := prev_track_record.id;
        title := prev_track_record.title;
        duration_sec := prev_track_record.duration_sec;
        storage_path := prev_track_record.storage_path;
        success := true;
        message := 'Previous track: ' || prev_track_record.title;
        RETURN NEXT;
    ELSE
        -- Wrap around to last track
        track_id := last_track_record.id;
        title := last_track_record.title;
        duration_sec := last_track_record.duration_sec;
        storage_path := last_track_record.storage_path;
        success := true;
        message := 'Wrapped to last track: ' || last_track_record.title;
        RETURN NEXT;
    END IF;
END;
$$;

-- Step 4: Replace admin-controlled functions with automatic track selection
CREATE OR REPLACE FUNCTION public.get_random_available_track()
RETURNS TABLE(
    track_id UUID,
    title TEXT,
    duration_sec INTEGER,
    storage_path TEXT
)
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
SELECT 
    t.id,
    t.title,
    t.duration_sec,
    t.storage_path
FROM public.tracks t
ORDER BY RANDOM()
LIMIT 1;
$$;

-- Step 5: Create updated skip functions that work without admin settings
DROP FUNCTION IF EXISTS public.skip_to_next_track();
CREATE OR REPLACE FUNCTION public.skip_to_next_track()
RETURNS TABLE(
    success BOOLEAN,
    title TEXT,
    storage_path TEXT,
    duration_sec INTEGER,
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    result_record RECORD;
BEGIN
    -- Get first available track (since there's no "current" track concept anymore)
    SELECT * INTO result_record
    FROM public.get_next_available_track(NULL)
    LIMIT 1;

    IF result_record.success THEN
        success := true;
        title := result_record.title;
        storage_path := result_record.storage_path;
        duration_sec := result_record.duration_sec;
        message := result_record.message;
    ELSE
        success := false;
        title := NULL;
        storage_path := NULL;
        duration_sec := NULL;
        message := 'No tracks available for playback';
    END IF;
    
    RETURN NEXT;
END;
$$;

DROP FUNCTION IF EXISTS public.skip_to_previous_track();
CREATE OR REPLACE FUNCTION public.skip_to_previous_track()
RETURNS TABLE(
    success BOOLEAN,
    title TEXT,
    storage_path TEXT,
    duration_sec INTEGER,
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    result_record RECORD;
BEGIN
    -- Get last available track (since there's no "current" track concept anymore)
    SELECT * INTO result_record
    FROM public.get_previous_available_track(NULL)
    LIMIT 1;

    IF result_record.success THEN
        success := true;
        title := result_record.title;
        storage_path := result_record.storage_path;
        duration_sec := result_record.duration_sec;
        message := result_record.message;
    ELSE
        success := false;
        title := NULL;
        storage_path := NULL;
        duration_sec := NULL;
        message := 'No tracks available for playback';
    END IF;
    
    RETURN NEXT;
END;
$$;

-- Step 6: Update get_active_track_info to return any available track instead of admin-selected
DROP FUNCTION IF EXISTS public.get_active_track_info();
CREATE OR REPLACE FUNCTION public.get_active_track_info()
RETURNS TABLE(
    track_id UUID,
    title TEXT,
    duration_sec INTEGER,
    storage_path TEXT
)
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
-- Return the first track by creation date (chronological order)
SELECT 
    t.id,
    t.title,
    t.duration_sec,
    t.storage_path
FROM public.tracks t
ORDER BY t.created_at ASC
LIMIT 1;
$$;

-- Step 7: Add comment to admin_settings table indicating it's no longer needed for track activation
COMMENT ON COLUMN public.admin_settings.active_track_id IS 'DEPRECATED: Track activation no longer requires admin approval. All tracks in storage are automatically available.';

-- Step 8: Create function to check if any tracks are available
CREATE OR REPLACE FUNCTION public.has_available_tracks()
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
SELECT EXISTS (SELECT 1 FROM public.tracks LIMIT 1);
$$;

-- Step 9: Create function to get track count
CREATE OR REPLACE FUNCTION public.get_track_count()
RETURNS INTEGER
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
SELECT COUNT(*)::INTEGER FROM public.tracks;
$$;