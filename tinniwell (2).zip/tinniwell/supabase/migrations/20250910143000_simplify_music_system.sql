-- Location: supabase/migrations/20250910143000_simplify_music_system.sql
-- Schema Analysis: Existing tracks and admin_settings tables with complex admin-controlled system
-- Integration Type: Simplification - Remove database dependencies for music system
-- Dependencies: Removes admin_settings dependencies, keeps existing tracks table for reference only

-- Remove admin_settings dependency by dropping the foreign key constraint
-- This allows music system to work independently of admin controls
ALTER TABLE public.admin_settings 
DROP CONSTRAINT IF EXISTS admin_settings_active_track_id_fkey;

-- Drop admin_settings related functions that create complexity
DROP FUNCTION IF EXISTS public.get_active_track_info();
DROP FUNCTION IF EXISTS public.skip_to_next_track();
DROP FUNCTION IF EXISTS public.skip_to_previous_track();
DROP FUNCTION IF EXISTS public.set_active_track_by_title(text);
DROP FUNCTION IF EXISTS public.get_next_available_track();
DROP FUNCTION IF EXISTS public.get_previous_available_track();
DROP FUNCTION IF EXISTS public.get_random_available_track();
DROP FUNCTION IF EXISTS public.update_active_track_to_latest();
DROP FUNCTION IF EXISTS public.trigger_update_active_track();

-- Drop the complex triggers that maintain admin state
DROP TRIGGER IF EXISTS tracks_update_active_track_update ON public.tracks;
DROP TRIGGER IF EXISTS tracks_update_active_track_insert ON public.tracks;
DROP TRIGGER IF EXISTS tracks_update_active_track_delete ON public.tracks;

-- Create simplified functions for storage-only music system
-- These work directly with storage bucket without database dependencies

-- Function to get all audio files from storage bucket
CREATE OR REPLACE FUNCTION public.get_storage_audio_files()
RETURNS TABLE(
    file_name TEXT,
    file_path TEXT,
    created_at TIMESTAMP WITH TIME ZONE,
    updated_at TIMESTAMP WITH TIME ZONE,
    file_size INTEGER
)
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
  -- This function will be used by the audio service to list files
  -- Implementation will be handled in Flutter code via storage.from().list()
  -- This is just a placeholder for potential future database integration
  SELECT 
    'placeholder'::TEXT as file_name,
    'placeholder'::TEXT as file_path,
    NOW() as created_at,
    NOW() as updated_at,
    0 as file_size
  WHERE false; -- Returns empty result, actual implementation in Flutter
$$;

-- Simple cleanup function for old track references (optional)
CREATE OR REPLACE FUNCTION public.cleanup_old_track_system()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Remove any admin_settings entries that reference tracks
  DELETE FROM public.admin_settings 
  WHERE setting_key = 'active_track';
  
  -- Optional: Keep tracks table for reference, but remove admin dependencies
  -- The tracks table can still exist for metadata if needed in future
  
  RAISE NOTICE 'Old track system cleaned up - music now works directly from storage';
END;
$$;

-- Run cleanup
SELECT public.cleanup_old_track_system();

-- Add comment explaining the new simplified system
COMMENT ON FUNCTION public.get_storage_audio_files() IS 
'Simplified music system: Audio files are loaded directly from therapy-audio storage bucket. No database management needed - just upload files to storage and they appear automatically in the app.';

-- Create a simple view for any remaining track metadata (optional)
CREATE OR REPLACE VIEW public.simple_tracks_view AS
SELECT 
  id,
  title,
  storage_path,
  duration_sec,
  created_at
FROM public.tracks
WHERE storage_path IS NOT NULL
ORDER BY created_at DESC;

-- Grant access to the simplified system
GRANT SELECT ON public.simple_tracks_view TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_storage_audio_files() TO authenticated;