-- Location: supabase/migrations/20250908100910_auto_update_active_track.sql
-- Schema Analysis: admin_settings and tracks tables exist with active_track_id relationship
-- Integration Type: enhancement - adding automatic active track management
-- Dependencies: admin_settings, tracks tables

-- Function to update active track to the latest track
CREATE OR REPLACE FUNCTION public.update_active_track_to_latest()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    latest_track_id UUID;
BEGIN
    -- Get the latest track by created_at timestamp
    SELECT t.id INTO latest_track_id
    FROM public.tracks t
    ORDER BY t.created_at DESC
    LIMIT 1;

    -- Update admin_settings if we found a latest track
    IF latest_track_id IS NOT NULL THEN
        -- Update existing active_track setting or insert if it doesn't exist
        INSERT INTO public.admin_settings (setting_key, setting_value, active_track_id)
        VALUES ('active_track', (SELECT title FROM public.tracks WHERE id = latest_track_id), latest_track_id)
        ON CONFLICT (setting_key)
        DO UPDATE SET 
            setting_value = EXCLUDED.setting_value,
            active_track_id = EXCLUDED.active_track_id,
            updated_at = CURRENT_TIMESTAMP;
    END IF;
END;
$$;

-- Trigger function to automatically update active track when tracks are modified
CREATE OR REPLACE FUNCTION public.trigger_update_active_track()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    -- Update active track to latest after any track changes
    PERFORM public.update_active_track_to_latest();
    
    RETURN COALESCE(NEW, OLD);
END;
$$;

-- Create triggers on tracks table for INSERT, UPDATE, DELETE
DROP TRIGGER IF EXISTS tracks_update_active_track_insert ON public.tracks;
CREATE TRIGGER tracks_update_active_track_insert
    AFTER INSERT ON public.tracks
    FOR EACH ROW
    EXECUTE FUNCTION public.trigger_update_active_track();

DROP TRIGGER IF EXISTS tracks_update_active_track_update ON public.tracks;
CREATE TRIGGER tracks_update_active_track_update
    AFTER UPDATE ON public.tracks
    FOR EACH ROW
    EXECUTE FUNCTION public.trigger_update_active_track();

DROP TRIGGER IF EXISTS tracks_update_active_track_delete ON public.tracks;
CREATE TRIGGER tracks_update_active_track_delete
    AFTER DELETE ON public.tracks
    FOR EACH ROW
    EXECUTE FUNCTION public.trigger_update_active_track();

-- Initialize active track to point to the latest track
SELECT public.update_active_track_to_latest();

-- Function to manually set active track (for admin use)
CREATE OR REPLACE FUNCTION public.set_active_track(track_uuid UUID)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    track_title TEXT;
BEGIN
    -- Verify the track exists
    SELECT title INTO track_title
    FROM public.tracks
    WHERE id = track_uuid;

    IF track_title IS NULL THEN
        RETURN false;
    END IF;

    -- Update admin_settings
    INSERT INTO public.admin_settings (setting_key, setting_value, active_track_id)
    VALUES ('active_track', track_title, track_uuid)
    ON CONFLICT (setting_key)
    DO UPDATE SET 
        setting_value = EXCLUDED.setting_value,
        active_track_id = EXCLUDED.active_track_id,
        updated_at = CURRENT_TIMESTAMP;

    RETURN true;
END;
$$;

-- Function to get current active track with full details
CREATE OR REPLACE FUNCTION public.get_active_track()
RETURNS TABLE(
    track_id UUID,
    title TEXT,
    duration_sec INTEGER,
    storage_path TEXT,
    mime_type TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    SELECT 
        t.id,
        t.title,
        t.duration_sec,
        t.storage_path,
        t.mime_type
    FROM public.admin_settings ads
    JOIN public.tracks t ON ads.active_track_id = t.id
    WHERE ads.setting_key = 'active_track'
    LIMIT 1;
END;
$$;

-- Add comment for documentation
COMMENT ON FUNCTION public.update_active_track_to_latest() IS 'Automatically updates admin_settings active_track to point to the most recently created track';
COMMENT ON FUNCTION public.trigger_update_active_track() IS 'Trigger function that calls update_active_track_to_latest when tracks table changes';
COMMENT ON FUNCTION public.set_active_track(UUID) IS 'Manually set a specific track as the active track. Returns true on success, false if track not found';
COMMENT ON FUNCTION public.get_active_track() IS 'Returns full details of the currently active track from admin_settings';