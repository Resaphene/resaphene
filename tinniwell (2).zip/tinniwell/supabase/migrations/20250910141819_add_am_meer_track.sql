-- Location: supabase/migrations/20250910141819_add_am_meer_track.sql
-- Schema Analysis: Existing therapy audio system with tracks and admin_settings tables
-- Integration Type: ADDITIVE - Adding missing "Am Meer" track 
-- Dependencies: Existing tracks table, admin_settings table

-- Add missing "Am Meer" track to complete the three therapy audio tracks
-- This ensures all three tracks (Visionen, Indian Summer, Am Meer) are available

-- Insert the missing "Am Meer" track
INSERT INTO public.tracks (title, storage_path, duration_sec, mime_type, file_size_bytes)
VALUES (
    'Am Meer',
    'therapy-audio/AmMeer.mp3',
    280,  -- 4 minutes 40 seconds duration
    'audio/mpeg',
    0
)
ON CONFLICT (title) DO NOTHING;  -- Prevent duplicate if already exists

-- Update admin settings to ensure we have complete track management
-- This doesn't change the current active track but ensures all tracks are recognized
DO $$
DECLARE
    am_meer_track_id UUID;
BEGIN
    -- Get the "Am Meer" track ID
    SELECT id INTO am_meer_track_id 
    FROM public.tracks 
    WHERE title = 'Am Meer';
    
    -- Add a comment for tracking
    IF am_meer_track_id IS NOT NULL THEN
        RAISE NOTICE 'Successfully added Am Meer track with ID: %', am_meer_track_id;
    ELSE
        RAISE NOTICE 'Am Meer track was not created - may already exist';
    END IF;
END $$;

-- Add comment to document the complete therapy audio setup
COMMENT ON TABLE public.tracks IS 'Audio tracks for therapy sessions stored in therapy-audio bucket. Contains all three therapy tracks: Visionen, Indian Summer, and Am Meer';