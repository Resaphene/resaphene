-- Location: supabase/migrations/20250907160513_add_trial_subscription_system.sql
-- Schema Analysis: Extending existing TinniWell therapy system with trial/subscription functionality
-- Integration Type: Addition - building upon existing user_profiles table
-- Dependencies: user_profiles (existing), auth.users (existing)

-- 1. Types for subscription management
CREATE TYPE public.subscription_status AS ENUM ('trial', 'active', 'expired', 'cancelled', 'suspended');
CREATE TYPE public.subscription_plan AS ENUM ('free_trial', 'monthly', 'annual');
CREATE TYPE public.payment_status AS ENUM ('pending', 'completed', 'failed', 'refunded', 'cancelled');

-- 2. User subscriptions table
CREATE TABLE public.user_subscriptions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    plan public.subscription_plan DEFAULT 'free_trial'::public.subscription_plan,
    status public.subscription_status DEFAULT 'trial'::public.subscription_status,
    trial_started_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    trial_ends_at TIMESTAMPTZ DEFAULT (CURRENT_TIMESTAMP + INTERVAL '4 weeks'),
    subscription_started_at TIMESTAMPTZ,
    subscription_ends_at TIMESTAMPTZ,
    auto_renew BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 3. Payment transactions table
CREATE TABLE public.payment_transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    subscription_id UUID REFERENCES public.user_subscriptions(id) ON DELETE CASCADE,
    amount DECIMAL(10,2) NOT NULL,
    currency TEXT DEFAULT 'EUR',
    payment_method TEXT, -- 'apple_pay', 'google_pay', 'card'
    transaction_id TEXT, -- External payment provider transaction ID
    status public.payment_status DEFAULT 'pending'::public.payment_status,
    processed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 4. Subscription features tracking table
CREATE TABLE public.subscription_features (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    feature_name TEXT NOT NULL, -- 'unlimited_sessions', 'advanced_analytics', 'audiologist_reports'
    usage_count INTEGER DEFAULT 0,
    limit_count INTEGER, -- NULL for unlimited
    reset_period TEXT DEFAULT 'monthly', -- 'daily', 'weekly', 'monthly'
    last_reset TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 5. Essential Indexes
CREATE INDEX idx_user_subscriptions_user_id ON public.user_subscriptions(user_id);
CREATE INDEX idx_user_subscriptions_status ON public.user_subscriptions(status);
CREATE INDEX idx_user_subscriptions_trial_ends ON public.user_subscriptions(trial_ends_at);
CREATE INDEX idx_payment_transactions_user_id ON public.payment_transactions(user_id);
CREATE INDEX idx_payment_transactions_status ON public.payment_transactions(status);
CREATE INDEX idx_subscription_features_user_id ON public.subscription_features(user_id);

-- 6. Add updated_at trigger for new tables
CREATE TRIGGER update_user_subscriptions_updated_at
    BEFORE UPDATE ON public.user_subscriptions
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_subscription_features_updated_at
    BEFORE UPDATE ON public.subscription_features
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- 7. RLS Setup
ALTER TABLE public.user_subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payment_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subscription_features ENABLE ROW LEVEL SECURITY;

-- 8. RLS Policies using Pattern 2 (Simple User Ownership)
CREATE POLICY "users_manage_own_subscriptions"
ON public.user_subscriptions
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

CREATE POLICY "users_manage_own_transactions"
ON public.payment_transactions
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

CREATE POLICY "users_manage_own_features"
ON public.subscription_features
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- 9. Functions for subscription management
CREATE OR REPLACE FUNCTION public.create_trial_subscription(user_uuid UUID)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    subscription_id UUID;
BEGIN
    -- Create trial subscription
    INSERT INTO public.user_subscriptions (
        user_id, 
        plan, 
        status, 
        trial_started_at, 
        trial_ends_at
    )
    VALUES (
        user_uuid,
        'free_trial'::public.subscription_plan,
        'trial'::public.subscription_status,
        CURRENT_TIMESTAMP,
        CURRENT_TIMESTAMP + INTERVAL '4 weeks'
    )
    RETURNING id INTO subscription_id;
    
    -- Set up trial feature limits
    INSERT INTO public.subscription_features (user_id, feature_name, usage_count, limit_count)
    VALUES 
        (user_uuid, 'therapy_sessions', 0, NULL), -- unlimited during trial
        (user_uuid, 'progress_tracking', 0, NULL),
        (user_uuid, 'personalized_audio', 0, NULL);
        
    RETURN subscription_id;
END;
$$;

CREATE OR REPLACE FUNCTION public.check_trial_status(user_uuid UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    subscription_record RECORD;
    result JSONB;
BEGIN
    SELECT * FROM public.user_subscriptions 
    WHERE user_id = user_uuid 
    ORDER BY created_at DESC 
    LIMIT 1 
    INTO subscription_record;
    
    IF subscription_record IS NULL THEN
        result := jsonb_build_object(
            'has_subscription', false,
            'status', 'no_subscription',
            'trial_remaining_days', 0
        );
    ELSE
        result := jsonb_build_object(
            'has_subscription', true,
            'status', subscription_record.status::text,
            'plan', subscription_record.plan::text,
            'trial_remaining_days', CASE 
                WHEN subscription_record.status = 'trial' 
                THEN GREATEST(0, EXTRACT(DAYS FROM (subscription_record.trial_ends_at - CURRENT_TIMESTAMP)))
                ELSE 0 
            END,
            'trial_ends_at', subscription_record.trial_ends_at,
            'subscription_ends_at', subscription_record.subscription_ends_at,
            'auto_renew', subscription_record.auto_renew
        );
    END IF;
    
    RETURN result;
END;
$$;

-- 10. Mock Data for existing users (reference existing UUIDs)
DO $$
DECLARE
    patient_id UUID;
    doctor_id UUID;
    trial_subscription_id UUID;
BEGIN
    -- Get existing user IDs from user_profiles
    SELECT id INTO patient_id FROM public.user_profiles WHERE email = 'patient@tinniwell.de' LIMIT 1;
    SELECT id INTO doctor_id FROM public.user_profiles WHERE email = 'doctor@tinniwell.de' LIMIT 1;
    
    -- Create trial subscriptions for existing users
    IF patient_id IS NOT NULL THEN
        SELECT public.create_trial_subscription(patient_id) INTO trial_subscription_id;
        
        -- Add a sample payment transaction (completed trial signup)
        INSERT INTO public.payment_transactions (
            user_id, 
            subscription_id, 
            amount, 
            currency, 
            payment_method,
            status,
            processed_at
        )
        VALUES (
            patient_id,
            trial_subscription_id,
            0.00,
            'EUR',
            'trial_signup',
            'completed'::public.payment_status,
            CURRENT_TIMESTAMP
        );
    END IF;
    
    -- Doctors get full access by default
    IF doctor_id IS NOT NULL THEN
        INSERT INTO public.user_subscriptions (
            user_id, 
            plan, 
            status, 
            subscription_started_at,
            subscription_ends_at,
            auto_renew
        )
        VALUES (
            doctor_id,
            'annual'::public.subscription_plan,
            'active'::public.subscription_status,
            CURRENT_TIMESTAMP,
            CURRENT_TIMESTAMP + INTERVAL '1 year',
            true
        );
        
        INSERT INTO public.subscription_features (user_id, feature_name, usage_count, limit_count)
        VALUES 
            (doctor_id, 'therapy_sessions', 0, NULL),
            (doctor_id, 'progress_tracking', 0, NULL),
            (doctor_id, 'patient_management', 0, NULL),
            (doctor_id, 'advanced_analytics', 0, NULL);
    END IF;
    
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Error creating mock subscription data: %', SQLERRM;
END $$;