-- Drop and recreate get_active_track_signed_url RPC function
-- This function now returns one row with title, signed_url, duration_sec, bucket, object_path
-- Uses storage.sign_url() and parses storage_path correctly

drop function if exists public.get_active_track_signed_url();

create or replace function public.get_active_track_signed_url()
returns table(title text, signed_url text, duration_sec int, bucket text, object_path text)
language plpgsql security definer
set search_path = public, extensions
as $$
declare 
  v_path text; 
  v_bucket text; 
  v_obj text;
begin
  -- Get the active track data from admin_settings and tracks join
  select t.title, t.storage_path, coalesce(t.duration_sec,0)
  into title, v_path, duration_sec
  from public.tracks t
  join public.admin_settings s on s.active_track_id = t.id
  where s.setting_key = 'active_track'
  limit 1;

  -- If no active track found, raise exception
  if v_path is null then 
    raise exception 'NO_ACTIVE_TRACK'; 
  end if;

  -- Parse storage_path like "therapy-audio/Visionen.mp3" into bucket and object
  v_bucket := split_part(v_path,'/',1);
  v_obj := substring(v_path from length(v_bucket)+2);

  -- Set return values
  bucket := v_bucket; 
  object_path := v_obj;
  
  -- Generate signed URL (2 hours expiry = 7200 seconds)
  signed_url := storage.sign_url(v_bucket, v_obj, 7200);
  
  -- Return the single row
  return next;
end $$;

-- Grant execute permissions
grant execute on function public.get_active_track_signed_url() to anon, authenticated;

-- Update admin_settings to ensure active_track_id points to latest track if mismatch
do $$
declare 
  v_id uuid; 
  v_title text; 
  v_updated int;
begin
  -- Get the latest track by created_at
  select id, title into v_id, v_title
  from public.tracks 
  order by created_at desc 
  limit 1;

  -- If no tracks exist, show warning and exit
  if v_id is null then 
    raise warning 'Keine Tracks vorhanden'; 
    return; 
  end if;

  -- Update or insert the active_track setting
  update public.admin_settings
     set active_track_id = v_id, 
         setting_value = v_title, 
         updated_at = now()
   where setting_key = 'active_track';

  get diagnostics v_updated = row_count;
  
  -- If no rows were updated, insert new record
  if v_updated = 0 then
    insert into public.admin_settings(setting_key, setting_value, active_track_id, created_at, updated_at)
    values ('active_track', v_title, v_id, now(), now());
  end if;
end $$;