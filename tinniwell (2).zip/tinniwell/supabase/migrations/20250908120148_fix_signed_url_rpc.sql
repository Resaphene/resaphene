-- Migration: Fix get_active_track_signed_url RPC function
-- Description: Updates the function to properly handle storage path parsing and signed URL generation
-- Date: 2025-09-08

-- Drop the existing function if it exists to replace with fixed version
DROP FUNCTION IF EXISTS public.get_active_track_signed_url();

-- Create or replace the fixed function
CREATE OR REPLACE FUNCTION public.get_active_track_signed_url()
RETURNS TABLE(title text, signed_url text, duration_sec int)
LANGUAGE plpgsql 
SECURITY DEFINER
SET search_path = public, extensions
AS $$
DECLARE 
    v_store text; 
    v_bucket text; 
    v_obj text;
BEGIN
    -- Get active track details from tracks table joined with admin_settings
    SELECT t.title, t.storage_path, COALESCE(t.duration_sec, 0)
    INTO title, v_store, duration_sec
    FROM public.tracks t
    JOIN public.admin_settings s ON s.active_track_id = t.id
    WHERE s.setting_key = 'active_track'
    LIMIT 1;

    -- Check if active track was found
    IF v_store IS NULL THEN
        RAISE EXCEPTION 'NO_ACTIVE_TRACK';
    END IF;

    -- Parse storage path to extract bucket and object path
    v_bucket := split_part(v_store, '/', 1);
    v_obj := substring(v_store FROM length(v_bucket) + 2);

    -- Generate signed URL valid for 2 hours (7200 seconds)
    signed_url := storage.sign_url(v_bucket, v_obj, 7200);
    
    -- Return the row
    RETURN NEXT;
END $$;

-- Grant execute permissions to anonymous and authenticated users
GRANT EXECUTE ON FUNCTION public.get_active_track_signed_url() TO anon, authenticated;

-- Add comment for documentation
COMMENT ON FUNCTION public.get_active_track_signed_url() IS 
'Returns the currently active therapy track with a signed URL for secure access. Returns title, signed_url, and duration_sec. Raises NO_ACTIVE_TRACK exception if no active track is configured.';