-- Migration: Remove faulty storage functions that use non-existent storage.sign_url
-- Description: Completely removes all RPC functions that attempt to use storage.sign_url
-- The Flutter app will handle storage URL generation directly using Supabase client
-- Date: 2025-09-10

-- Remove all functions that use the non-existent storage.sign_url
DROP FUNCTION IF EXISTS public.get_active_track_signed_url() CASCADE;
DROP FUNCTION IF EXISTS public.get_active_track_signed_url_http() CASCADE; 
DROP FUNCTION IF EXISTS public.get_active_track_url_simple() CASCADE;
DROP FUNCTION IF EXISTS public.test_storage_connection() CASCADE;

-- Create a simple function that returns only the data needed for Flutter client
CREATE OR REPLACE FUNCTION public.get_active_track_info()
 RETURNS TABLE(title text, storage_path text, duration_sec integer)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  -- Get active track data from admin_settings and tracks join
  RETURN QUERY
  SELECT t.title, t.storage_path, COALESCE(t.duration_sec, 0)
  FROM public.tracks t
  JOIN public.admin_settings s ON s.active_track_id = t.id
  WHERE s.setting_key = 'active_track'
  LIMIT 1;
  
  -- Check if we found any results
  IF NOT FOUND THEN
    RAISE EXCEPTION 'NO_ACTIVE_TRACK';
  END IF;
END $function$;

-- Grant execute permissions
GRANT EXECUTE ON FUNCTION public.get_active_track_info() TO anon, authenticated;

-- Add comment for documentation
COMMENT ON FUNCTION public.get_active_track_info() IS 
'Returns active track info (title, storage_path, duration) for Flutter client to generate signed URLs directly using Supabase storage client createSignedUrl method.';