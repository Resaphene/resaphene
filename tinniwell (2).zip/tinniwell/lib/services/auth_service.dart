import 'package:supabase_flutter/supabase_flutter.dart';

import './supabase_service.dart';

class AuthService {
  static AuthService? _instance;
  static AuthService get instance => _instance ??= AuthService._();
  AuthService._();

  final SupabaseClient _client = SupabaseService.instance.client;

  // Authentication State
  User? get currentUser => _client.auth.currentUser;
  bool get isAuthenticated => _client.auth.currentUser != null;

  // Authentication Methods
  Future<AuthResponse> signUp({
    required String email,
    required String password,
    String? fullName,
    String role = 'patient',
  }) async {
    try {
      // Validate input parameters
      if (email.trim().isEmpty) {
        throw Exception('E-Mail-Adresse ist erforderlich');
      }
      if (password.isEmpty) {
        throw Exception('Passwort ist erforderlich');
      }
      if (fullName != null && fullName.trim().isEmpty) {
        throw Exception('Name ist erforderlich');
      }

      // Clean email input
      final cleanEmail = email.trim().toLowerCase();

      // Validate email format
      final emailRegex = RegExp(r'^[^\s@]+@[^\s@]+\.[^\s@]+$');
      if (!emailRegex.hasMatch(cleanEmail)) {
        throw Exception('Ungültige E-Mail-Adresse');
      }

      // Attempt Supabase signup with retry mechanism
      AuthResponse? response;
      int retryCount = 0;
      const maxRetries = 3;

      while (retryCount < maxRetries) {
        try {
          response = await _client.auth
              .signUp(
                email: cleanEmail,
                password: password,
                data: {
                  'full_name': fullName?.trim() ?? cleanEmail.split('@').first,
                  'role': role,
                },
              )
              .timeout(
                const Duration(seconds: 15),
                onTimeout: () {
                  throw Exception('Zeitüberschreitung bei der Registrierung');
                },
              );
          break; // Success, exit retry loop
        } on PostgrestException catch (e) {
          if (e.code == '23505' &&
              e.message.contains('user_profiles_email_key')) {
            throw Exception('Diese E-Mail-Adresse ist bereits registriert');
          }
          retryCount++;
          if (retryCount >= maxRetries) {
            throw Exception('Datenbankfehler: ${e.message}');
          }
          await Future.delayed(Duration(seconds: retryCount));
        } catch (e) {
          retryCount++;
          if (retryCount >= maxRetries) {
            rethrow;
          }
          await Future.delayed(Duration(seconds: retryCount));
        }
      }

      if (response == null) {
        throw Exception(
          'Registrierung fehlgeschlagen - Keine Antwort erhalten',
        );
      }

      // Enhanced validation of response
      if (response.user == null) {
        throw Exception('Benutzer konnte nicht erstellt werden');
      }

      // Check if user profile was created (give it some time)
      await Future.delayed(const Duration(milliseconds: 500));

      try {
        final profileExists = await _checkUserProfileExists(response.user!.id);
        if (!profileExists) {
          // Manually trigger profile creation as fallback
          await _createUserProfileFallback(response.user!);
        }
      } catch (e) {
        // Log but don't fail registration for this
        print('Warning: Could not verify profile creation: $e');
      }

      // Automatically create trial subscription
      try {
        if (response.user != null) {
          await _client.rpc(
            'create_trial_subscription',
            params: {'user_uuid': response.user!.id},
          );
        }
      } catch (e) {
        // Log but don't fail registration for this
        print('Warning: Could not create trial subscription: $e');
      }

      return response;
    } on AuthException catch (e) {
      // Handle specific Supabase auth errors
      switch (e.statusCode) {
        case '400':
          if (e.message.contains('Email rate limit exceeded')) {
            throw Exception(
              'Zu viele Registrierungsversuche. Bitte warten Sie 60 Sekunden.',
            );
          } else if (e.message.contains('Password')) {
            throw Exception('Passwort muss mindestens 8 Zeichen lang sein');
          } else if (e.message.contains('email')) {
            throw Exception('Ungültige E-Mail-Adresse');
          }
          break;
        case '422':
          if (e.message.contains('already registered')) {
            throw Exception('Diese E-Mail-Adresse ist bereits registriert');
          }
          break;
        case '429':
          throw Exception(
            'Zu viele Versuche. Bitte warten Sie einige Minuten.',
          );
        default:
          break;
      }
      throw Exception('Registrierung fehlgeschlagen: ${e.message}');
    } on Exception catch (e) {
      // Re-throw our custom exceptions
      if (e.toString().startsWith('Exception: ')) {
        rethrow;
      }
      throw Exception('Netzwerkfehler bei der Registrierung');
    } catch (error) {
      throw Exception('Unerwarteter Fehler bei der Registrierung');
    }
  }

  // Helper method to check if user profile exists
  Future<bool> _checkUserProfileExists(String userId) async {
    try {
      final response =
          await _client
              .from('user_profiles')
              .select('id')
              .eq('id', userId)
              .limit(1)
              .maybeSingle();
      return response != null;
    } catch (e) {
      return false;
    }
  }

  // Fallback method to create user profile manually
  Future<void> _createUserProfileFallback(User user) async {
    try {
      final fullName =
          user.userMetadata?['full_name'] as String? ??
          user.email?.split('@').first ??
          'User';
      final role = user.userMetadata?['role'] as String? ?? 'patient';

      await _client.from('user_profiles').insert({
        'id': user.id,
        'email': user.email,
        'full_name': fullName,
        'role': role,
        'is_active': true,
      });
    } catch (e) {
      print('Failed to create user profile fallback: $e');
      // Don't throw here, as this is just a fallback
    }
  }

  Future<AuthResponse> signIn({
    required String email,
    required String password,
  }) async {
    try {
      final response = await _client.auth.signInWithPassword(
        email: email,
        password: password,
      );

      if (response.user == null) {
        throw Exception('Invalid email or password');
      }

      return response;
    } catch (error) {
      throw Exception('Sign in failed: $error');
    }
  }

  Future<void> signOut() async {
    try {
      await _client.auth.signOut();
    } catch (error) {
      throw Exception('Sign out failed: $error');
    }
  }

  Future<void> resetPassword({required String email}) async {
    try {
      await _client.auth.resetPasswordForEmail(email);
    } catch (error) {
      throw Exception('Password reset failed: $error');
    }
  }

  Future<UserResponse> updateUser({
    String? email,
    String? password,
    Map<String, dynamic>? data,
  }) async {
    try {
      final attributes = UserAttributes(
        email: email,
        password: password,
        data: data,
      );

      final response = await _client.auth.updateUser(attributes);
      return response;
    } catch (error) {
      throw Exception('User update failed: $error');
    }
  }

  // Session Management
  Session? get currentSession => _client.auth.currentSession;

  Future<bool> refreshSession() async {
    try {
      final response = await _client.auth.refreshSession();
      return response.session != null;
    } catch (error) {
      return false;
    }
  }

  // Role-based access helpers
  Future<String?> getUserRole() async {
    try {
      final user = currentUser;
      if (user == null) return null;

      // First try to get role from user metadata
      final roleFromMetadata =
          user.userMetadata?['role'] as String? ??
          user.appMetadata['role'] as String?;

      if (roleFromMetadata != null) {
        return roleFromMetadata;
      }

      // Fallback: get role from user_profiles table
      final response =
          await _client
              .from('user_profiles')
              .select('role')
              .eq('id', user.id)
              .single();

      return response['role'] as String?;
    } catch (error) {
      return null;
    }
  }

  Future<bool> hasRole(String role) async {
    final userRole = await getUserRole();
    return userRole == role;
  }

  Future<bool> isPatient() async => await hasRole('patient');
  Future<bool> isDoctor() async => await hasRole('doctor');
  Future<bool> isAdmin() async => await hasRole('admin');

  Future<bool> canAccessPatientData(String patientId) async {
    final currentUserId = currentUser?.id;
    if (currentUserId == null) return false;

    // Users can access their own data
    if (currentUserId == patientId) return true;

    // Doctors and admins can access all patient data
    return await isDoctor() || await isAdmin();
  }

  // OAuth Authentication
  Future<bool> signInWithGoogle() async {
    try {
      return await _client.auth.signInWithOAuth(OAuthProvider.google);
    } catch (error) {
      throw Exception('Google sign in failed: $error');
    }
  }

  Future<bool> signInWithApple() async {
    try {
      return await _client.auth.signInWithOAuth(OAuthProvider.apple);
    } catch (error) {
      throw Exception('Apple sign in failed: $error');
    }
  }

  // Auth State Listener
  Stream<AuthState> get authStateChanges => _client.auth.onAuthStateChange;

  void listenToAuthChanges({required Function(AuthState) onAuthStateChange}) {
    _client.auth.onAuthStateChange.listen(onAuthStateChange);
  }

  // Email Verification
  Future<void> resendConfirmation({required String email}) async {
    try {
      await _client.auth.resend(type: OtpType.signup, email: email);
    } catch (error) {
      throw Exception('Failed to resend confirmation: $error');
    }
  }

  // Utility Methods
  String getInitials(String? fullName) {
    if (fullName == null || fullName.isEmpty) return 'U';

    final names = fullName.trim().split(' ');
    if (names.length >= 2) {
      return '${names.first[0]}${names.last[0]}'.toUpperCase();
    } else {
      return names.first[0].toUpperCase();
    }
  }

  String getDisplayName() {
    final user = currentUser;
    if (user == null) return 'Guest';

    final fullName = user.userMetadata?['full_name'] as String?;
    if (fullName != null && fullName.isNotEmpty) {
      return fullName;
    }

    return user.email?.split('@').first ?? 'User';
  }

  // Check if user needs to complete profile
  Future<bool> isProfileComplete() async {
    try {
      final user = currentUser;
      if (user == null) return false;

      final response =
          await _client
              .from('user_profiles')
              .select('full_name, role')
              .eq('id', user.id)
              .single();

      final fullName = response['full_name'] as String?;
      final role = response['role'] as String?;

      return fullName != null && fullName.isNotEmpty && role != null;
    } catch (error) {
      return false;
    }
  }

  // Account deletion (for GDPR compliance)
  Future<void> deleteAccount() async {
    try {
      final userId = currentUser?.id;
      if (userId == null) throw Exception('No user signed in');

      // The database cascade deletes will handle related data
      await _client.rpc('delete_user_account', params: {'user_id': userId});

      await signOut();
    } catch (error) {
      throw Exception('Account deletion failed: $error');
    }
  }

  // Two-Factor Authentication helpers
  Future<void> enableMFA() async {
    try {
      final response = await _client.auth.mfa.enroll(
        issuer: 'TinniWell',
        friendlyName: 'TinniWell App',
      );

      // Handle QR code generation for authenticator apps
    } catch (error) {
      throw Exception('MFA enrollment failed: $error');
    }
  }

  Future<AuthMFAVerifyResponse> verifyMFA({
    required String factorId,
    required String challengeId,
    required String code,
  }) async {
    try {
      final response = await _client.auth.mfa.verify(
        factorId: factorId,
        challengeId: challengeId,
        code: code,
      );

      return response;
    } catch (error) {
      throw Exception('MFA verification failed: $error');
    }
  }

  // Development/Testing helpers
  Future<void> signInWithMockCredentials(String email) async {
    try {
      String password;
      switch (email) {
        case 'patient@tinniwell.de':
          password = 'patient123';
          break;
        case 'doctor@tinniwell.de':
          password = 'doctor123';
          break;
        case 'admin@tinniwell.de':
          password = 'admin123';
          break;
        default:
          throw Exception('Invalid mock credentials');
      }

      await signIn(email: email, password: password);
    } catch (error) {
      throw Exception('Mock sign in failed: $error');
    }
  }

  // Trial and subscription helpers
  Future<bool> isTrialActive() async {
    try {
      final user = currentUser;
      if (user == null) return false;

      final response = await _client.rpc(
        'check_trial_status',
        params: {'user_uuid': user.id},
      );

      if (response is Map<String, dynamic>) {
        return response['status'] == 'trial' &&
            (response['trial_remaining_days'] as num) > 0;
      }
      return false;
    } catch (error) {
      return false;
    }
  }

  Future<bool> hasActiveSubscription() async {
    try {
      final user = currentUser;
      if (user == null) return false;

      final response =
          await _client
              .from('user_subscriptions')
              .select('status')
              .eq('user_id', user.id)
              .inFilter('status', ['trial', 'active'])
              .limit(1)
              .maybeSingle();

      return response != null;
    } catch (error) {
      return false;
    }
  }

  Future<String> getSubscriptionStatus() async {
    try {
      final user = currentUser;
      if (user == null) return 'no_user';

      final trialStatus = await _client.rpc(
        'check_trial_status',
        params: {'user_uuid': user.id},
      );

      if (trialStatus is Map<String, dynamic>) {
        return trialStatus['status'] as String? ?? 'unknown';
      }
      return 'unknown';
    } catch (error) {
      return 'error';
    }
  }
}
