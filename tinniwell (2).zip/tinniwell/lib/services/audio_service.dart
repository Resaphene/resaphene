import 'dart:async';

import 'package:audio_session/audio_session.dart';
import 'package:flutter/services.dart';
import 'package:just_audio/just_audio.dart' as ja;

import './supabase_service.dart';

/// Custom player state for UI updates
enum AudioPlayerState { idle, loading, buffering, ready, completed }

/// Service for handling audio playback in therapy sessions
/// Manages music streaming from Supabase storage with proper iOS audio session handling
class AudioService {
  static final AudioService _instance = AudioService._internal();
  static AudioService get instance => _instance;
  AudioService._internal();

  // Audio player and session
  ja.AudioPlayer? _audioPlayer;
  AudioSession? _audioSession;

  // Current track state
  String? _currentTrackTitle;
  String? _currentSignedUrl;
  int? _currentDurationSec;
  bool _isInitialized = false;

  // Stream controllers for UI updates
  final StreamController<AudioPlayerState> _playerStateController =
      StreamController<AudioPlayerState>.broadcast();
  final StreamController<Duration?> _durationController =
      StreamController<Duration?>.broadcast();
  final StreamController<Duration> _positionController =
      StreamController<Duration>.broadcast();
  final StreamController<String?> _trackTitleController =
      StreamController<String?>.broadcast();

  // Getters for streams
  Stream<AudioPlayerState> get playerStateStream =>
      _playerStateController.stream;
  Stream<Duration?> get durationStream => _durationController.stream;
  Stream<Duration> get positionStream => _positionController.stream;
  Stream<String?> get trackTitleStream => _trackTitleController.stream;

  // Current state getters
  bool get isPlaying => _audioPlayer?.playing ?? false;
  bool get isInitialized => _isInitialized;
  String? get currentTrackTitle => _currentTrackTitle;
  Duration? get currentDuration => _audioPlayer?.duration;
  Duration get currentPosition => _audioPlayer?.position ?? Duration.zero;

  /// Initialize the audio service with proper iOS audio session
  Future<void> initialize() async {
    if (_isInitialized) return;

    try {
      _audioSession = await AudioSession.instance;
      await _audioSession!.configure(const AudioSessionConfiguration.music());

      _audioPlayer = ja.AudioPlayer();
      _setupAudioListeners();

      _isInitialized = true;
      print('AudioService initialized successfully');
    } catch (error) {
      print('Failed to initialize AudioService: $error');
      throw Exception('Audio-System konnte nicht initialisiert werden');
    }
  }

  /// Set up audio player event listeners
  void _setupAudioListeners() {
    if (_audioPlayer == null) return;

    _audioPlayer!.playerStateStream.listen((playerState) {
      _playerStateController.add(playerState.toAudioPlayerState());
    });

    _audioPlayer!.durationStream.listen((duration) {
      _durationController.add(duration);
    });

    _audioPlayer!.positionStream.listen((position) {
      _positionController.add(position);
    });

    _audioPlayer!.processingStateStream.listen((state) {
      if (state == ja.ProcessingState.completed) {
        _handlePlaybackComplete();
      }
    });
  }

  void _handlePlaybackComplete() {
    _audioPlayer?.seek(Duration.zero);
    _audioPlayer?.pause();
    HapticFeedback.lightImpact();
  }

  /// Get any available track data from Supabase (updated to work without admin settings)
  Future<Map<String, dynamic>> _getActiveTrackFromSupabase() async {
    try {
      final client = SupabaseService.instance.client;

      // ✅ Get any available track (no admin control needed)
      final row = await client.rpc('get_active_track_info').single();

      final String? title = row['title']?.toString();
      final String? storagePath = row['storage_path']?.toString();
      final int durationSec = (row['duration_sec'] as num?)?.toInt() ?? 0;

      if (title == null || storagePath == null) {
        return {'error': true, 'message': 'Keine Therapie-Tracks verfügbar'};
      }

      // Parse storage_path like "therapy-audio/Visionen.mp3"
      final pathParts = storagePath.split('/');
      if (pathParts.length < 2) {
        return {
          'error': true,
          'message': 'Ungültiger Speicherpfad: $storagePath',
        };
      }

      final String bucket = pathParts[0]; // "therapy-audio"
      final String filePath = pathParts.sublist(1).join('/'); // "Visionen.mp3"

      print('Parsed storage path - Bucket: $bucket, File: $filePath');

      // ✅ Use official Supabase client createSignedUrl method
      final String signedUrl = await client.storage
          .from(bucket)
          .createSignedUrl(filePath, 60); // 60 seconds expiry

      print('Generated signed URL: $signedUrl');

      return {
        'error': false,
        'title': title,
        'signed_url': signedUrl,
        'duration_sec': durationSec,
        'bucket': bucket,
        'file_path': filePath,
      };
    } catch (error) {
      print('Error getting available track: $error');
      final msg = error.toString();
      if (msg.contains('NO_ACTIVE_TRACK') || msg.contains('null')) {
        return {
          'error': true,
          'message': 'Keine Therapie-Tracks im System verfügbar',
        };
      } else if (msg.contains('JWT expired') || msg.contains('invalid JWT')) {
        return {
          'error': true,
          'message': 'Sitzung abgelaufen, bitte neu anmelden',
        };
      } else if (msg.contains('NetworkException') ||
          msg.contains('SocketException')) {
        return {
          'error': true,
          'message': 'Netzwerkfehler - bitte Internet prüfen',
        };
      } else if (msg.contains('timeout')) {
        return {
          'error': true,
          'message': 'Zeitüberschreitung - bitte erneut versuchen',
        };
      } else if (msg.contains('Storage')) {
        return {
          'error': true,
          'message': 'Fehler beim Zugriff auf Audio-Dateien',
        };
      }
      return {'error': true, 'message': 'Verbindungsfehler zum Server'};
    }
  }

  Future<void> _loadAndPlayAudio(String signedUrl) async {
    if (_audioPlayer == null) {
      throw Exception('Audio player not initialized');
    }
    try {
      print('Attempting to load audio from URL: $signedUrl');
      await _audioPlayer!.setUrl(signedUrl);
      await _audioPlayer!.play();
      print('Audio loaded and playing successfully');
      HapticFeedback.mediumImpact();
    } catch (error) {
      print('Error loading/playing audio: $error');
      if (error.toString().contains('Failed to load')) {
        throw Exception('Die Audio-Datei konnte nicht geladen werden.');
      } else if (error.toString().contains('timeout')) {
        throw Exception('Zeitüberschreitung beim Laden der Audio-Datei.');
      } else if (error.toString().contains('403')) {
        throw Exception('Zugriff verweigert. Bitte neu anmelden.');
      } else {
        throw Exception('Audio konnte nicht geladen werden.');
      }
    }
  }

  /// Skip to next track (updated to work without admin dependency)
  Future<Map<String, dynamic>> skipToNextTrack() async {
    try {
      final client = SupabaseService.instance.client;
      final result = await client.rpc('skip_to_next_track').single();

      final bool success = result['success'] ?? false;

      if (success) {
        final String title = result['title']?.toString() ?? '';
        final String storagePath = result['storage_path']?.toString() ?? '';
        final int durationSec = (result['duration_sec'] as num?)?.toInt() ?? 0;

        // Parse storage path and generate signed URL
        final pathParts = storagePath.split('/');
        if (pathParts.length >= 2) {
          final String bucket = pathParts[0];
          final String filePath = pathParts.sublist(1).join('/');

          try {
            final String signedUrl =
                await client.storage.from(bucket).createSignedUrl(filePath, 60);

            // Update current track state
            _currentTrackTitle = title;
            _currentSignedUrl = signedUrl;
            _currentDurationSec = durationSec;
            _trackTitleController.add(title);

            // Load and play new track
            await _loadAndPlayAudio(signedUrl);

            HapticFeedback.mediumImpact();
            return {
              'error': false,
              'title': title,
              'message':
                  result['message']?.toString() ?? 'Nächster Track geladen',
            };
          } catch (storageError) {
            print('Storage URL generation error: $storageError');
            return {
              'error': true,
              'message': 'Fehler beim Laden des nächsten Tracks',
            };
          }
        } else {
          return {
            'error': true,
            'message': 'Ungültiger Speicherpfad für nächsten Track',
          };
        }
      } else {
        return {
          'error': true,
          'message': result['message']?.toString() ??
              'Alle verfügbaren Tracks durchlaufen',
        };
      }
    } catch (error) {
      print('Error skipping to next track: $error');
      return {
        'error': true,
        'message': 'Fehler beim Wechsel zum nächsten Track',
      };
    }
  }

  /// Skip to previous track (updated to work without admin dependency)
  Future<Map<String, dynamic>> skipToPreviousTrack() async {
    try {
      final client = SupabaseService.instance.client;
      final result = await client.rpc('skip_to_previous_track').single();

      final bool success = result['success'] ?? false;

      if (success) {
        final String title = result['title']?.toString() ?? '';
        final String storagePath = result['storage_path']?.toString() ?? '';
        final int durationSec = (result['duration_sec'] as num?)?.toInt() ?? 0;

        // Parse storage path and generate signed URL
        final pathParts = storagePath.split('/');
        if (pathParts.length >= 2) {
          final String bucket = pathParts[0];
          final String filePath = pathParts.sublist(1).join('/');

          try {
            final String signedUrl =
                await client.storage.from(bucket).createSignedUrl(filePath, 60);

            // Update current track state
            _currentTrackTitle = title;
            _currentSignedUrl = signedUrl;
            _currentDurationSec = durationSec;
            _trackTitleController.add(title);

            // Load and play new track
            await _loadAndPlayAudio(signedUrl);

            HapticFeedback.mediumImpact();
            return {
              'error': false,
              'title': title,
              'message':
                  result['message']?.toString() ?? 'Vorheriger Track geladen',
            };
          } catch (storageError) {
            print('Storage URL generation error: $storageError');
            return {
              'error': true,
              'message': 'Fehler beim Laden des vorherigen Tracks',
            };
          }
        } else {
          return {
            'error': true,
            'message': 'Ungültiger Speicherpfad für vorherigen Track',
          };
        }
      } else {
        return {
          'error': true,
          'message': result['message']?.toString() ??
              'Alle verfügbaren Tracks durchlaufen',
        };
      }
    } catch (error) {
      print('Error skipping to previous track: $error');
      return {
        'error': true,
        'message': 'Fehler beim Wechsel zum vorherigen Track',
      };
    }
  }

  Future<void> togglePlayPause() async {
    if (_audioPlayer == null) return;
    try {
      if (_audioPlayer!.playing) {
        await _audioPlayer!.pause();
      } else {
        await _audioPlayer!.play();
      }
      HapticFeedback.lightImpact();
    } catch (error) {
      print('Error toggling play/pause: $error');
    }
  }

  Future<void> stop() async {
    if (_audioPlayer == null) return;
    try {
      await _audioPlayer!.stop();
      await _audioPlayer!.seek(Duration.zero);
      _currentTrackTitle = null;
      _currentSignedUrl = null;
      _currentDurationSec = null;
      _trackTitleController.add(null);
      HapticFeedback.lightImpact();
    } catch (error) {
      print('Error stopping audio: $error');
    }
  }

  Future<void> seek(Duration position) async {
    if (_audioPlayer == null) return;
    try {
      await _audioPlayer!.seek(position);
    } catch (error) {
      print('Error seeking audio: $error');
    }
  }

  Future<void> setVolume(double volume) async {
    if (_audioPlayer == null) return;
    try {
      await _audioPlayer!.setVolume(volume.clamp(0.0, 1.0));
    } catch (error) {
      print('Error setting volume: $error');
    }
  }

  Future<void> dispose() async {
    try {
      await _audioPlayer?.dispose();
      await _playerStateController.close();
      await _durationController.close();
      await _positionController.close();
      await _trackTitleController.close();
      _audioPlayer = null;
      _audioSession = null;
      _isInitialized = false;
      print('AudioService disposed successfully');
    } catch (error) {
      print('Error disposing AudioService: $error');
    }
  }

  Future<Map<String, dynamic>> startTherapySession() async {
    try {
      await initialize();
      final trackResult = await _getActiveTrackFromSupabase();
      if (trackResult['error'] == true) {
        return trackResult;
      }

      final String signedUrl = trackResult['signed_url'] as String;
      final String title = trackResult['title'] as String;
      final int durationSec =
          (trackResult['duration_sec'] as num?)?.toInt() ?? 0;

      _currentTrackTitle = title;
      _currentSignedUrl = signedUrl;
      _currentDurationSec = durationSec;
      _trackTitleController.add(title);

      await _loadAndPlayAudio(signedUrl);

      return {
        'error': false,
        'title': title,
        'message': 'Therapie-Sitzung erfolgreich gestartet',
      };
    } catch (error) {
      print('Error starting therapy session: $error');
      _currentTrackTitle = null;
      _currentSignedUrl = null;
      _currentDurationSec = null;
      _trackTitleController.add(null);
      return {
        'error': true,
        'message': 'Fehler beim Starten der Therapie-Sitzung',
      };
    }
  }
}

/// Extension to convert just_audio PlayerState to our AudioPlayerState
extension PlayerStateExtension on ja.PlayerState {
  AudioPlayerState toAudioPlayerState() {
    switch (processingState) {
      case ja.ProcessingState.idle:
        return AudioPlayerState.idle;
      case ja.ProcessingState.loading:
        return AudioPlayerState.loading;
      case ja.ProcessingState.buffering:
        return AudioPlayerState.buffering;
      case ja.ProcessingState.ready:
        return AudioPlayerState.ready;
      case ja.ProcessingState.completed:
        return AudioPlayerState.completed;
    }
  }
}
