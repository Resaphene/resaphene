import 'dart:async';

import 'package:audio_session/audio_session.dart';
import 'package:flutter/services.dart';
import 'package:just_audio/just_audio.dart' as ja;

import './supabase_service.dart';

/// Simple Audio Service for Storage-Based Music System
/// Works directly with Supabase storage bucket - no database dependencies
/// Users just upload songs to therapy-audio bucket and they appear automatically
class SimpleAudioService {
  static final SimpleAudioService _instance = SimpleAudioService._internal();
  static SimpleAudioService get instance => _instance;
  SimpleAudioService._internal();

  // Audio player and session
  ja.AudioPlayer? _audioPlayer;
  AudioSession? _audioSession;

  // Simple storage-based state
  List<Map<String, dynamic>> _availableFiles = [];
  int _currentIndex = 0;
  String? _currentTrackTitle;
  bool _isInitialized = false;

  // Stream controllers for UI updates
  final StreamController<String?> _trackTitleController =
      StreamController<String?>.broadcast();
  final StreamController<Duration?> _durationController =
      StreamController<Duration?>.broadcast();
  final StreamController<Duration> _positionController =
      StreamController<Duration>.broadcast();
  final StreamController<bool> _playingController =
      StreamController<bool>.broadcast();

  // Getters for streams
  Stream<String?> get trackTitleStream => _trackTitleController.stream;
  Stream<Duration?> get durationStream => _durationController.stream;
  Stream<Duration> get positionStream => _positionController.stream;
  Stream<bool> get playingStream => _playingController.stream;

  // Current state getters
  bool get isPlaying => _audioPlayer?.playing ?? false;
  bool get isInitialized => _isInitialized;
  String? get currentTrackTitle => _currentTrackTitle;
  Duration? get currentDuration => _audioPlayer?.duration;
  Duration get currentPosition => _audioPlayer?.position ?? Duration.zero;
  int get totalTracks => _availableFiles.length;
  int get currentTrackIndex => _currentIndex + 1; // 1-based for UI

  /// Initialize the audio service
  Future<void> initialize() async {
    if (_isInitialized) return;

    try {
      _audioSession = await AudioSession.instance;
      await _audioSession!.configure(const AudioSessionConfiguration.music());

      _audioPlayer = ja.AudioPlayer();
      _setupAudioListeners();

      _isInitialized = true;
      print('SimpleAudioService initialized successfully');
    } catch (error) {
      print('Failed to initialize SimpleAudioService: $error');
      throw Exception('Audio-System konnte nicht initialisiert werden');
    }
  }

  /// Set up audio player event listeners
  void _setupAudioListeners() {
    if (_audioPlayer == null) return;

    _audioPlayer!.durationStream.listen((duration) {
      _durationController.add(duration);
    });

    _audioPlayer!.positionStream.listen((position) {
      _positionController.add(position);
    });

    _audioPlayer!.playingStream.listen((playing) {
      _playingController.add(playing);
    });

    _audioPlayer!.processingStateStream.listen((state) {
      if (state == ja.ProcessingState.completed) {
        _handlePlaybackComplete();
      }
    });
  }

  void _handlePlaybackComplete() {
    // Auto-advance to next track when current track completes
    if (_currentIndex < _availableFiles.length - 1) {
      skipToNext();
    } else {
      // Reached end of playlist, stop and reset
      _audioPlayer?.seek(Duration.zero);
      _audioPlayer?.pause();
      _currentIndex = 0;
      HapticFeedback.lightImpact();
    }
  }

  /// Load available audio files from storage bucket
  Future<Map<String, dynamic>> _loadAvailableFiles() async {
    try {
      final client = SupabaseService.instance.client;

      // List all files in the therapy-audio bucket
      final response = await client.storage.from('therapy-audio').list();

      // Filter audio files only
      final audioFiles = response.where((file) {
        final name = file.name.toLowerCase() ?? '';
        return name.endsWith('.mp3') ||
            name.endsWith('.wav') ||
            name.endsWith('.m4a') ||
            name.endsWith('.aac') ||
            name.endsWith('.ogg') ||
            name.endsWith('.flac');
      }).toList();

      if (audioFiles.isEmpty) {
        return {
          'error': true,
          'message':
              'Keine Audio-Dateien im Storage gefunden. Laden Sie Songs in den therapy-audio Bucket hoch.',
        };
      }

      // Convert to simple format for playback
      _availableFiles = audioFiles.map((file) {
        final fileName = file.name ?? 'Unbekannter Song';
        final cleanTitle =
            fileName.replaceAll(RegExp(r'\.(mp3|wav|m4a|aac|ogg|flac)$'), '');

        return {
          'title': cleanTitle,
          'file_name': fileName,
          'file_path': fileName,
          'created_at': file.createdAt?.toString(),
          'size': file.metadata?['size'] ?? 0,
        };
      }).toList();

      return {
        'error': false,
        'files': _availableFiles,
        'count': _availableFiles.length,
      };
    } catch (error) {
      print('Error loading available files: $error');
      return {
        'error': true,
        'message': 'Fehler beim Laden der Audio-Dateien aus dem Storage',
      };
    }
  }

  /// Start playing audio from current index
  Future<Map<String, dynamic>> startTherapySession() async {
    try {
      await initialize();

      // Load available files from storage
      final loadResult = await _loadAvailableFiles();
      if (loadResult['error'] == true) {
        return loadResult;
      }

      if (_availableFiles.isEmpty) {
        return {
          'error': true,
          'message':
              'Keine Audio-Dateien verfügbar. Laden Sie Songs in den therapy-audio Storage hoch.',
        };
      }

      // Play first track
      return await _playTrackAtIndex(0);
    } catch (error) {
      print('Error starting therapy session: $error');
      return {
        'error': true,
        'message': 'Fehler beim Starten der Therapie-Sitzung',
      };
    }
  }

  /// Play track at specific index
  Future<Map<String, dynamic>> _playTrackAtIndex(int index) async {
    if (index < 0 || index >= _availableFiles.length) {
      return {
        'error': true,
        'message': 'Ungültiger Track-Index',
      };
    }

    try {
      final trackInfo = _availableFiles[index];
      final fileName = trackInfo['file_name'];
      final title = trackInfo['title'];

      // Create signed URL for the file
      final client = SupabaseService.instance.client;
      final signedUrlResponse = await client.storage
          .from('therapy-audio')
          .createSignedUrl(fileName, 3600); // 1 hour expiry

      if (signedUrlResponse.isEmpty) {
        return {
          'error': true,
          'message': 'Fehler beim Erstellen der Audio-URL',
        };
      }

      // Load and play the audio
      await _audioPlayer!.setUrl(signedUrlResponse);
      await _audioPlayer!.play();

      // Update state
      _currentIndex = index;
      _currentTrackTitle = title;
      _trackTitleController.add(title);

      HapticFeedback.mediumImpact();

      return {
        'error': false,
        'title': title,
        'index': index + 1, // 1-based for UI
        'total': _availableFiles.length,
        'message': 'Track wird abgespielt',
      };
    } catch (error) {
      print('Error playing track at index $index: $error');
      return {
        'error': true,
        'message': 'Fehler beim Abspielen des Tracks',
      };
    }
  }

  /// Skip to next track
  Future<Map<String, dynamic>> skipToNext() async {
    if (_availableFiles.isEmpty) {
      return {
        'error': true,
        'message': 'Keine Tracks verfügbar',
      };
    }

    final nextIndex = (_currentIndex + 1) % _availableFiles.length;
    return await _playTrackAtIndex(nextIndex);
  }

  /// Skip to previous track
  Future<Map<String, dynamic>> skipToPrevious() async {
    if (_availableFiles.isEmpty) {
      return {
        'error': true,
        'message': 'Keine Tracks verfügbar',
      };
    }

    final prevIndex =
        _currentIndex > 0 ? _currentIndex - 1 : _availableFiles.length - 1;
    return await _playTrackAtIndex(prevIndex);
  }

  /// Toggle play/pause
  Future<void> togglePlayPause() async {
    if (_audioPlayer == null) return;

    try {
      if (_audioPlayer!.playing) {
        await _audioPlayer!.pause();
      } else {
        await _audioPlayer!.play();
      }
      HapticFeedback.lightImpact();
    } catch (error) {
      print('Error toggling play/pause: $error');
    }
  }

  /// Stop playback
  Future<void> stop() async {
    if (_audioPlayer == null) return;

    try {
      await _audioPlayer!.stop();
      await _audioPlayer!.seek(Duration.zero);
      _currentTrackTitle = null;
      _trackTitleController.add(null);
      HapticFeedback.lightImpact();
    } catch (error) {
      print('Error stopping audio: $error');
    }
  }

  /// Seek to position
  Future<void> seek(Duration position) async {
    if (_audioPlayer == null) return;

    try {
      await _audioPlayer!.seek(position);
    } catch (error) {
      print('Error seeking audio: $error');
    }
  }

  /// Set volume
  Future<void> setVolume(double volume) async {
    if (_audioPlayer == null) return;

    try {
      await _audioPlayer!.setVolume(volume.clamp(0.0, 1.0));
    } catch (error) {
      print('Error setting volume: $error');
    }
  }

  /// Get list of available tracks for UI
  Future<List<Map<String, dynamic>>> getAvailableTracks() async {
    final loadResult = await _loadAvailableFiles();
    if (loadResult['error'] == true) {
      return [];
    }
    return _availableFiles;
  }

  /// Dispose resources
  Future<void> dispose() async {
    try {
      await _audioPlayer?.dispose();
      await _trackTitleController.close();
      await _durationController.close();
      await _positionController.close();
      await _playingController.close();

      _audioPlayer = null;
      _audioSession = null;
      _isInitialized = false;
      _availableFiles.clear();

      print('SimpleAudioService disposed successfully');
    } catch (error) {
      print('Error disposing SimpleAudioService: $error');
    }
  }
}
