import 'package:supabase_flutter/supabase_flutter.dart';

import './supabase_service.dart';

class UserService {
  static UserService? _instance;
  static UserService get instance => _instance ??= UserService._();
  UserService._();

  final SupabaseClient _client = SupabaseService.instance.client;

  // User Profile Management
  Future<Map<String, dynamic>?> getCurrentUserProfile() async {
    try {
      final userId = _client.auth.currentUser?.id;
      if (userId == null) return null;

      final response = await _client.from('user_profiles').select('''
            id, email, full_name, role, date_of_birth, phone_number, 
            avatar_url, medical_id, created_at, is_active
          ''').eq('id', userId).single();

      return response;
    } catch (error) {
      throw Exception('Failed to get user profile: $error');
    }
  }

  Future<Map<String, dynamic>> updateUserProfile({
    String? fullName,
    DateTime? dateOfBirth,
    String? phoneNumber,
    String? avatarUrl,
    String? medicalId,
  }) async {
    try {
      final userId = _client.auth.currentUser?.id;
      if (userId == null) throw Exception('User not authenticated');

      final updates = <String, dynamic>{};
      if (fullName != null) updates['full_name'] = fullName;
      if (dateOfBirth != null)
        updates['date_of_birth'] = dateOfBirth.toIso8601String().split('T')[0];
      if (phoneNumber != null) updates['phone_number'] = phoneNumber;
      if (avatarUrl != null) updates['avatar_url'] = avatarUrl;
      if (medicalId != null) updates['medical_id'] = medicalId;

      final response = await _client
          .from('user_profiles')
          .update(updates)
          .eq('id', userId)
          .select()
          .single();

      return response;
    } catch (error) {
      throw Exception('Failed to update user profile: $error');
    }
  }

  // Medical Profile Management
  Future<Map<String, dynamic>?> getMedicalProfile({String? userId}) async {
    try {
      final targetUserId = userId ?? _client.auth.currentUser?.id;
      if (targetUserId == null) return null;

      final response = await _client.from('medical_profiles').select('''
            id, tinnitus_onset_date, tinnitus_cause, hearing_loss_degree,
            affected_ear, dominant_frequency_hz, volume_level, medical_notes,
            created_at, updated_at
          ''').eq('user_id', targetUserId).single();

      return response;
    } catch (error) {
      if (error.toString().contains('PGRST301')) {
        return null; // No medical profile found
      }
      throw Exception('Failed to get medical profile: $error');
    }
  }

  Future<Map<String, dynamic>> createOrUpdateMedicalProfile({
    DateTime? tinnitusOnsetDate,
    String? tinnitusCause,
    String? hearingLossDegree,
    String? affectedEar,
    int? dominantFrequencyHz,
    int? volumeLevel,
    String? medicalNotes,
  }) async {
    try {
      final userId = _client.auth.currentUser?.id;
      if (userId == null) throw Exception('User not authenticated');

      final medicalData = {
        'user_id': userId,
        'tinnitus_onset_date':
            tinnitusOnsetDate?.toIso8601String().split('T')[0],
        'tinnitus_cause': tinnitusCause,
        'hearing_loss_degree': hearingLossDegree,
        'affected_ear': affectedEar,
        'dominant_frequency_hz': dominantFrequencyHz,
        'volume_level': volumeLevel,
        'medical_notes': medicalNotes,
      };

      // Remove null values
      medicalData.removeWhere((key, value) => value == null);

      final response = await _client
          .from('medical_profiles')
          .upsert(medicalData)
          .select()
          .single();

      return response;
    } catch (error) {
      throw Exception('Failed to save medical profile: $error');
    }
  }

  // License Management
  Future<Map<String, dynamic>?> getUserLicense({String? userId}) async {
    try {
      final targetUserId = userId ?? _client.auth.currentUser?.id;
      if (targetUserId == null) return null;

      final response = await _client
          .from('licenses')
          .select('''
            id, license_key, license_status, activated_at, expires_at,
            device_info, created_at
          ''')
          .eq('user_id', targetUserId)
          .order('created_at', ascending: false)
          .limit(1)
          .single();

      return response;
    } catch (error) {
      if (error.toString().contains('PGRST301')) {
        return null; // No license found
      }
      throw Exception('Failed to get user license: $error');
    }
  }

  Future<Map<String, dynamic>> activateLicense({
    required String licenseKey,
    Map<String, dynamic>? deviceInfo,
  }) async {
    try {
      final userId = _client.auth.currentUser?.id;
      if (userId == null) throw Exception('User not authenticated');

      // First check if license exists and is valid
      final existingLicense = await _client
          .from('licenses')
          .select('id, license_status, user_id')
          .eq('license_key', licenseKey)
          .single();

      if (existingLicense['license_status'] == 'active' &&
          existingLicense['user_id'] != userId) {
        throw Exception('License already activated by another user');
      }

      // Activate the license
      final activationData = {
        'user_id': userId,
        'license_status': 'active',
        'activated_at': DateTime.now().toIso8601String(),
        'expires_at':
            DateTime.now().add(const Duration(days: 365)).toIso8601String(),
        'device_info': deviceInfo,
      };

      final response = await _client
          .from('licenses')
          .update(activationData)
          .eq('license_key', licenseKey)
          .select()
          .single();

      return response;
    } catch (error) {
      throw Exception('Failed to activate license: $error');
    }
  }

  // User Documents
  Future<List<Map<String, dynamic>>> getUserDocuments({
    String? userId,
    bool? medicalRecordsOnly,
  }) async {
    try {
      final targetUserId = userId ?? _client.auth.currentUser?.id;
      if (targetUserId == null) return [];

      var query = _client.from('user_documents').select('''
        id, document_name, document_type, file_path, file_size_bytes,
        uploaded_at, is_medical_record
      ''');

      query = query.eq('user_id', targetUserId);

      if (medicalRecordsOnly == true) {
        query = query.eq('is_medical_record', true);
      }

      return await query.order('uploaded_at', ascending: false);
    } catch (error) {
      throw Exception('Failed to get user documents: $error');
    }
  }

  Future<Map<String, dynamic>> uploadDocument({
    required String documentName,
    required String documentType,
    required String filePath,
    int? fileSizeBytes,
    bool isMedicalRecord = false,
  }) async {
    try {
      final userId = _client.auth.currentUser?.id;
      if (userId == null) throw Exception('User not authenticated');

      final documentData = {
        'user_id': userId,
        'document_name': documentName,
        'document_type': documentType,
        'file_path': filePath,
        'file_size_bytes': fileSizeBytes,
        'is_medical_record': isMedicalRecord,
        'uploaded_at': DateTime.now().toIso8601String(),
      };

      final response = await _client
          .from('user_documents')
          .insert(documentData)
          .select()
          .single();

      return response;
    } catch (error) {
      throw Exception('Failed to upload document: $error');
    }
  }

  Future<void> deleteDocument(String documentId) async {
    try {
      await _client.from('user_documents').delete().eq('id', documentId);
    } catch (error) {
      throw Exception('Failed to delete document: $error');
    }
  }

  // Authentication helpers
  Future<bool> isUserDoctor({String? userId}) async {
    try {
      final targetUserId = userId ?? _client.auth.currentUser?.id;
      if (targetUserId == null) return false;

      final response = await _client
          .from('user_profiles')
          .select('role')
          .eq('id', targetUserId)
          .single();

      return response['role'] == 'doctor';
    } catch (error) {
      return false;
    }
  }

  Future<bool> isUserAdmin({String? userId}) async {
    try {
      final targetUserId = userId ?? _client.auth.currentUser?.id;
      if (targetUserId == null) return false;

      final response = await _client
          .from('user_profiles')
          .select('role')
          .eq('id', targetUserId)
          .single();

      return response['role'] == 'admin';
    } catch (error) {
      return false;
    }
  }

  Future<List<Map<String, dynamic>>> getAllUsers({
    String? role,
    bool activeOnly = true,
  }) async {
    try {
      // Only doctors and admins can access this
      final currentUser = await getCurrentUserProfile();
      if (currentUser == null ||
          !['doctor', 'admin'].contains(currentUser['role'])) {
        throw Exception('Insufficient permissions');
      }

      var query = _client.from('user_profiles').select('''
        id, email, full_name, role, created_at, is_active
      ''');

      if (role != null) {
        query = query.eq('role', role);
      }

      if (activeOnly) {
        query = query.eq('is_active', true);
      }

      return await query.order('created_at', ascending: false);
    } catch (error) {
      throw Exception('Failed to get all users: $error');
    }
  }

  // Real-time subscription for user profile changes
  RealtimeChannel subscribeToUserProfile({
    required Function(Map<String, dynamic>) onProfileUpdate,
  }) {
    final userId = _client.auth.currentUser?.id;
    if (userId == null) throw Exception('User not authenticated');

    return _client
        .channel('user_profile_channel')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'user_profiles',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'id',
            value: userId,
          ),
          callback: (payload) {
            onProfileUpdate(payload.newRecord);
          },
        )
        .subscribe();
  }
}
