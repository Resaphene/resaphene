import 'package:supabase_flutter/supabase_flutter.dart';
import './supabase_service.dart';

class SubscriptionService {
  static SubscriptionService? _instance;
  static SubscriptionService get instance =>
      _instance ??= SubscriptionService._();
  SubscriptionService._();

  final SupabaseClient _client = SupabaseService.instance.client;

  // Get current user's subscription status
  Future<Map<String, dynamic>?> getSubscriptionStatus() async {
    try {
      final user = _client.auth.currentUser;
      if (user == null) return null;

      final response = await _client
          .rpc('check_trial_status', params: {'user_uuid': user.id});

      if (response is List && response.isNotEmpty) {
        return response.first as Map<String, dynamic>;
      }
      return response as Map<String, dynamic>?;
    } catch (error) {
      throw Exception('Failed to get subscription status: $error');
    }
  }

  // Check if user has active trial
  Future<bool> hasActiveTrial() async {
    try {
      final status = await getSubscriptionStatus();
      if (status == null) return false;

      return status['status'] == 'trial' &&
          (status['trial_remaining_days'] as int) > 0;
    } catch (error) {
      return false;
    }
  }

  // Check if user has active subscription (trial or premium)
  Future<bool> hasActiveAccess() async {
    try {
      final status = await getSubscriptionStatus();
      if (status == null) return false;

      return status['can_access_premium'] as bool? ?? false;
    } catch (error) {
      return false;
    }
  }

  // Get trial remaining days
  Future<int> getTrialRemainingDays() async {
    try {
      final status = await getSubscriptionStatus();
      if (status == null) return 0;

      return status['trial_remaining_days'] as int? ?? 0;
    } catch (error) {
      return 0;
    }
  }

  // Activate trial for current user
  Future<void> activateTrial() async {
    try {
      final user = _client.auth.currentUser;
      if (user == null) throw Exception('No authenticated user');

      await _client
          .rpc('activate_trial_for_user', params: {'user_uuid': user.id});
    } catch (error) {
      throw Exception('Failed to activate trial: $error');
    }
  }

  // Upgrade to premium subscription
  Future<void> upgradeToPremium({
    String? stripeCustomerId,
    String? stripeSubscriptionId,
  }) async {
    try {
      final user = _client.auth.currentUser;
      if (user == null) throw Exception('No authenticated user');

      await _client.rpc('upgrade_to_premium', params: {
        'user_uuid': user.id,
        'stripe_customer_id_param': stripeCustomerId,
        'stripe_subscription_id_param': stripeSubscriptionId,
      });
    } catch (error) {
      throw Exception('Failed to upgrade to premium: $error');
    }
  }

  // Get subscription details
  Future<Map<String, dynamic>?> getSubscriptionDetails() async {
    try {
      final user = _client.auth.currentUser;
      if (user == null) return null;

      final response = await _client
          .from('user_subscriptions')
          .select('*')
          .eq('user_id', user.id)
          .order('created_at', ascending: false)
          .limit(1)
          .maybeSingle();

      return response;
    } catch (error) {
      throw Exception('Failed to get subscription details: $error');
    }
  }

  // Check if user needs to upgrade (trial expired or no access)
  Future<bool> needsUpgrade() async {
    try {
      final status = await getSubscriptionStatus();
      if (status == null) return true;

      return !(status['can_access_premium'] as bool? ?? false);
    } catch (error) {
      return true;
    }
  }

  // Get subscription status text for UI
  Future<String> getStatusDisplayText() async {
    try {
      final status = await getSubscriptionStatus();
      if (status == null) return 'Kein Zugang';

      final statusValue = status['status'] as String;
      final remainingDays = status['trial_remaining_days'] as int? ?? 0;

      switch (statusValue) {
        case 'trial':
          if (remainingDays > 0) {
            return 'Testversion ($remainingDays Tage verbleibend)';
          } else {
            return 'Testversion abgelaufen';
          }
        case 'active':
          return 'Premium Abo';
        case 'trial_expired':
          return 'Testversion abgelaufen';
        case 'expired':
          return 'Abo abgelaufen';
        case 'canceled':
          return 'Abo gekündigt';
        default:
          return 'Status unbekannt';
      }
    } catch (error) {
      return 'Fehler beim Laden';
    }
  }

  // Cancel subscription
  Future<void> cancelSubscription() async {
    try {
      final user = _client.auth.currentUser;
      if (user == null) throw Exception('No authenticated user');

      await _client.from('user_subscriptions').update({
        'subscription_status': 'canceled',
        'updated_at': DateTime.now().toIso8601String(),
      }).eq('user_id', user.id);
    } catch (error) {
      throw Exception('Failed to cancel subscription: $error');
    }
  }

  // Reactivate subscription
  Future<void> reactivateSubscription() async {
    try {
      final user = _client.auth.currentUser;
      if (user == null) throw Exception('No authenticated user');

      await _client.from('user_subscriptions').update({
        'subscription_status': 'active',
        'updated_at': DateTime.now().toIso8601String(),
      }).eq('user_id', user.id);
    } catch (error) {
      throw Exception('Failed to reactivate subscription: $error');
    }
  }
}
