import 'package:supabase_flutter/supabase_flutter.dart';

import './supabase_service.dart';

class TherapyService {
  static TherapyService? _instance;
  static TherapyService get instance => _instance ??= TherapyService._();
  TherapyService._();

  final SupabaseClient _client = SupabaseService.instance.client;

  // Therapy Sessions
  Future<List<Map<String, dynamic>>> getTherapySessions({
    String? userId,
    int? limit,
    String? status,
  }) async {
    try {
      var query = _client.from('therapy_sessions').select('''
        id, therapy_mode, frequency_hz, intensity_level, duration_minutes,
        session_status, started_at, completed_at, effectiveness_rating, notes
      ''');

      if (userId != null) {
        query = query.eq('user_id', userId);
      }

      if (status != null) {
        query = query.eq('session_status', status);
      }

      if (limit != null) {
        return await query.order('started_at', ascending: false).limit(limit);
      }

      return await query.order('started_at', ascending: false);
    } catch (error) {
      throw Exception('Failed to fetch therapy sessions: $error');
    }
  }

  Future<Map<String, dynamic>> createTherapySession({
    required String therapyMode,
    required int frequencyHz,
    required int intensityLevel,
    required int durationMinutes,
    String? notes,
  }) async {
    try {
      final session = {
        'user_id': _client.auth.currentUser?.id,
        'therapy_mode': therapyMode,
        'frequency_hz': frequencyHz,
        'intensity_level': intensityLevel,
        'duration_minutes': durationMinutes,
        'session_status': 'active',
        'started_at': DateTime.now().toIso8601String(),
        'notes': notes,
      };

      final response = await _client
          .from('therapy_sessions')
          .insert(session)
          .select()
          .single();

      return response;
    } catch (error) {
      throw Exception('Failed to create therapy session: $error');
    }
  }

  Future<Map<String, dynamic>> completeTherapySession({
    required String sessionId,
    required int effectivenessRating,
    String? notes,
  }) async {
    try {
      final updates = {
        'session_status': 'completed',
        'completed_at': DateTime.now().toIso8601String(),
        'effectiveness_rating': effectivenessRating,
        'notes': notes,
      };

      final response = await _client
          .from('therapy_sessions')
          .update(updates)
          .eq('id', sessionId)
          .select()
          .single();

      return response;
    } catch (error) {
      throw Exception('Failed to complete therapy session: $error');
    }
  }

  // Symptom Logs
  Future<List<Map<String, dynamic>>> getSymptomLogs({
    String? userId,
    int? limit,
    DateTime? startDate,
    DateTime? endDate,
  }) async {
    try {
      var query = _client.from('symptom_logs').select('''
        id, severity_level, symptoms_description, mood_before, mood_after,
        triggers, environmental_factors, logged_at
      ''');

      if (userId != null) {
        query = query.eq('user_id', userId);
      }

      if (startDate != null) {
        query = query.gte('logged_at', startDate.toIso8601String());
      }

      if (endDate != null) {
        query = query.lte('logged_at', endDate.toIso8601String());
      }

      if (limit != null) {
        return await query.order('logged_at', ascending: false).limit(limit);
      }

      return await query.order('logged_at', ascending: false);
    } catch (error) {
      throw Exception('Failed to fetch symptom logs: $error');
    }
  }

  Future<Map<String, dynamic>> logSymptom({
    required int severityLevel,
    required String symptomsDescription,
    int? moodBefore,
    int? moodAfter,
    String? triggers,
    String? environmentalFactors,
  }) async {
    try {
      final symptomLog = {
        'user_id': _client.auth.currentUser?.id,
        'severity_level': severityLevel,
        'symptoms_description': symptomsDescription,
        'mood_before': moodBefore,
        'mood_after': moodAfter,
        'triggers': triggers,
        'environmental_factors': environmentalFactors,
        'logged_at': DateTime.now().toIso8601String(),
      };

      final response = await _client
          .from('symptom_logs')
          .insert(symptomLog)
          .select()
          .single();

      return response;
    } catch (error) {
      throw Exception('Failed to log symptom: $error');
    }
  }

  // Treatment Plans
  Future<List<Map<String, dynamic>>> getTreatmentPlans({String? userId}) async {
    try {
      var query = _client.from('treatment_plans').select('''
        id, plan_name, recommended_frequency_hz, recommended_intensity,
        recommended_duration_minutes, recommended_therapy_mode,
        sessions_per_week, plan_duration_weeks, special_instructions,
        is_active, created_at
      ''');

      if (userId != null) {
        query = query.eq('user_id', userId);
      }

      return await query
          .eq('is_active', true)
          .order('created_at', ascending: false);
    } catch (error) {
      throw Exception('Failed to fetch treatment plans: $error');
    }
  }

  // Progress Statistics
  Future<Map<String, dynamic>> getProgressStatistics({
    String? userId,
    DateTime? date,
  }) async {
    try {
      var query = _client.from('progress_statistics').select('''
        total_sessions_count, average_session_duration, average_effectiveness_rating,
        symptom_improvement_percentage, compliance_rate, date_recorded
      ''');

      if (userId != null) {
        query = query.eq('user_id', userId);
      }

      if (date != null) {
        query = query.eq('date_recorded', date.toIso8601String().split('T')[0]);
      }

      final response = await query.single();
      return response;
    } catch (error) {
      // Return default statistics if none found
      return {
        'total_sessions_count': 0,
        'average_session_duration': 0.0,
        'average_effectiveness_rating': 0.0,
        'symptom_improvement_percentage': 0.0,
        'compliance_rate': 0.0,
        'date_recorded': DateTime.now().toIso8601String().split('T')[0],
      };
    }
  }

  Future<Map<String, dynamic>> updateProgressStatistics({
    required int totalSessionsCount,
    required double averageSessionDuration,
    required double averageEffectivenessRating,
    required double symptomImprovementPercentage,
    required double complianceRate,
  }) async {
    try {
      final userId = _client.auth.currentUser?.id;
      final today = DateTime.now().toIso8601String().split('T')[0];

      final statisticsData = {
        'user_id': userId,
        'date_recorded': today,
        'total_sessions_count': totalSessionsCount,
        'average_session_duration': averageSessionDuration,
        'average_effectiveness_rating': averageEffectivenessRating,
        'symptom_improvement_percentage': symptomImprovementPercentage,
        'compliance_rate': complianceRate,
      };

      // Try to update existing record, insert if not exists
      final response = await _client
          .from('progress_statistics')
          .upsert(statisticsData)
          .select()
          .single();

      return response;
    } catch (error) {
      throw Exception('Failed to update progress statistics: $error');
    }
  }

  // Analytics Methods
  Future<Map<String, dynamic>> getWeeklySessionData({String? userId}) async {
    try {
      final endDate = DateTime.now();
      final startDate = endDate.subtract(const Duration(days: 7));

      var query = _client
          .from('therapy_sessions')
          .select('started_at, duration_minutes');

      if (userId != null) {
        query = query.eq('user_id', userId);
      }

      final sessions = await query
          .gte('started_at', startDate.toIso8601String())
          .lte('started_at', endDate.toIso8601String())
          .order('started_at');

      // Process data for weekly chart
      Map<String, int> weeklyData = {
        'Mo': 0,
        'Di': 0,
        'Mi': 0,
        'Do': 0,
        'Fr': 0,
        'Sa': 0,
        'So': 0
      };

      for (var session in sessions) {
        final date = DateTime.parse(session['started_at']);
        final weekday =
            ['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'][date.weekday - 1];
        weeklyData[weekday] = (weeklyData[weekday] ?? 0) + 1;
      }

      return {'weekly_sessions': weeklyData};
    } catch (error) {
      throw Exception('Failed to get weekly session data: $error');
    }
  }

  Future<Map<String, dynamic>> getSymptomTrendData({String? userId}) async {
    try {
      final endDate = DateTime.now();
      final startDate = endDate.subtract(const Duration(days: 14));

      var query =
          _client.from('symptom_logs').select('severity_level, logged_at');

      if (userId != null) {
        query = query.eq('user_id', userId);
      }

      final logs = await query
          .gte('logged_at', startDate.toIso8601String())
          .lte('logged_at', endDate.toIso8601String())
          .order('logged_at');

      // Process data for trend analysis
      List<Map<String, dynamic>> trendData = [];
      for (var log in logs.take(14)) {
        final date = DateTime.parse(log['logged_at']);
        trendData.add({
          'date':
              '${date.day.toString().padLeft(2, '0')}.${date.month.toString().padLeft(2, '0')}',
          'severity': log['severity_level'],
        });
      }

      return {'symptom_trend': trendData};
    } catch (error) {
      throw Exception('Failed to get symptom trend data: $error');
    }
  }

  Future<Map<String, dynamic>> getTherapyModeDistribution(
      {String? userId}) async {
    try {
      var query = _client.from('therapy_sessions').select('therapy_mode');

      if (userId != null) {
        query = query.eq('user_id', userId);
      }

      final sessions = await query.eq('session_status', 'completed');

      // Count therapy modes
      Map<String, int> modeCount = {
        'Ausblendung': 0,
        'Überlagerung': 0,
        'Gegentakt': 0,
      };

      for (var session in sessions) {
        final mode = session['therapy_mode'];
        switch (mode) {
          case 'ausblendung':
            modeCount['Ausblendung'] = (modeCount['Ausblendung'] ?? 0) + 1;
            break;
          case 'ueberlagerung':
            modeCount['Überlagerung'] = (modeCount['Überlagerung'] ?? 0) + 1;
            break;
          case 'gegentakt':
            modeCount['Gegentakt'] = (modeCount['Gegentakt'] ?? 0) + 1;
            break;
        }
      }

      return {'mode_distribution': modeCount};
    } catch (error) {
      throw Exception('Failed to get therapy mode distribution: $error');
    }
  }

  // Real-time subscription for therapy sessions
  RealtimeChannel subscribeToTherapySessions({
    required Function(Map<String, dynamic>) onSessionUpdate,
  }) {
    return _client
        .channel('therapy_sessions_channel')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'therapy_sessions',
          callback: (payload) {
            onSessionUpdate(payload.newRecord);
          },
        )
        .subscribe();
  }

  // ============================================================================
  // THERAPY AUDIO TRACKS MANAGEMENT - UPDATED FOR AUTOMATIC AVAILABILITY
  // ============================================================================

  /// Get all available therapy audio tracks (no admin approval needed)
  Future<List<Map<String, dynamic>>> getAvailableAudioTracks() async {
    try {
      return await _client
          .from('tracks')
          .select('id, title, duration_sec, created_at, storage_path')
          .order('created_at', ascending: true);
    } catch (error) {
      throw Exception('Failed to fetch available audio tracks: $error');
    }
  }

  /// Get any available track for therapy (automatic selection)
  Future<Map<String, dynamic>?> getActiveAudioTrack() async {
    try {
      final result = await _client.rpc('get_active_track_info').single();
      return {
        'id': result['track_id'],
        'title': result['title'],
        'duration_sec': result['duration_sec'],
        'storage_path': result['storage_path'],
      };
    } catch (error) {
      print('Error getting active audio track: $error');
      return null;
    }
  }

  /// Get random track for variety (no admin control needed)
  Future<Map<String, dynamic>?> getRandomAudioTrack() async {
    try {
      final result = await _client.rpc('get_random_available_track').single();
      return {
        'id': result['track_id'],
        'title': result['title'],
        'duration_sec': result['duration_sec'],
        'storage_path': result['storage_path'],
      };
    } catch (error) {
      print('Error getting random audio track: $error');
      return null;
    }
  }

  /// Skip to next track (automatic, no admin control)
  Future<Map<String, dynamic>> skipToNextTrack() async {
    try {
      final result = await _client.rpc('skip_to_next_track').single();
      return {
        'success': result['success'] ?? false,
        'title': result['title'],
        'storage_path': result['storage_path'],
        'duration_sec': result['duration_sec'],
        'message': result['message'] ?? 'Track changed',
      };
    } catch (error) {
      print('Error skipping to next track: $error');
      return {
        'success': false,
        'title': null,
        'storage_path': null,
        'duration_sec': null,
        'message': 'Error changing track: $error',
      };
    }
  }

  /// Skip to previous track (automatic, no admin control)
  Future<Map<String, dynamic>> skipToPreviousTrack() async {
    try {
      final result = await _client.rpc('skip_to_previous_track').single();
      return {
        'success': result['success'] ?? false,
        'title': result['title'],
        'storage_path': result['storage_path'],
        'duration_sec': result['duration_sec'],
        'message': result['message'] ?? 'Track changed',
      };
    } catch (error) {
      print('Error skipping to previous track: $error');
      return {
        'success': false,
        'title': null,
        'storage_path': null,
        'duration_sec': null,
        'message': 'Error changing track: $error',
      };
    }
  }

  /// Check if current user has admin privileges (kept for other admin functions)
  Future<bool> isAudioTrackAdmin() async {
    try {
      final user = _client.auth.currentUser;
      if (user == null) return false;

      final profile = await _client
          .from('user_profiles')
          .select('role')
          .eq('id', user.id)
          .single();

      return profile['role'] == 'admin';
    } catch (error) {
      print('Error checking admin privileges: $error');
      return false;
    }
  }

  /// Get therapy audio tracks statistics (updated for automatic availability)
  Future<Map<String, dynamic>> getAudioTracksStatistics() async {
    try {
      final tracks = await getAvailableAudioTracks();

      int totalDuration = 0;
      for (var track in tracks) {
        totalDuration += (track['duration_sec'] as num?)?.toInt() ?? 0;
      }

      return {
        'total_tracks': tracks.length,
        'total_duration_minutes': (totalDuration / 60).round(),
        'all_tracks_available': true, // No admin activation needed
        'tracks_list': tracks
            .map((track) => {
                  'id': track['id'],
                  'title': track['title'],
                  'duration_minutes':
                      ((track['duration_sec'] as num?)?.toInt() ?? 0 / 60)
                          .round(),
                  'is_available': true, // All tracks are always available
                })
            .toList(),
      };
    } catch (error) {
      throw Exception('Failed to get audio tracks statistics: $error');
    }
  }

  /// Check if any tracks are available in the system
  Future<bool> hasAvailableTracks() async {
    try {
      final result = await _client.rpc('has_available_tracks').single();
      return result == true;
    } catch (error) {
      print('Error checking available tracks: $error');
      return false;
    }
  }

  /// Get total track count
  Future<int> getTrackCount() async {
    try {
      final result = await _client.rpc('get_track_count').single();
      return (result as num?)?.toInt() ?? 0;
    } catch (error) {
      print('Error getting track count: $error');
      return 0;
    }
  }

  /// DEPRECATED: setActiveAudioTrack is no longer needed
  /// All tracks are automatically available
  @Deprecated(
      'All tracks are now automatically available. Use getRandomAudioTrack() or getActiveAudioTrack() instead.')
  Future<bool> setActiveAudioTrack(String trackId) async {
    // Return true to maintain compatibility but track selection is now automatic
    print(
        'setActiveAudioTrack is deprecated. All tracks are automatically available.');
    return true;
  }

  /// DEPRECATED: getAudioAdminSettings no longer relevant
  /// All tracks are automatically available without admin settings
  @Deprecated('Admin settings for track activation are no longer needed.')
  Future<Map<String, dynamic>?> getAudioAdminSettings() async {
    print(
        'Admin settings for track activation are no longer needed. All tracks are automatically available.');
    return null;
  }
}
