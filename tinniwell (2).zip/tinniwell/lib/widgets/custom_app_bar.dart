import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

/// Custom app bar widget implementing Clinical Minimalism design
/// for tinnitus therapy application with therapeutic calm aesthetics
class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final List<Widget>? actions;
  final Widget? leading;
  final bool centerTitle;
  final bool showBackButton;
  final VoidCallback? onBackPressed;
  final Color? backgroundColor;
  final Color? foregroundColor;
  final double elevation;
  final bool showShadow;
  final PreferredSizeWidget? bottom;

  const CustomAppBar({
    super.key,
    required this.title,
    this.actions,
    this.leading,
    this.centerTitle = true,
    this.showBackButton = true,
    this.onBackPressed,
    this.backgroundColor,
    this.foregroundColor,
    this.elevation = 0,
    this.showShadow = false,
    this.bottom,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final isDark = theme.brightness == Brightness.dark;

    // Use theme colors with clinical minimalism approach
    final effectiveBackgroundColor = backgroundColor ??
        (isDark ? const Color(0xFF1A1F24) : const Color(0xFFFFFFFF));
    final effectiveForegroundColor = foregroundColor ??
        (isDark ? const Color(0xFFE8E9EA) : const Color(0xFF1A1A1A));

    return AppBar(
      title: Text(
        title,
        style: GoogleFonts.inter(
          fontSize: 18,
          fontWeight: FontWeight.w600,
          color: effectiveForegroundColor,
          letterSpacing: -0.2,
          height: 1.22,
        ),
      ),
      centerTitle: centerTitle,
      backgroundColor: effectiveBackgroundColor,
      foregroundColor: effectiveForegroundColor,
      elevation: showShadow ? elevation : 0,
      shadowColor: isDark ? const Color(0x1A000000) : const Color(0x0A000000),
      surfaceTintColor: Colors.transparent,

      // Leading widget with back button logic
      leading: leading ??
          (showBackButton && Navigator.canPop(context)
              ? IconButton(
                  icon: Icon(
                    Icons.arrow_back_ios_new_rounded,
                    size: 20,
                    color: effectiveForegroundColor,
                  ),
                  onPressed: onBackPressed ?? () => Navigator.pop(context),
                  tooltip: 'Zurück', // German localization
                  splashRadius: 20,
                )
              : null),

      // Actions with proper spacing and clinical design
      actions: actions?.map((action) {
        if (action is IconButton) {
          return Padding(
            padding: const EdgeInsets.only(right: 8.0),
            child: IconButton(
              icon: action.icon,
              onPressed: action.onPressed,
              tooltip: action.tooltip,
              splashRadius: 20,
              iconSize: 24,
              color: effectiveForegroundColor,
            ),
          );
        }
        return Padding(
          padding: const EdgeInsets.only(right: 16.0),
          child: action,
        );
      }).toList(),

      // System UI overlay style for status bar
      systemOverlayStyle: SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: isDark ? Brightness.light : Brightness.dark,
        statusBarBrightness: isDark ? Brightness.dark : Brightness.light,
      ),

      bottom: bottom,
    );
  }

  @override
  Size get preferredSize => Size.fromHeight(
        kToolbarHeight + (bottom?.preferredSize.height ?? 0.0),
      );

  /// Factory constructor for therapy dashboard app bar
  factory CustomAppBar.therapyDashboard(BuildContext context) {
    return CustomAppBar(
      title: 'Therapie Dashboard',
      showBackButton: false,
      actions: [
        IconButton(
          icon: const Icon(Icons.settings_outlined),
          onPressed: () => Navigator.pushNamed(context, '/user-profile-screen'),
          tooltip: 'Einstellungen',
        ),
        IconButton(
          icon: const Icon(Icons.notifications_outlined),
          onPressed: () {
            // Show therapy reminders or notifications
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('Keine neuen Benachrichtigungen'),
                duration: Duration(seconds: 2),
              ),
            );
          },
          tooltip: 'Benachrichtigungen',
        ),
      ],
    );
  }

  /// Factory constructor for progress tracking app bar
  factory CustomAppBar.progressTracking(BuildContext context) {
    return CustomAppBar(
      title: 'Fortschritt',
      actions: [
        IconButton(
          icon: const Icon(Icons.share_outlined),
          onPressed: () {
            // Share progress with healthcare provider
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('Fortschritt wird geteilt...'),
                duration: Duration(seconds: 2),
              ),
            );
          },
          tooltip: 'Teilen',
        ),
        IconButton(
          icon: const Icon(Icons.download_outlined),
          onPressed: () {
            // Export progress data
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('Daten werden exportiert...'),
                duration: Duration(seconds: 2),
              ),
            );
          },
          tooltip: 'Exportieren',
        ),
      ],
    );
  }

  /// Factory constructor for user profile app bar
  factory CustomAppBar.userProfile(BuildContext context) {
    return CustomAppBar(
      title: 'Profil',
      actions: [
        IconButton(
          icon: const Icon(Icons.edit_outlined),
          onPressed: () {
            // Edit profile functionality
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('Profil bearbeiten...'),
                duration: Duration(seconds: 2),
              ),
            );
          },
          tooltip: 'Bearbeiten',
        ),
      ],
    );
  }

  /// Factory constructor for login screen app bar
  factory CustomAppBar.login(BuildContext context) {
    return const CustomAppBar(
      title: 'Anmelden',
      showBackButton: false,
      centerTitle: true,
    );
  }

  /// Factory constructor for license activation app bar
  factory CustomAppBar.licenseActivation(BuildContext context) {
    return const CustomAppBar(
      title: 'Lizenz aktivieren',
      centerTitle: true,
    );
  }
}
