import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

/// Navigation item data class for bottom navigation
class BottomNavItem {
  final IconData icon;
  final IconData? activeIcon;
  final String label;
  final String route;

  const BottomNavItem({
    required this.icon,
    this.activeIcon,
    required this.label,
    required this.route,
  });
}

/// Custom bottom navigation bar implementing Clinical Minimalism design
/// for tinnitus therapy application with therapeutic calm aesthetics
class CustomBottomBar extends StatelessWidget {
  final int currentIndex;
  final Function(int)? onTap;
  final Color? backgroundColor;
  final Color? selectedItemColor;
  final Color? unselectedItemColor;
  final double elevation;
  final bool showLabels;

  const CustomBottomBar({
    super.key,
    required this.currentIndex,
    this.onTap,
    this.backgroundColor,
    this.selectedItemColor,
    this.unselectedItemColor,
    this.elevation = 4.0,
    this.showLabels = true,
  });

  // Hardcoded navigation items for tinnitus therapy app
  static const List<BottomNavItem> _navItems = [
    BottomNavItem(
      icon: Icons.dashboard_outlined,
      activeIcon: Icons.dashboard_rounded,
      label: 'Dashboard',
      route: '/therapy-dashboard',
    ),
    BottomNavItem(
      icon: Icons.trending_up_outlined,
      activeIcon: Icons.trending_up_rounded,
      label: 'Fortschritt',
      route: '/progress-tracking-screen',
    ),
    BottomNavItem(
      icon: Icons.person_outline_rounded,
      activeIcon: Icons.person_rounded,
      label: 'Profil',
      route: '/user-profile-screen',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final isDark = theme.brightness == Brightness.dark;

    // Clinical minimalism color scheme
    final effectiveBackgroundColor = backgroundColor ??
        (isDark ? const Color(0xFF1A1F24) : const Color(0xFFFFFFFF));
    final effectiveSelectedColor = selectedItemColor ??
        (isDark ? const Color(0xFF4A90A4) : const Color(0xFF2B5A87));
    final effectiveUnselectedColor = unselectedItemColor ??
        (isDark ? const Color(0xFFD1D5DB) : const Color(0xFF6B7280));

    return Container(
      decoration: BoxDecoration(
        color: effectiveBackgroundColor,
        boxShadow: [
          BoxShadow(
            color: isDark ? const Color(0x1A000000) : const Color(0x0A000000),
            offset: const Offset(0, -1),
            blurRadius: elevation,
            spreadRadius: 0,
          ),
        ],
      ),
      child: SafeArea(
        child: Container(
          height: 72, // Optimized height for therapy app
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: _navItems.asMap().entries.map((entry) {
              final index = entry.key;
              final item = entry.value;
              final isSelected = index == currentIndex;

              return Expanded(
                child: _BottomNavButton(
                  item: item,
                  isSelected: isSelected,
                  selectedColor: effectiveSelectedColor,
                  unselectedColor: effectiveUnselectedColor,
                  showLabel: showLabels,
                  onTap: () => _handleNavigation(context, index, item.route),
                ),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }

  void _handleNavigation(BuildContext context, int index, String route) {
    // Provide haptic feedback for therapy app interactions
    HapticFeedback.lightImpact();

    // Call the onTap callback if provided
    onTap?.call(index);

    // Navigate to the selected route
    if (ModalRoute.of(context)?.settings.name != route) {
      Navigator.pushNamedAndRemoveUntil(
        context,
        route,
        (route) => false, // Clear navigation stack for main tabs
      );
    }
  }
}

/// Individual bottom navigation button widget
class _BottomNavButton extends StatelessWidget {
  final BottomNavItem item;
  final bool isSelected;
  final Color selectedColor;
  final Color unselectedColor;
  final bool showLabel;
  final VoidCallback onTap;

  const _BottomNavButton({
    required this.item,
    required this.isSelected,
    required this.selectedColor,
    required this.unselectedColor,
    required this.showLabel,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final effectiveColor = isSelected ? selectedColor : unselectedColor;
    final effectiveIcon =
        isSelected && item.activeIcon != null ? item.activeIcon! : item.icon;

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      splashColor: selectedColor.withValues(alpha: 0.1),
      highlightColor: selectedColor.withValues(alpha: 0.05),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Icon with smooth transition
            AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              curve: Curves.easeInOut,
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                color: isSelected
                    ? selectedColor.withValues(alpha: 0.1)
                    : Colors.transparent,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(
                effectiveIcon,
                size: 24,
                color: effectiveColor,
              ),
            ),

            // Label with fade transition
            if (showLabel) ...[
              const SizedBox(height: 4),
              AnimatedDefaultTextStyle(
                duration: const Duration(milliseconds: 200),
                style: GoogleFonts.inter(
                  fontSize: 12,
                  fontWeight: isSelected ? FontWeight.w500 : FontWeight.w400,
                  color: effectiveColor,
                  letterSpacing: 0.1,
                  height: 1.0,
                ),
                child: Text(
                  item.label,
                  textAlign: TextAlign.center,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

/// Extension to get current route index for bottom navigation
extension CustomBottomBarExtension on CustomBottomBar {
  static int getIndexForRoute(String? routeName) {
    if (routeName == null) return 0;

    for (int i = 0; i < CustomBottomBar._navItems.length; i++) {
      if (CustomBottomBar._navItems[i].route == routeName) {
        return i;
      }
    }
    return 0; // Default to dashboard
  }

  static bool shouldShowBottomBar(String? routeName) {
    if (routeName == null) return false;

    const mainRoutes = [
      '/therapy-dashboard',
      '/progress-tracking-screen',
      '/user-profile-screen',
    ];

    return mainRoutes.contains(routeName);
  }
}
