class SymptomLog {
  final String id;
  final String userId;
  final int severityLevel;
  final String symptomsDescription;
  final int? moodBefore;
  final int? moodAfter;
  final String? triggers;
  final String? environmentalFactors;
  final DateTime loggedAt;

  SymptomLog({
    required this.id,
    required this.userId,
    required this.severityLevel,
    required this.symptomsDescription,
    this.moodBefore,
    this.moodAfter,
    this.triggers,
    this.environmentalFactors,
    required this.loggedAt,
  });

  factory SymptomLog.fromJson(Map<String, dynamic> json) {
    return SymptomLog(
      id: json['id'] as String,
      userId: json['user_id'] as String,
      severityLevel: json['severity_level'] as int,
      symptomsDescription: json['symptoms_description'] as String,
      moodBefore: json['mood_before'] as int?,
      moodAfter: json['mood_after'] as int?,
      triggers: json['triggers'] as String?,
      environmentalFactors: json['environmental_factors'] as String?,
      loggedAt: DateTime.parse(json['logged_at'] as String),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'user_id': userId,
      'severity_level': severityLevel,
      'symptoms_description': symptomsDescription,
      'mood_before': moodBefore,
      'mood_after': moodAfter,
      'triggers': triggers,
      'environmental_factors': environmentalFactors,
      'logged_at': loggedAt.toIso8601String(),
    };
  }

  // Helper methods
  String get severityText {
    switch (severityLevel) {
      case 1:
      case 2:
        return 'Leicht';
      case 3:
      case 4:
        return 'Mild';
      case 5:
      case 6:
        return 'Mäßig';
      case 7:
      case 8:
        return 'Schwer';
      case 9:
      case 10:
        return 'Sehr schwer';
      default:
        return 'Unbekannt';
    }
  }

  String get severityColor {
    switch (severityLevel) {
      case 1:
      case 2:
        return 'green';
      case 3:
      case 4:
        return 'lightgreen';
      case 5:
      case 6:
        return 'yellow';
      case 7:
      case 8:
        return 'orange';
      case 9:
      case 10:
        return 'red';
      default:
        return 'grey';
    }
  }

  double get severityPercentage => (severityLevel / 10.0) * 100.0;

  String? get moodImprovementText {
    if (moodBefore == null || moodAfter == null) return null;

    final improvement = moodAfter! - moodBefore!;
    if (improvement > 0) {
      return 'Verbesserung um ${improvement} Punkte';
    } else if (improvement < 0) {
      return 'Verschlechterung um ${improvement.abs()} Punkte';
    } else {
      return 'Keine Änderung';
    }
  }

  int? get moodImprovement {
    if (moodBefore == null || moodAfter == null) return null;
    return moodAfter! - moodBefore!;
  }

  String get formattedLoggedAt {
    final now = DateTime.now();
    final difference = now.difference(loggedAt);

    if (difference.inDays == 0) {
      if (difference.inHours == 0) {
        return 'Vor ${difference.inMinutes} Min';
      }
      return 'Vor ${difference.inHours} Std';
    } else if (difference.inDays == 1) {
      return 'Gestern';
    } else if (difference.inDays < 7) {
      return 'Vor ${difference.inDays} Tagen';
    } else {
      return '${loggedAt.day.toString().padLeft(2, '0')}.${loggedAt.month.toString().padLeft(2, '0')}.${loggedAt.year}';
    }
  }

  String get formattedDate {
    return '${loggedAt.day.toString().padLeft(2, '0')}.${loggedAt.month.toString().padLeft(2, '0')}.${loggedAt.year}';
  }

  String get formattedTime {
    return '${loggedAt.hour.toString().padLeft(2, '0')}:${loggedAt.minute.toString().padLeft(2, '0')}';
  }

  bool get hasTriggers => triggers != null && triggers!.isNotEmpty;
  bool get hasEnvironmentalFactors =>
      environmentalFactors != null && environmentalFactors!.isNotEmpty;
  bool get hasMoodData => moodBefore != null && moodAfter != null;

  List<String> get triggersList {
    if (!hasTriggers) return [];
    return triggers!
        .split(',')
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList();
  }

  bool get isHighSeverity => severityLevel >= 7;
  bool get isModerateSeverity => severityLevel >= 4 && severityLevel < 7;
  bool get isLowSeverity => severityLevel < 4;

  SymptomLog copyWith({
    String? id,
    String? userId,
    int? severityLevel,
    String? symptomsDescription,
    int? moodBefore,
    int? moodAfter,
    String? triggers,
    String? environmentalFactors,
    DateTime? loggedAt,
  }) {
    return SymptomLog(
      id: id ?? this.id,
      userId: userId ?? this.userId,
      severityLevel: severityLevel ?? this.severityLevel,
      symptomsDescription: symptomsDescription ?? this.symptomsDescription,
      moodBefore: moodBefore ?? this.moodBefore,
      moodAfter: moodAfter ?? this.moodAfter,
      triggers: triggers ?? this.triggers,
      environmentalFactors: environmentalFactors ?? this.environmentalFactors,
      loggedAt: loggedAt ?? this.loggedAt,
    );
  }

  @override
  String toString() {
    return 'SymptomLog(id: $id, severity: $severityLevel, '
        'symptoms: $symptomsDescription, logged: $formattedLoggedAt)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;

    return other is SymptomLog && other.id == id;
  }

  @override
  int get hashCode => id.hashCode;
}
