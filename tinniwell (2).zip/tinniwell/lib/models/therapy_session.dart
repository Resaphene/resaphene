class TherapySession {
  final String id;
  final String userId;
  final String therapyMode;
  final int frequencyHz;
  final int intensityLevel;
  final int durationMinutes;
  final String sessionStatus;
  final DateTime startedAt;
  final DateTime? completedAt;
  final int? effectivenessRating;
  final String? notes;
  final Map<String, dynamic>? sessionData;
  final String? audioFilePath;

  TherapySession({
    required this.id,
    required this.userId,
    required this.therapyMode,
    required this.frequencyHz,
    required this.intensityLevel,
    required this.durationMinutes,
    required this.sessionStatus,
    required this.startedAt,
    this.completedAt,
    this.effectivenessRating,
    this.notes,
    this.sessionData,
    this.audioFilePath,
  });

  factory TherapySession.fromJson(Map<String, dynamic> json) {
    return TherapySession(
      id: json['id'] as String,
      userId: json['user_id'] as String,
      therapyMode: json['therapy_mode'] as String,
      frequencyHz: json['frequency_hz'] as int,
      intensityLevel: json['intensity_level'] as int,
      durationMinutes: json['duration_minutes'] as int,
      sessionStatus: json['session_status'] as String,
      startedAt: DateTime.parse(json['started_at'] as String),
      completedAt: json['completed_at'] != null
          ? DateTime.parse(json['completed_at'] as String)
          : null,
      effectivenessRating: json['effectiveness_rating'] as int?,
      notes: json['notes'] as String?,
      sessionData: json['session_data'] as Map<String, dynamic>?,
      audioFilePath: json['audio_file_path'] as String?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'user_id': userId,
      'therapy_mode': therapyMode,
      'frequency_hz': frequencyHz,
      'intensity_level': intensityLevel,
      'duration_minutes': durationMinutes,
      'session_status': sessionStatus,
      'started_at': startedAt.toIso8601String(),
      'completed_at': completedAt?.toIso8601String(),
      'effectiveness_rating': effectivenessRating,
      'notes': notes,
      'session_data': sessionData,
      'audio_file_path': audioFilePath,
    };
  }

  // Helper methods
  String get formattedTherapyMode {
    switch (therapyMode.toLowerCase()) {
      case 'ausblendung':
        return 'Ausblendung';
      case 'ueberlagerung':
        return 'Überlagerung';
      case 'gegentakt':
        return 'Gegentakt';
      default:
        return therapyMode;
    }
  }

  String get formattedStatus {
    switch (sessionStatus.toLowerCase()) {
      case 'active':
        return 'Aktiv';
      case 'completed':
        return 'Abgeschlossen';
      case 'paused':
        return 'Pausiert';
      case 'cancelled':
        return 'Abgebrochen';
      default:
        return sessionStatus;
    }
  }

  String get formattedDuration {
    if (durationMinutes < 60) {
      return '$durationMinutes Min';
    } else {
      final hours = durationMinutes ~/ 60;
      final minutes = durationMinutes % 60;
      return minutes > 0 ? '${hours}h ${minutes}min' : '${hours}h';
    }
  }

  String get formattedFrequency =>
      '${(frequencyHz / 1000).toStringAsFixed(1)} kHz';

  bool get isActive => sessionStatus.toLowerCase() == 'active';
  bool get isCompleted => sessionStatus.toLowerCase() == 'completed';
  bool get isPaused => sessionStatus.toLowerCase() == 'paused';
  bool get isCancelled => sessionStatus.toLowerCase() == 'cancelled';

  double get effectivenessPercentage {
    if (effectivenessRating == null) return 0.0;
    return (effectivenessRating! / 5.0) * 100.0;
  }

  TherapySession copyWith({
    String? id,
    String? userId,
    String? therapyMode,
    int? frequencyHz,
    int? intensityLevel,
    int? durationMinutes,
    String? sessionStatus,
    DateTime? startedAt,
    DateTime? completedAt,
    int? effectivenessRating,
    String? notes,
    Map<String, dynamic>? sessionData,
    String? audioFilePath,
  }) {
    return TherapySession(
      id: id ?? this.id,
      userId: userId ?? this.userId,
      therapyMode: therapyMode ?? this.therapyMode,
      frequencyHz: frequencyHz ?? this.frequencyHz,
      intensityLevel: intensityLevel ?? this.intensityLevel,
      durationMinutes: durationMinutes ?? this.durationMinutes,
      sessionStatus: sessionStatus ?? this.sessionStatus,
      startedAt: startedAt ?? this.startedAt,
      completedAt: completedAt ?? this.completedAt,
      effectivenessRating: effectivenessRating ?? this.effectivenessRating,
      notes: notes ?? this.notes,
      sessionData: sessionData ?? this.sessionData,
      audioFilePath: audioFilePath ?? this.audioFilePath,
    );
  }

  @override
  String toString() {
    return 'TherapySession(id: $id, therapyMode: $therapyMode, '
        'frequency: ${formattedFrequency}, duration: ${formattedDuration}, '
        'status: $formattedStatus)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;

    return other is TherapySession && other.id == id;
  }

  @override
  int get hashCode => id.hashCode;
}
