class UserProfile {
  final String id;
  final String email;
  final String fullName;
  final String role;
  final DateTime? dateOfBirth;
  final String? phoneNumber;
  final String? avatarUrl;
  final String? medicalId;
  final DateTime createdAt;
  final bool isActive;

  UserProfile({
    required this.id,
    required this.email,
    required this.fullName,
    required this.role,
    this.dateOfBirth,
    this.phoneNumber,
    this.avatarUrl,
    this.medicalId,
    required this.createdAt,
    this.isActive = true,
  });

  factory UserProfile.fromJson(Map<String, dynamic> json) {
    return UserProfile(
      id: json['id'] as String,
      email: json['email'] as String,
      fullName: json['full_name'] as String,
      role: json['role'] as String,
      dateOfBirth: json['date_of_birth'] != null
          ? DateTime.parse(json['date_of_birth'] as String)
          : null,
      phoneNumber: json['phone_number'] as String?,
      avatarUrl: json['avatar_url'] as String?,
      medicalId: json['medical_id'] as String?,
      createdAt: DateTime.parse(json['created_at'] as String),
      isActive: json['is_active'] as bool? ?? true,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'email': email,
      'full_name': fullName,
      'role': role,
      'date_of_birth': dateOfBirth?.toIso8601String().split('T')[0],
      'phone_number': phoneNumber,
      'avatar_url': avatarUrl,
      'medical_id': medicalId,
      'created_at': createdAt.toIso8601String(),
      'is_active': isActive,
    };
  }

  // Helper methods
  String get formattedRole {
    switch (role.toLowerCase()) {
      case 'patient':
        return 'Patient';
      case 'doctor':
        return 'Arzt';
      case 'admin':
        return 'Administrator';
      default:
        return role;
    }
  }

  String get initials {
    final names = fullName.trim().split(' ');
    if (names.length >= 2) {
      return '${names.first[0]}${names.last[0]}'.toUpperCase();
    } else {
      return names.first[0].toUpperCase();
    }
  }

  String get firstName => fullName.split(' ').first;
  String get lastName =>
      fullName.split(' ').length > 1 ? fullName.split(' ').last : '';

  bool get isPatient => role.toLowerCase() == 'patient';
  bool get isDoctor => role.toLowerCase() == 'doctor';
  bool get isAdmin => role.toLowerCase() == 'admin';

  bool get hasProfilePicture => avatarUrl != null && avatarUrl!.isNotEmpty;

  int? get age {
    if (dateOfBirth == null) return null;
    final today = DateTime.now();
    int age = today.year - dateOfBirth!.year;
    if (today.month < dateOfBirth!.month ||
        (today.month == dateOfBirth!.month && today.day < dateOfBirth!.day)) {
      age--;
    }
    return age;
  }

  String? get formattedDateOfBirth {
    if (dateOfBirth == null) return null;
    return '${dateOfBirth!.day.toString().padLeft(2, '0')}.${dateOfBirth!.month.toString().padLeft(2, '0')}.${dateOfBirth!.year}';
  }

  UserProfile copyWith({
    String? id,
    String? email,
    String? fullName,
    String? role,
    DateTime? dateOfBirth,
    String? phoneNumber,
    String? avatarUrl,
    String? medicalId,
    DateTime? createdAt,
    bool? isActive,
  }) {
    return UserProfile(
      id: id ?? this.id,
      email: email ?? this.email,
      fullName: fullName ?? this.fullName,
      role: role ?? this.role,
      dateOfBirth: dateOfBirth ?? this.dateOfBirth,
      phoneNumber: phoneNumber ?? this.phoneNumber,
      avatarUrl: avatarUrl ?? this.avatarUrl,
      medicalId: medicalId ?? this.medicalId,
      createdAt: createdAt ?? this.createdAt,
      isActive: isActive ?? this.isActive,
    );
  }

  @override
  String toString() {
    return 'UserProfile(id: $id, email: $email, fullName: $fullName, role: $role)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;

    return other is UserProfile && other.id == id;
  }

  @override
  int get hashCode => id.hashCode;
}
