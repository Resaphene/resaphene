import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../services/therapy_service.dart';
import '../../services/user_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/custom_app_bar.dart';
import '../../widgets/custom_bottom_bar.dart';
import '../trial_status_widget/trial_status_widget.dart';
import './widgets/data_export_card.dart';
import './widgets/license_management_card.dart';
import './widgets/medical_info_section.dart';
import './widgets/settings_section.dart';
import './widgets/simple_audio_info_widget.dart';
import './widgets/user_info_card.dart';

/// User Profile Screen for TinniWell
/// Displays user information, settings, and account management options
class UserProfileScreen extends StatefulWidget {
  const UserProfileScreen({super.key});

  @override
  State<UserProfileScreen> createState() => _UserProfileScreenState();
}

class _UserProfileScreenState extends State<UserProfileScreen>
    with TickerProviderStateMixin {
  bool _isLoading = true;
  bool _isDarkMode = false;
  bool _pushNotifications = true;
  bool _soundNotifications = true;
  bool _vibrationNotifications = true;
  String _reminderFrequency = 'Täglich';
  String _language = 'Deutsch';
  String _exportFormat = 'PDF';

  // Real user data from Supabase
  Map<String, dynamic>? _userProfile;
  Map<String, dynamic>? _medicalProfile;
  Map<String, dynamic>? _progressStats;
  int _totalSessions = 0;
  double _averageSessionTime = 0.0;

  @override
  void initState() {
    super.initState();
    _loadUserProfileData();
  }

  @override
  void dispose() {
    super.dispose();
  }

  Future<void> _loadUserProfileData() async {
    try {
      setState(() {
        _isLoading = true;
      });

      // Load user profile
      final userProfile = await UserService.instance.getCurrentUserProfile();

      if (userProfile != null) {
        // Load medical profile
        final medicalProfile = await UserService.instance.getMedicalProfile();

        // Load progress statistics
        final progressStats =
            await TherapyService.instance.getProgressStatistics();

        // Load therapy sessions count
        final sessions =
            await TherapyService.instance.getTherapySessions(limit: 100);

        setState(() {
          _userProfile = userProfile;
          _medicalProfile = medicalProfile;
          _progressStats = progressStats;
          _totalSessions =
              progressStats['total_sessions_count'] ?? sessions.length;
          _averageSessionTime =
              progressStats['average_session_duration'] ?? 0.0;
          _isLoading = false;
        });
      } else {
        setState(() {
          _isLoading = false;
        });
      }
    } catch (error) {
      print('Error loading profile data: $error');
      setState(() {
        _isLoading = false;
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Fehler beim Laden der Profildaten'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  String _formatTherapyDuration() {
    if (_userProfile == null) return 'Unbekannt';

    final createdAt = DateTime.parse(_userProfile!['created_at']);
    final now = DateTime.now();
    final difference = now.difference(createdAt);

    if (difference.inDays < 30) {
      return '${difference.inDays} Tage';
    } else if (difference.inDays < 365) {
      final months = (difference.inDays / 30).floor();
      return '$months Monat${months > 1 ? 'e' : ''}';
    } else {
      final years = (difference.inDays / 365).floor();
      final remainingMonths = ((difference.inDays % 365) / 30).floor();
      return '$years Jahr${years > 1 ? 'e' : ''} ${remainingMonths > 0 ? '$remainingMonths Monat${remainingMonths > 1 ? 'e' : ''}' : ''}';
    }
  }

  String _getTherapyFrequency() {
    if (_medicalProfile == null) return 'Standard';

    final frequency = _medicalProfile!['dominant_frequency_hz'];
    if (frequency != null) {
      return '${(frequency / 1000).toStringAsFixed(1)} kHz';
    }
    return 'Standard';
  }

  String _getProgressPercentage() {
    if (_progressStats == null) return '0%';

    final improvement =
        _progressStats!['symptom_improvement_percentage'] ?? 0.0;
    return '${improvement.toStringAsFixed(0)}%';
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Scaffold(
      backgroundColor:
          isDark ? AppTheme.backgroundDark : AppTheme.backgroundLight,
      appBar: CustomAppBar(title: 'Profil', showBackButton: true),
      body: SafeArea(
        child: _isLoading
            ? Center(
                child: CircularProgressIndicator(
                  color: theme.colorScheme.primary,
                ),
              )
            : SingleChildScrollView(
                padding: EdgeInsets.symmetric(horizontal: 6.w, vertical: 2.h),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // User Info Card with real data
                    UserInfoCard(
                      userProfile: _userProfile,
                      therapyDuration: _formatTherapyDuration(),
                      totalSessions: _totalSessions,
                      progressPercentage: _getProgressPercentage(),
                      therapyFrequency: _getTherapyFrequency(),
                    ),

                    SizedBox(height: 2.h),

                    // Trial Status Widget - collapsible card
                    const TrialStatusWidget(
                      displayMode: TrialStatusDisplayMode.card,
                      isDismissible: false,
                    ),

                    SizedBox(height: 2.h),

                    // Audio Tracks Admin Widget (only for admin users)
                    SimpleAudioInfoWidget(),

                    // Medical Information Section with real data
                    MedicalInfoSection(
                      medicalProfile: _medicalProfile,
                    ),

                    SizedBox(height: 2.h),

                    // License Management Card
                    const LicenseManagementCard(),

                    SizedBox(height: 2.h),

                    // Settings Section
                    SettingsSection(
                      title: 'Einstellungen',
                      iconName: 'settings',
                      items: [
                        SettingsItem(
                          title: 'App-Einstellungen',
                          subtitle: 'Theme, Sprache, Benachrichtigungen',
                          leadingIcon: 'tune',
                          onTap: () => _showAppSettingsDialog(),
                        ),
                        SettingsItem(
                          title: 'Therapie-Einstellungen',
                          subtitle: 'Standard-Frequenz, Session-Dauer',
                          leadingIcon: 'healing',
                          onTap: () => _showTherapySettingsDialog(),
                        ),
                        SettingsItem(
                          title: 'Erinnerungen',
                          subtitle: 'Therapie-Erinnerungen konfigurieren',
                          leadingIcon: 'notifications',
                          onTap: () => _showReminderSettings(),
                        ),
                        SettingsItem(
                          title: 'Datenschutz & Sicherheit',
                          subtitle: 'Datenschutz-Einstellungen verwalten',
                          leadingIcon: 'shield',
                          onTap: () => _showPrivacySettings(),
                        ),
                        SettingsItem(
                          title: 'Hilfe & Support',
                          subtitle: 'FAQ, Kontakt, Tutorials',
                          leadingIcon: 'help',
                          onTap: () => _showHelpSupport(),
                        ),
                      ],
                    ),

                    SizedBox(height: 2.h),

                    // Data Export Card
                    const DataExportCard(),

                    SizedBox(height: 4.h),
                  ],
                ),
              ),
      ),
      bottomNavigationBar: CustomBottomBar(
        currentIndex: CustomBottomBarExtension.getIndexForRoute(
          '/user-profile-screen',
        ),
        onTap: (index) {
          // Navigation handled by CustomBottomBar
        },
      ),
    );
  }

  void _showAppSettingsDialog() {
    showDialog(
      context: context,
      builder: (context) {
        final theme = Theme.of(context);
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              title: const Text('App-Einstellungen'),
              content: SizedBox(
                width: double.maxFinite,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SwitchListTile(
                      title: const Text('Dark Mode'),
                      subtitle: const Text('Dunkles Design verwenden'),
                      value: _isDarkMode,
                      onChanged: (value) {
                        setDialogState(() {
                          _isDarkMode = value;
                        });
                      },
                    ),
                    ListTile(
                      title: const Text('Sprache'),
                      subtitle: Text(_language),
                      trailing: DropdownButton<String>(
                        value: _language,
                        items: const [
                          DropdownMenuItem(
                            value: 'Deutsch',
                            child: Text('Deutsch'),
                          ),
                          DropdownMenuItem(
                            value: 'English',
                            child: Text('English'),
                          ),
                        ],
                        onChanged: (value) {
                          if (value != null) {
                            setDialogState(() {
                              _language = value;
                            });
                          }
                        },
                      ),
                    ),
                    SwitchListTile(
                      title: const Text('Push-Benachrichtigungen'),
                      value: _pushNotifications,
                      onChanged: (value) {
                        setDialogState(() {
                          _pushNotifications = value;
                        });
                      },
                    ),
                    SwitchListTile(
                      title: const Text('Sound-Benachrichtigungen'),
                      value: _soundNotifications,
                      onChanged: (value) {
                        setDialogState(() {
                          _soundNotifications = value;
                        });
                      },
                    ),
                    SwitchListTile(
                      title: const Text('Vibration'),
                      value: _vibrationNotifications,
                      onChanged: (value) {
                        setDialogState(() {
                          _vibrationNotifications = value;
                        });
                      },
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Abbrechen'),
                ),
                ElevatedButton(
                  onPressed: () {
                    _saveAppSettings();
                    Navigator.pop(context);
                  },
                  child: const Text('Speichern'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  void _showTherapySettingsDialog() {
    final frequency = _medicalProfile?['dominant_frequency_hz'] ?? 6200;
    final averageDuration = (_averageSessionTime > 0)
        ? '${_averageSessionTime.toStringAsFixed(0)} Minuten'
        : '30 Minuten';

    showDialog(
      context: context,
      builder: (context) {
        final theme = Theme.of(context);
        return AlertDialog(
          title: const Text('Therapie-Einstellungen'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                title: const Text('Standard-Frequenz'),
                subtitle: Text('${(frequency / 1000).toStringAsFixed(1)} kHz'),
                trailing: Icon(Icons.tune),
              ),
              ListTile(
                title: const Text('Durchschnittliche Session-Dauer'),
                subtitle: Text(averageDuration),
                trailing: Icon(Icons.timer),
              ),
              ListTile(
                title: const Text('Auto-Start nach Login'),
                subtitle: const Text('Aktiviert'),
                trailing: Icon(Icons.play_arrow),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Schließen'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
                // Navigate to detailed therapy settings
              },
              child: const Text('Bearbeiten'),
            ),
          ],
        );
      },
    );
  }

  void _showReminderSettings() {
    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              title: const Text('Erinnerungen'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  ListTile(
                    title: const Text('Erinnerungshäufigkeit'),
                    subtitle: Text(_reminderFrequency),
                    trailing: DropdownButton<String>(
                      value: _reminderFrequency,
                      items: const [
                        DropdownMenuItem(
                          value: 'Täglich',
                          child: Text('Täglich'),
                        ),
                        DropdownMenuItem(
                          value: 'Wöchentlich',
                          child: Text('Wöchentlich'),
                        ),
                        DropdownMenuItem(value: 'Nie', child: Text('Nie')),
                      ],
                      onChanged: (value) {
                        if (value != null) {
                          setDialogState(() {
                            _reminderFrequency = value;
                          });
                        }
                      },
                    ),
                  ),
                  const ListTile(
                    title: Text('Erinnerungszeit'),
                    subtitle: Text('09:00 Uhr'),
                    trailing: Icon(Icons.access_time),
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Abbrechen'),
                ),
                ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: const Text('Speichern'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  void _showPrivacySettings() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Datenschutz & Sicherheit'),
          content: const Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                title: Text('Datensammlung'),
                subtitle: Text('Anonyme Nutzungsstatistiken'),
                trailing: Icon(Icons.info),
              ),
              ListTile(
                title: Text('Datenschutzerklärung'),
                trailing: Icon(Icons.open_in_new),
              ),
              ListTile(
                title: Text('Nutzungsbedingungen'),
                trailing: Icon(Icons.description),
              ),
              ListTile(
                title: Text('Daten exportieren'),
                trailing: Icon(Icons.download),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Schließen'),
            ),
          ],
        );
      },
    );
  }

  void _showHelpSupport() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Hilfe & Support'),
          content: const Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                title: Text('FAQ'),
                subtitle: Text('Häufig gestellte Fragen'),
                trailing: Icon(Icons.quiz),
              ),
              ListTile(
                title: Text('Tutorial'),
                subtitle: Text('App-Einführung wiederholen'),
                trailing: Icon(Icons.school),
              ),
              ListTile(
                title: Text('Kontakt'),
                subtitle: Text('Support kontaktieren'),
                trailing: Icon(Icons.contact_support),
              ),
              ListTile(
                title: Text('Feedback senden'),
                subtitle: Text('Verbesserungsvorschläge'),
                trailing: Icon(Icons.feedback),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Schließen'),
            ),
          ],
        );
      },
    );
  }

  void _saveAppSettings() {
    // Implementation to save app settings
    setState(() {
      // Settings are already updated in the dialog state
    });

    // Show confirmation
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Einstellungen gespeichert'),
        duration: Duration(seconds: 2),
      ),
    );
  }
}
