import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../services/therapy_service.dart';

/// Audio Tracks Information Widget (No Admin Controls Needed)
/// Shows available tracks and system status - all tracks are automatically available
class AudioTracksAdminWidget extends StatefulWidget {
  const AudioTracksAdminWidget({super.key});

  @override
  State<AudioTracksAdminWidget> createState() => _AudioTracksAdminWidgetState();
}

class _AudioTracksAdminWidgetState extends State<AudioTracksAdminWidget> {
  bool _isLoading = true;
  bool _isAdmin = false;
  Map<String, dynamic>? _tracksStatistics;
  List<Map<String, dynamic>> _availableTracks = [];
  int _totalTracks = 0;

  @override
  void initState() {
    super.initState();
    _loadAudioTracksData();
  }

  Future<void> _loadAudioTracksData() async {
    try {
      setState(() {
        _isLoading = true;
      });

      // Check if user is admin (for display purposes)
      final isAdmin = await TherapyService.instance.isAudioTrackAdmin();

      // Load all available tracks (no admin approval needed)
      final statistics =
          await TherapyService.instance.getAudioTracksStatistics();
      final tracks = await TherapyService.instance.getAvailableAudioTracks();
      final trackCount = await TherapyService.instance.getTrackCount();

      setState(() {
        _isAdmin = isAdmin;
        _tracksStatistics = statistics;
        _availableTracks = tracks;
        _totalTracks = trackCount;
        _isLoading = false;
      });
    } catch (error) {
      print('Error loading audio tracks data: $error');
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Container(
      margin: EdgeInsets.symmetric(vertical: 1.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: isDark ? AppTheme.cardDark : AppTheme.cardLight,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(26),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              CustomIconWidget(
                iconName: 'library_music',
                size: 5.w,
                color: theme.colorScheme.primary,
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: Text(
                  'Verfügbare Therapie-Tracks',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: theme.colorScheme.onSurface,
                  ),
                ),
              ),
              if (_isLoading)
                SizedBox(
                  width: 4.w,
                  height: 4.w,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: theme.colorScheme.primary,
                  ),
                ),
            ],
          ),

          SizedBox(height: 2.h),

          // Auto-availability notice
          Container(
            padding: EdgeInsets.all(3.w),
            decoration: BoxDecoration(
              color: Colors.green.withAlpha(26),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: Colors.green.withAlpha(77),
              ),
            ),
            child: Row(
              children: [
                Icon(
                  Icons.check_circle_outline,
                  color: Colors.green,
                  size: 20,
                ),
                SizedBox(width: 2.w),
                Expanded(
                  child: Text(
                    'Alle hochgeladenen Songs sind automatisch verfügbar',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: Colors.green[700],
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
          ),

          SizedBox(height: 3.h),

          // Statistics Overview
          if (_tracksStatistics != null) ...[
            Row(
              children: [
                Expanded(
                  child: _StatisticCard(
                    title: 'Verfügbare Tracks',
                    value: '${_tracksStatistics!['total_tracks']}',
                    icon: 'library_music',
                    color: Colors.blue,
                  ),
                ),
                SizedBox(width: 3.w),
                Expanded(
                  child: _StatisticCard(
                    title: 'Gesamtdauer',
                    value: '${_tracksStatistics!['total_duration_minutes']}min',
                    icon: 'schedule',
                    color: Colors.orange,
                  ),
                ),
              ],
            ),
            SizedBox(height: 3.h),
          ],

          // Available Tracks List
          Text(
            'Alle verfügbaren Audio-Tracks',
            style: theme.textTheme.titleSmall?.copyWith(
              fontWeight: FontWeight.w500,
              color: theme.colorScheme.onSurface,
            ),
          ),

          SizedBox(height: 1.h),

          if (_availableTracks.isEmpty && !_isLoading)
            Container(
              padding: EdgeInsets.all(3.w),
              decoration: BoxDecoration(
                color: Colors.grey.withAlpha(26),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: [
                  Icon(Icons.info_outline, color: Colors.grey[600]),
                  SizedBox(width: 2.w),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Keine Tracks verfügbar',
                          style: theme.textTheme.bodyMedium?.copyWith(
                            color: Colors.grey[600],
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        SizedBox(height: 0.5.h),
                        Text(
                          'Laden Sie Audio-Dateien in den Supabase Storage hoch, um sie automatisch verfügbar zu machen.',
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: Colors.grey[500],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            )
          else
            ..._availableTracks.map((track) => _AudioTrackTile(
                  track: track,
                  isAvailable: true, // All tracks are always available
                )),

          // Admin notice (if admin)
          if (_isAdmin) ...[
            SizedBox(height: 2.h),
            Container(
              padding: EdgeInsets.all(3.w),
              decoration: BoxDecoration(
                color: theme.colorScheme.primary.withAlpha(26),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: theme.colorScheme.primary.withAlpha(77),
                ),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CustomIconWidget(
                    iconName: 'admin_panel_settings',
                    size: 4.w,
                    color: theme.colorScheme.primary,
                  ),
                  SizedBox(width: 2.w),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Admin-Hinweis',
                          style: theme.textTheme.bodyMedium?.copyWith(
                            color: theme.colorScheme.primary,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        SizedBox(height: 0.5.h),
                        Text(
                          'Manuelle Track-Aktivierung ist nicht mehr erforderlich. Alle Songs im Storage sind automatisch für alle Benutzer verfügbar.',
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: theme.colorScheme.onSurface,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _StatisticCard extends StatelessWidget {
  final String title;
  final String value;
  final String icon;
  final Color color;

  const _StatisticCard({
    required this.title,
    required this.value,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: color.withOpacity(isDark ? 0.1 : 0.05),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: color.withAlpha(51),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CustomIconWidget(
                iconName: icon,
                size: 4.w,
                color: color,
              ),
              SizedBox(width: 2.w),
              Expanded(
                child: Text(
                  title,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.onSurface.withAlpha(179),
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 1.h),
          Text(
            value,
            style: theme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}

class _AudioTrackTile extends StatelessWidget {
  final Map<String, dynamic> track;
  final bool isAvailable;

  const _AudioTrackTile({
    required this.track,
    required this.isAvailable,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    final duration = (track['duration_sec'] as num?)?.toInt() ?? 0;
    final minutes = (duration / 60).floor();
    final seconds = duration % 60;

    return Container(
      margin: EdgeInsets.only(bottom: 1.h),
      decoration: BoxDecoration(
        color: isAvailable
            ? theme.colorScheme.primary.withAlpha(26)
            : (isDark ? Colors.grey[800] : Colors.grey[100]),
        borderRadius: BorderRadius.circular(8),
        border: isAvailable
            ? Border.all(color: theme.colorScheme.primary.withAlpha(128))
            : null,
      ),
      child: ListTile(
        leading: Container(
          width: 10.w,
          height: 10.w,
          decoration: BoxDecoration(
            color: isAvailable
                ? theme.colorScheme.primary
                : theme.colorScheme.primary.withAlpha(77),
            borderRadius: BorderRadius.circular(20),
          ),
          child: CustomIconWidget(
            iconName: 'music_note',
            size: 5.w,
            color: Colors.white,
          ),
        ),
        title: Text(
          track['title'] ?? 'Unbekannter Track',
          style: theme.textTheme.bodyMedium?.copyWith(
            fontWeight: FontWeight.w500,
            color: theme.colorScheme.onSurface,
          ),
        ),
        subtitle: Text(
          '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')} min • Automatisch verfügbar',
          style: theme.textTheme.bodySmall?.copyWith(
            color: theme.colorScheme.onSurface.withAlpha(179),
          ),
        ),
        trailing: Container(
          padding: EdgeInsets.symmetric(
            horizontal: 2.w,
            vertical: 0.5.h,
          ),
          decoration: BoxDecoration(
            color: Colors.green,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Text(
            'VERFÜGBAR',
            style: theme.textTheme.bodySmall?.copyWith(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 9.sp,
            ),
          ),
        ),
      ),
    );
  }
}
