import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class MedicalInfoSection extends StatelessWidget {
  final Map<String, dynamic>? medicalProfile;

  const MedicalInfoSection({
    super.key,
    this.medicalProfile,
  });

  String _getTinnitusType() {
    if (medicalProfile == null ||
        medicalProfile!['tinnitus_onset_date'] == null) {
      return 'Nicht angegeben';
    }

    final onsetDate = DateTime.parse(medicalProfile!['tinnitus_onset_date']);
    final now = DateTime.now();
    final difference = now.difference(onsetDate);

    if (difference.inDays > 180) {
      // 6 months
      return 'Chronisch (> 6 Monate)';
    } else if (difference.inDays > 90) {
      // 3 months
      return 'Subchronisch (3-6 Monate)';
    } else {
      return 'Akut (< 3 Monate)';
    }
  }

  String _getSeverityLevel() {
    final volumeLevel = medicalProfile?['volume_level'];
    if (volumeLevel == null) return 'Nicht bewertet';

    if (volumeLevel >= 80) {
      return 'Sehr stark';
    } else if (volumeLevel >= 60) {
      return 'Stark';
    } else if (volumeLevel >= 40) {
      return 'Mittelgradig';
    } else if (volumeLevel >= 20) {
      return 'Mild';
    } else {
      return 'Sehr mild';
    }
  }

  String _getDominantFrequency() {
    final frequency = medicalProfile?['dominant_frequency_hz'];
    if (frequency == null) return 'Nicht gemessen';

    return '${(frequency / 1000).toStringAsFixed(1)} kHz';
  }

  String _getAffectedEar() {
    final ear = medicalProfile?['affected_ear'];
    if (ear == null) return 'Nicht angegeben';

    switch (ear) {
      case 'left':
        return 'Links';
      case 'right':
        return 'Rechts';
      case 'both':
        return 'Beidseitig';
      default:
        return 'Nicht angegeben';
    }
  }

  String _getOnsetDate() {
    if (medicalProfile?['tinnitus_onset_date'] == null) return 'Unbekannt';

    final date = DateTime.parse(medicalProfile!['tinnitus_onset_date']);
    return '${date.day.toString().padLeft(2, '0')}.${date.month.toString().padLeft(2, '0')}.${date.year}';
  }

  String _getCurrentMedication() {
    final notes = medicalProfile?['medical_notes'];
    if (notes == null || notes.isEmpty) return 'Keine aktuellen Medikamente';

    // Extract medication info from medical notes
    if (notes.toLowerCase().contains('medikament')) {
      return 'Siehe Arztnotizen';
    }

    return 'Keine aktuellen Medikamente';
  }

  String _getAllergies() {
    // This would typically be in a separate allergies field
    return 'Keine bekannten Allergien';
  }

  String _getHearingLossDegree() {
    final degree = medicalProfile?['hearing_loss_degree'];
    return degree ?? 'Nicht getestet';
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Container(
      width: double.infinity,
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: isDark ? const Color(0x1A000000) : const Color(0x0A000000),
            offset: const Offset(0, 2),
            blurRadius: 8,
            spreadRadius: 0,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              CustomIconWidget(
                iconName: 'medical_information',
                color: theme.colorScheme.secondary,
                size: 24,
              ),
              SizedBox(width: 3.w),
              Text(
                'Medizinische Informationen',
                style: theme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: theme.colorScheme.onSurface,
                ),
              ),
              const Spacer(),
              IconButton(
                onPressed: () {
                  _showDetailedMedicalInfo(context);
                },
                icon: CustomIconWidget(
                  iconName: 'info',
                  color: theme.colorScheme.primary,
                  size: 20,
                ),
                tooltip: 'Detaillierte Informationen',
              ),
            ],
          ),

          SizedBox(height: 3.h),

          // Medical Information Grid
          _buildInfoGrid(context),
        ],
      ),
    );
  }

  Widget _buildInfoGrid(BuildContext context) {
    return Column(
      children: [
        Row(
          children: [
            Expanded(
              child: _buildInfoItem(
                context,
                'Tinnitus-Typ',
                _getTinnitusType(),
                'psychology',
              ),
            ),
            SizedBox(width: 4.w),
            Expanded(
              child: _buildInfoItem(
                context,
                'Schweregrad',
                _getSeverityLevel(),
                'volume_up',
              ),
            ),
          ],
        ),
        SizedBox(height: 2.h),
        Row(
          children: [
            Expanded(
              child: _buildInfoItem(
                context,
                'Dominante Frequenz',
                _getDominantFrequency(),
                'graphic_eq',
              ),
            ),
            SizedBox(width: 4.w),
            Expanded(
              child: _buildInfoItem(
                context,
                'Betroffenes Ohr',
                _getAffectedEar(),
                'hearing',
              ),
            ),
          ],
        ),
        SizedBox(height: 2.h),
        Row(
          children: [
            Expanded(
              child: _buildInfoItem(
                context,
                'Beginn der Symptome',
                _getOnsetDate(),
                'event',
              ),
            ),
            SizedBox(width: 4.w),
            Expanded(
              child: _buildInfoItem(
                context,
                'Hörverlust',
                _getHearingLossDegree(),
                'hearing_disabled',
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildInfoItem(
    BuildContext context,
    String label,
    String value,
    String iconName,
  ) {
    final theme = Theme.of(context);

    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.3),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: theme.colorScheme.outline.withValues(alpha: 0.2),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CustomIconWidget(
                iconName: iconName,
                color: theme.colorScheme.secondary,
                size: 18,
              ),
              SizedBox(width: 2.w),
              Expanded(
                child: Text(
                  label,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.onSurfaceVariant,
                    fontWeight: FontWeight.w500,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          SizedBox(height: 1.h),
          Text(
            value,
            style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.colorScheme.onSurface,
              fontWeight: FontWeight.w600,
            ),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }

  void _showDetailedMedicalInfo(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) {
        final theme = Theme.of(context);
        return AlertDialog(
          title: const Text('Detaillierte Medizinische Informationen'),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                _buildDetailItem('Tinnitus-Ursache',
                    medicalProfile?['tinnitus_cause'] ?? 'Unbekannt'),
                SizedBox(height: 1.h),
                _buildDetailItem('Hörverlust', _getHearingLossDegree()),
                SizedBox(height: 1.h),
                _buildDetailItem(
                    'Aktuelle Medikation', _getCurrentMedication()),
                SizedBox(height: 1.h),
                _buildDetailItem('Allergien', _getAllergies()),
                SizedBox(height: 1.h),
                _buildDetailItem(
                    'Arztnotizen',
                    medicalProfile?['medical_notes'] ??
                        'Keine Notizen verfügbar'),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Schließen'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
                // TODO: Navigate to medical info editing
              },
              child: const Text('Bearbeiten'),
            ),
          ],
        );
      },
    );
  }

  Widget _buildDetailItem(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '$label:',
          style: TextStyle(
            fontWeight: FontWeight.w600,
            fontSize: 14,
          ),
        ),
        SizedBox(height: 0.5.h),
        Text(
          value,
          style: TextStyle(
            fontSize: 13,
            color: Colors.grey[600],
          ),
        ),
      ],
    );
  }
}
