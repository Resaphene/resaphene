import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../services/simple_audio_service.dart';

/// Simple Audio Info Widget - Shows storage-based music system info
/// Replaces complex admin controls with simple file upload instructions
class SimpleAudioInfoWidget extends StatefulWidget {
  const SimpleAudioInfoWidget({super.key});

  @override
  State<SimpleAudioInfoWidget> createState() => _SimpleAudioInfoWidgetState();
}

class _SimpleAudioInfoWidgetState extends State<SimpleAudioInfoWidget> {
  bool _isLoading = false;
  List<Map<String, dynamic>> _availableTracks = [];

  @override
  void initState() {
    super.initState();
    _loadTrackInfo();
  }

  Future<void> _loadTrackInfo() async {
    setState(() {
      _isLoading = true;
    });

    try {
      final tracks = await SimpleAudioService.instance.getAvailableTracks();
      setState(() {
        _availableTracks = tracks;
        _isLoading = false;
      });
    } catch (error) {
      print('Error loading track info: $error');
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Container(
      margin: EdgeInsets.symmetric(vertical: 1.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: isDark ? AppTheme.cardDark : AppTheme.cardLight,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(26),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              CustomIconWidget(
                iconName: 'cloud_upload',
                size: 5.w,
                color: theme.colorScheme.primary,
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: Text(
                  'Einfaches Audio-System',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: theme.colorScheme.onSurface,
                  ),
                ),
              ),
              if (_isLoading)
                SizedBox(
                  width: 4.w,
                  height: 4.w,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: theme.colorScheme.primary,
                  ),
                ),
              if (!_isLoading)
                IconButton(
                  onPressed: _loadTrackInfo,
                  icon: Icon(
                    Icons.refresh,
                    color: theme.colorScheme.primary,
                  ),
                ),
            ],
          ),

          SizedBox(height: 2.h),

          // Simplified system explanation
          Container(
            padding: EdgeInsets.all(3.w),
            decoration: BoxDecoration(
              color: Colors.blue.withAlpha(26),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: Colors.blue.withAlpha(77),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      Icons.lightbulb_outline,
                      color: Colors.blue,
                      size: 20,
                    ),
                    SizedBox(width: 2.w),
                    Expanded(
                      child: Text(
                        'So einfach funktioniert es:',
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: Colors.blue[700],
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 1.h),
                _buildInstructionStep('1',
                    'Laden Sie Audio-Dateien in den "therapy-audio" Storage-Bucket hoch'),
                SizedBox(height: 0.5.h),
                _buildInstructionStep(
                    '2', 'Die Songs erscheinen automatisch in der App'),
                SizedBox(height: 0.5.h),
                _buildInstructionStep(
                    '3', 'Keine weiteren Einstellungen nötig!'),
              ],
            ),
          ),

          SizedBox(height: 3.h),

          // Supported formats
          Container(
            padding: EdgeInsets.all(3.w),
            decoration: BoxDecoration(
              color: Colors.green.withAlpha(26),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: Colors.green.withAlpha(77),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      Icons.audiotrack,
                      color: Colors.green,
                      size: 20,
                    ),
                    SizedBox(width: 2.w),
                    Text(
                      'Unterstützte Formate:',
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: Colors.green[700],
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 1.h),
                Wrap(
                  spacing: 1.w,
                  runSpacing: 0.5.h,
                  children: [
                    _buildFormatChip('MP3'),
                    _buildFormatChip('WAV'),
                    _buildFormatChip('M4A'),
                    _buildFormatChip('AAC'),
                    _buildFormatChip('OGG'),
                    _buildFormatChip('FLAC'),
                  ],
                ),
              ],
            ),
          ),

          SizedBox(height: 3.h),

          // Available tracks info
          Row(
            children: [
              Expanded(
                child: _StatisticCard(
                  title: 'Verfügbare Songs',
                  value: '${_availableTracks.length}',
                  icon: 'library_music',
                  color: Colors.blue,
                ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: _StatisticCard(
                  title: 'System Status',
                  value: _availableTracks.isNotEmpty ? 'Bereit' : 'Leer',
                  icon: _availableTracks.isNotEmpty ? 'check_circle' : 'info',
                  color: _availableTracks.isNotEmpty
                      ? Colors.green
                      : Colors.orange,
                ),
              ),
            ],
          ),

          SizedBox(height: 2.h),

          // Available tracks list (if any)
          if (_availableTracks.isNotEmpty) ...[
            Text(
              'Verfügbare Audio-Dateien:',
              style: theme.textTheme.titleSmall?.copyWith(
                fontWeight: FontWeight.w500,
                color: theme.colorScheme.onSurface,
              ),
            ),
            SizedBox(height: 1.h),
            ..._availableTracks
                .take(5)
                .map((track) => _AudioTrackTile(track: track)),
            if (_availableTracks.length > 5)
              Padding(
                padding: EdgeInsets.only(top: 1.h),
                child: Text(
                  '... und ${_availableTracks.length - 5} weitere',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.onSurface.withAlpha(179),
                    fontStyle: FontStyle.italic,
                  ),
                ),
              ),
          ] else if (!_isLoading) ...[
            Container(
              padding: EdgeInsets.all(3.w),
              decoration: BoxDecoration(
                color: Colors.orange.withAlpha(26),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: Colors.orange.withAlpha(77),
                ),
              ),
              child: Row(
                children: [
                  Icon(Icons.folder_open, color: Colors.orange[600]),
                  SizedBox(width: 2.w),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Keine Audio-Dateien gefunden',
                          style: theme.textTheme.bodyMedium?.copyWith(
                            color: Colors.orange[700],
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        SizedBox(height: 0.5.h),
                        Text(
                          'Laden Sie Audio-Dateien in den "therapy-audio" Storage-Bucket hoch, um sie hier zu sehen.',
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: Colors.orange[600],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildInstructionStep(String number, String text) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 5.w,
          height: 5.w,
          decoration: BoxDecoration(
            color: Colors.blue,
            shape: BoxShape.circle,
          ),
          child: Center(
            child: Text(
              number,
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 10.sp,
              ),
            ),
          ),
        ),
        SizedBox(width: 2.w),
        Expanded(
          child: Text(
            text,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Colors.blue[600],
                ),
          ),
        ),
      ],
    );
  }

  Widget _buildFormatChip(String format) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.5.h),
      decoration: BoxDecoration(
        color: Colors.green,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        format,
        style: TextStyle(
          color: Colors.white,
          fontSize: 10.sp,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}

class _StatisticCard extends StatelessWidget {
  final String title;
  final String value;
  final String icon;
  final Color color;

  const _StatisticCard({
    required this.title,
    required this.value,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: color.withOpacity(isDark ? 0.1 : 0.05),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: color.withAlpha(51),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CustomIconWidget(
                iconName: icon,
                size: 4.w,
                color: color,
              ),
              SizedBox(width: 2.w),
              Expanded(
                child: Text(
                  title,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.onSurface.withAlpha(179),
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 1.h),
          Text(
            value,
            style: theme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}

class _AudioTrackTile extends StatelessWidget {
  final Map<String, dynamic> track;

  const _AudioTrackTile({required this.track});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      margin: EdgeInsets.only(bottom: 1.h),
      decoration: BoxDecoration(
        color: theme.colorScheme.primary.withAlpha(26),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: theme.colorScheme.primary.withAlpha(128)),
      ),
      child: ListTile(
        dense: true,
        leading: Container(
          width: 8.w,
          height: 8.w,
          decoration: BoxDecoration(
            color: theme.colorScheme.primary,
            borderRadius: BorderRadius.circular(15),
          ),
          child: Icon(
            Icons.music_note,
            color: Colors.white,
            size: 4.w,
          ),
        ),
        title: Text(
          track['title'] ?? 'Unbekannter Track',
          style: theme.textTheme.bodyMedium?.copyWith(
            fontWeight: FontWeight.w500,
            color: theme.colorScheme.onSurface,
          ),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        subtitle: Text(
          track['file_name'] ?? '',
          style: theme.textTheme.bodySmall?.copyWith(
            color: theme.colorScheme.onSurface.withAlpha(179),
          ),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        trailing: Container(
          padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.5.h),
          decoration: BoxDecoration(
            color: Colors.green,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Text(
            'VERFÜGBAR',
            style: theme.textTheme.bodySmall?.copyWith(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 9.sp,
            ),
          ),
        ),
      ),
    );
  }
}
