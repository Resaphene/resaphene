import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../widgets/custom_app_bar.dart';
import '../../widgets/custom_bottom_bar.dart';
import './widgets/date_range_selector.dart';
import './widgets/progress_chart_widget.dart';
import './widgets/session_history_item.dart';
import './widgets/symptom_severity_tracker.dart';
import './widgets/therapy_statistics_card.dart';

class ProgressTrackingScreen extends StatefulWidget {
  const ProgressTrackingScreen({super.key});

  @override
  State<ProgressTrackingScreen> createState() => _ProgressTrackingScreenState();
}

class _ProgressTrackingScreenState extends State<ProgressTrackingScreen>
    with TickerProviderStateMixin {
  late TabController _tabController;
  String _selectedDateRange = '1M';
  bool _isLoading = false;

  // Mock data for therapy statistics
  final List<Map<String, dynamic>> _statisticsData = [
    {
      'title': 'Gesamtsitzungen',
      'value': '47',
      'subtitle': 'Diesen Monat',
      'icon': Icons.timer_outlined,
      'trend': '+12%',
      'showTrend': true,
    },
    {
      'title': 'Durchschnittsdauer',
      'value': '28 Min',
      'subtitle': 'Pro Sitzung',
      'icon': Icons.schedule_outlined,
      'trend': '+5 Min',
      'showTrend': true,
    },
    {
      'title': 'Häufigkeitstrend',
      'value': '6.2 kHz',
      'subtitle': 'Durchschnitt',
      'icon': Icons.graphic_eq_outlined,
      'iconColor': AppTheme.lightTheme.colorScheme.secondary,
    },
    {
      'title': 'Symptomverbesserung',
      'value': '73%',
      'subtitle': 'Letzte 30 Tage',
      'icon': Icons.trending_up_outlined,
      'iconColor': AppTheme.lightTheme.colorScheme.tertiary,
      'trend': '+18%',
      'showTrend': true,
    },
  ];

  // Mock data for progress charts
  final List<Map<String, dynamic>> _weeklyProgressData = [
    {'day': 'Mo', 'value': 3},
    {'day': 'Di', 'value': 5},
    {'day': 'Mi', 'value': 2},
    {'day': 'Do', 'value': 7},
    {'day': 'Fr', 'value': 4},
    {'day': 'Sa', 'value': 6},
    {'day': 'So', 'value': 3},
  ];

  final List<Map<String, dynamic>> _symptomTrendData = [
    {'day': 'Mo', 'value': 6},
    {'day': 'Di', 'value': 5},
    {'day': 'Mi', 'value': 7},
    {'day': 'Do', 'value': 4},
    {'day': 'Fr', 'value': 3},
    {'day': 'Sa', 'value': 4},
    {'day': 'So', 'value': 2},
  ];

  final List<Map<String, dynamic>> _therapyModeData = [
    {'mode': 'Ausblendung', 'value': 45},
    {'mode': 'Überlagerung', 'value': 30},
    {'mode': 'Gegentakt', 'value': 25},
  ];

  // Mock data for symptom severity
  final List<Map<String, dynamic>> _severityData = [
    {'date': '01.12', 'severity': 8},
    {'date': '02.12', 'severity': 7},
    {'date': '03.12', 'severity': 6},
    {'date': '04.12', 'severity': 5},
    {'date': '05.12', 'severity': 4},
    {'date': '06.12', 'severity': 6},
    {'date': '07.12', 'severity': 3},
    {'date': '08.12', 'severity': 4},
    {'date': '09.12', 'severity': 2},
    {'date': '10.12', 'severity': 3},
    {'date': '11.12', 'severity': 2},
    {'date': '12.12', 'severity': 1},
    {'date': '13.12', 'severity': 2},
    {'date': '14.12', 'severity': 1},
  ];

  // Mock data for session history
  final List<Map<String, dynamic>> _sessionHistory = [
    {
      'id': 1,
      'date': '14. Dezember 2024, 09:30',
      'duration': '32 Min',
      'frequency': '6.2 kHz',
      'mode': 'Ausblendung',
      'effectiveness': 4,
      'notes': 'Gute Entspannung erreicht',
    },
    {
      'id': 2,
      'date': '13. Dezember 2024, 20:15',
      'duration': '25 Min',
      'frequency': '5.8 kHz',
      'mode': 'Überlagerung',
      'effectiveness': 5,
      'notes': 'Sehr effektive Sitzung',
    },
    {
      'id': 3,
      'date': '12. Dezember 2024, 14:45',
      'duration': '28 Min',
      'frequency': '6.5 kHz',
      'mode': 'Gegentakt',
      'effectiveness': 3,
      'notes': '',
    },
    {
      'id': 4,
      'date': '11. Dezember 2024, 08:00',
      'duration': '30 Min',
      'frequency': '6.0 kHz',
      'mode': 'Ausblendung',
      'effectiveness': 4,
      'notes': 'Morgentherapie sehr hilfreich',
    },
    {
      'id': 5,
      'date': '10. Dezember 2024, 19:30',
      'duration': '35 Min',
      'frequency': '5.5 kHz',
      'mode': 'Überlagerung',
      'effectiveness': 5,
      'notes': 'Beste Sitzung diese Woche',
    },
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      appBar: CustomAppBar.progressTracking(context),
      body: SafeArea(
        child: Column(
          children: [
            // Date range selector
            Container(
              padding: EdgeInsets.all(4.w),
              child: DateRangeSelector(
                selectedRange: _selectedDateRange,
                onRangeChanged: _onDateRangeChanged,
              ),
            ),

            // Tab bar
            Container(
              margin: EdgeInsets.symmetric(horizontal: 4.w),
              decoration: BoxDecoration(
                color: theme.colorScheme.surfaceContainerHighest
                    .withValues(alpha: 0.3),
                borderRadius: BorderRadius.circular(8),
              ),
              child: TabBar(
                controller: _tabController,
                indicator: BoxDecoration(
                  color: theme.colorScheme.primary,
                  borderRadius: BorderRadius.circular(6),
                ),
                indicatorSize: TabBarIndicatorSize.tab,
                dividerColor: Colors.transparent,
                labelColor: theme.colorScheme.onPrimary,
                unselectedLabelColor: theme.colorScheme.onSurfaceVariant,
                labelStyle: theme.textTheme.bodyMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
                unselectedLabelStyle: theme.textTheme.bodyMedium?.copyWith(
                  fontWeight: FontWeight.w400,
                ),
                tabs: const [
                  Tab(text: 'Verlauf'),
                  Tab(text: 'Analyse'),
                ],
              ),
            ),

            // Tab content
            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: [
                  _buildProgressTab(),
                  _buildAnalysisTab(),
                ],
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _showSymptomLogger,
        tooltip: 'Symptom erfassen',
        child: CustomIconWidget(
          iconName: 'add',
          color: theme.colorScheme.onPrimary,
          size: 6.w,
        ),
      ),
      bottomNavigationBar: CustomBottomBar(
        currentIndex: CustomBottomBarExtension.getIndexForRoute(
            '/progress-tracking-screen'),
        onTap: (index) {
          // Navigation handled by CustomBottomBar
        },
      ),
    );
  }

  Widget _buildProgressTab() {
    return RefreshIndicator(
      onRefresh: _refreshData,
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: EdgeInsets.all(4.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Statistics cards
            Column(
              children: _statisticsData.map((data) {
                return Padding(
                  padding: EdgeInsets.only(bottom: 3.w),
                  child: TherapyStatisticsCard(
                    title: data['title'],
                    value: data['value'],
                    subtitle: data['subtitle'],
                    icon: data['icon'],
                    iconColor: data['iconColor'],
                    trend: data['trend'],
                    showTrend: data['showTrend'] ?? false,
                  ),
                );
              }).toList(),
            ),
            SizedBox(height: 6.w),

            // Weekly progress chart
            ProgressChartWidget(
              chartType: 'bar',
              chartData: _weeklyProgressData,
              title: 'Wöchentliche Therapiesitzungen',
            ),
            SizedBox(height: 4.w),

            // Symptom severity tracker
            SymptomSeverityTracker(
              severityData: _severityData,
            ),
            SizedBox(height: 6.w),

            // Session history header
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Letzte Sitzungen',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                ),
                TextButton(
                  onPressed: _exportProgress,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      CustomIconWidget(
                        iconName: 'download_outlined',
                        color: Theme.of(context).colorScheme.primary,
                        size: 4.w,
                      ),
                      SizedBox(width: 2.w),
                      Text('Exportieren'),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: 3.w),

            // Session history list
            ..._sessionHistory.map((session) {
              return SessionHistoryItem(
                sessionData: session,
                onTap: () => _showSessionDetails(session),
                onShare: () => _shareSession(session),
                onDetails: () => _showSessionDetails(session),
              );
            }),

            SizedBox(height: 20.w), // Bottom padding for FAB
          ],
        ),
      ),
    );
  }

  Widget _buildAnalysisTab() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Symptom trend chart
          ProgressChartWidget(
            chartType: 'line',
            chartData: _symptomTrendData,
            title: 'Symptomverlauf (Letzte 7 Tage)',
          ),
          SizedBox(height: 4.w),

          // Therapy mode distribution
          ProgressChartWidget(
            chartType: 'pie',
            chartData: _therapyModeData,
            title: 'Therapiemodus-Verteilung',
          ),
          SizedBox(height: 6.w),

          // Analysis insights
          Container(
            width: double.infinity,
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? const Color(0x1A000000)
                      : const Color(0x0A000000),
                  offset: const Offset(0, 1),
                  blurRadius: 3,
                  spreadRadius: 0,
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    CustomIconWidget(
                      iconName: 'lightbulb_outline',
                      color: AppTheme.lightTheme.colorScheme.tertiary,
                      size: 6.w,
                    ),
                    SizedBox(width: 3.w),
                    Text(
                      'Therapie-Erkenntnisse',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.w600,
                          ),
                    ),
                  ],
                ),
                SizedBox(height: 4.w),
                _buildInsightItem(
                  'Beste Tageszeit',
                  'Abendtherapie (19:00-21:00) zeigt 23% bessere Ergebnisse',
                  Icons.schedule_outlined,
                ),
                SizedBox(height: 3.w),
                _buildInsightItem(
                  'Optimale Frequenz',
                  'Frequenzen um 6.0 kHz erzielen die höchste Wirksamkeit',
                  Icons.graphic_eq_outlined,
                ),
                SizedBox(height: 3.w),
                _buildInsightItem(
                  'Therapiedauer',
                  'Sitzungen über 30 Min zeigen signifikant bessere Langzeiteffekte',
                  Icons.timer_outlined,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInsightItem(String title, String description, IconData icon) {
    final theme = Theme.of(context);

    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.3),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          CustomIconWidget(
            iconName: _getIconName(icon),
            color: theme.colorScheme.primary,
            size: 5.w,
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: theme.colorScheme.onSurface,
                  ),
                ),
                SizedBox(height: 1.w),
                Text(
                  description,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _getIconName(IconData icon) {
    if (icon == Icons.schedule_outlined) return 'schedule_outlined';
    if (icon == Icons.graphic_eq_outlined) return 'graphic_eq_outlined';
    if (icon == Icons.timer_outlined) return 'timer_outlined';
    return 'info_outline';
  }

  void _onDateRangeChanged(String range) {
    setState(() {
      _selectedDateRange = range;
    });
    // Here you would typically fetch new data based on the selected range
    _refreshData();
  }

  Future<void> _refreshData() async {
    setState(() {
      _isLoading = true;
    });

    // Provide haptic feedback
    HapticFeedback.lightImpact();

    // Simulate data refresh
    await Future.delayed(const Duration(seconds: 1));

    setState(() {
      _isLoading = false;
    });

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Fortschrittsdaten aktualisiert'),
          duration: Duration(seconds: 2),
        ),
      );
    }
  }

  void _showSymptomLogger() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _buildSymptomLoggerSheet(),
    );
  }

  Widget _buildSymptomLoggerSheet() {
    final theme = Theme.of(context);
    double currentSeverity = 5.0;

    return StatefulBuilder(
      builder: (context, setSheetState) {
        return Container(
          height: 60.h,
          decoration: BoxDecoration(
            color: theme.cardColor,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
          ),
          padding: EdgeInsets.all(6.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Handle bar
              Center(
                child: Container(
                  width: 12.w,
                  height: 1.w,
                  decoration: BoxDecoration(
                    color: theme.colorScheme.onSurfaceVariant
                        .withValues(alpha: 0.3),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              SizedBox(height: 4.w),

              Text(
                'Symptom erfassen',
                style: theme.textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(height: 6.w),

              Text(
                'Wie stark sind Ihre Tinnitus-Symptome gerade?',
                style: theme.textTheme.bodyMedium,
              ),
              SizedBox(height: 4.w),

              // Severity slider
              Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Niedrig', style: theme.textTheme.bodySmall),
                      Text('Schwer', style: theme.textTheme.bodySmall),
                    ],
                  ),
                  Slider(
                    value: currentSeverity,
                    min: 1.0,
                    max: 10.0,
                    divisions: 9,
                    label: currentSeverity.round().toString(),
                    onChanged: (value) {
                      setSheetState(() {
                        currentSeverity = value;
                      });
                      HapticFeedback.selectionClick();
                    },
                  ),
                  Text(
                    'Schweregrad: ${currentSeverity.round()}/10',
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                      color: theme.colorScheme.primary,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 6.w),

              // Save button
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                    _saveSymptomEntry(currentSeverity.round());
                  },
                  child: const Text('Symptom speichern'),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void _saveSymptomEntry(int severity) {
    HapticFeedback.lightImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Symptom mit Schweregrad $severity gespeichert'),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _showSessionDetails(Map<String, dynamic> session) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Sitzungsdetails'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildDetailRow('Datum:', session['date']),
            _buildDetailRow('Dauer:', session['duration']),
            _buildDetailRow('Frequenz:', session['frequency']),
            _buildDetailRow('Modus:', session['mode']),
            _buildDetailRow('Wirksamkeit:', '${session['effectiveness']}/5'),
            if (session['notes'].isNotEmpty)
              _buildDetailRow('Notizen:', session['notes']),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Schließen'),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: EdgeInsets.only(bottom: 2.w),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 20.w,
            child: Text(
              label,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ),
        ],
      ),
    );
  }

  void _shareSession(Map<String, dynamic> session) {
    HapticFeedback.lightImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Sitzungsdaten werden geteilt...'),
        duration: Duration(seconds: 2),
      ),
    );
  }

  void _exportProgress() {
    HapticFeedback.lightImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Fortschrittsbericht wird erstellt...'),
        duration: Duration(seconds: 2),
      ),
    );
  }
}
