import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class TherapyStatisticsCard extends StatelessWidget {
  final String title;
  final String value;
  final String subtitle;
  final IconData icon;
  final Color? iconColor;
  final String? trend;
  final bool showTrend;

  const TherapyStatisticsCard({
    super.key,
    required this.title,
    required this.value,
    required this.subtitle,
    required this.icon,
    this.iconColor,
    this.trend,
    this.showTrend = false,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: theme.cardColor,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: isDark ? const Color(0x1A000000) : const Color(0x0A000000),
            offset: const Offset(0, 1),
            blurRadius: 3,
            spreadRadius: 0,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: EdgeInsets.all(2.w),
                decoration: BoxDecoration(
                  color: (iconColor ?? AppTheme.lightTheme.primaryColor)
                      .withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: CustomIconWidget(
                  iconName: _getIconName(icon),
                  color: iconColor ?? AppTheme.lightTheme.primaryColor,
                  size: 5.w,
                ),
              ),
              const Spacer(),
              if (showTrend && trend != null)
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 1.w),
                  decoration: BoxDecoration(
                    color: _getTrendColor(trend!).withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    trend!,
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: _getTrendColor(trend!),
                      fontWeight: FontWeight.w500,
                      fontSize: 10.sp,
                    ),
                  ),
                ),
            ],
          ),
          SizedBox(height: 3.w),
          Text(
            value,
            style: theme.textTheme.headlineSmall?.copyWith(
              fontWeight: FontWeight.w600,
              fontSize: 18.sp,
              color: theme.colorScheme.onSurface,
            ),
          ),
          SizedBox(height: 1.w),
          Text(
            title,
            style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
              fontSize: 12.sp,
            ),
          ),
          if (subtitle.isNotEmpty) ...[
            SizedBox(height: 1.w),
            Text(
              subtitle,
              style: theme.textTheme.bodySmall?.copyWith(
                color: theme.colorScheme.onSurfaceVariant,
                fontSize: 10.sp,
              ),
            ),
          ],
        ],
      ),
    );
  }

  String _getIconName(IconData icon) {
    if (icon == Icons.timer_outlined) return 'timer_outlined';
    if (icon == Icons.trending_up_outlined) return 'trending_up_outlined';
    if (icon == Icons.headphones_outlined) return 'headphones_outlined';
    if (icon == Icons.favorite_outline) return 'favorite_outline';
    if (icon == Icons.analytics_outlined) return 'analytics_outlined';
    if (icon == Icons.schedule_outlined) return 'schedule_outlined';
    return 'analytics_outlined';
  }

  Color _getTrendColor(String trend) {
    if (trend.startsWith('+')) {
      return AppTheme.lightTheme.colorScheme.tertiary; // Success green
    } else if (trend.startsWith('-')) {
      return AppTheme.lightTheme.colorScheme.error; // Error red
    }
    return AppTheme.lightTheme.colorScheme.onSurfaceVariant;
  }
}
