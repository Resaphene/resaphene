import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class SessionHistoryItem extends StatelessWidget {
  final Map<String, dynamic> sessionData;
  final VoidCallback? onTap;
  final VoidCallback? onShare;
  final VoidCallback? onDetails;

  const SessionHistoryItem({
    super.key,
    required this.sessionData,
    this.onTap,
    this.onShare,
    this.onDetails,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    final date = sessionData['date'] as String;
    final duration = sessionData['duration'] as String;
    final frequency = sessionData['frequency'] as String;
    final mode = sessionData['mode'] as String;
    final effectiveness = sessionData['effectiveness'] as int;
    final notes = sessionData['notes'] as String? ?? '';

    return Slidable(
      key: ValueKey(sessionData['id']),
      endActionPane: ActionPane(
        motion: const ScrollMotion(),
        children: [
          SlidableAction(
            onPressed: (context) => onDetails?.call(),
            backgroundColor: AppTheme.lightTheme.colorScheme.primary,
            foregroundColor: Colors.white,
            icon: Icons.info_outline,
            label: 'Details',
            borderRadius: BorderRadius.circular(8),
          ),
          SlidableAction(
            onPressed: (context) => onShare?.call(),
            backgroundColor: AppTheme.lightTheme.colorScheme.secondary,
            foregroundColor: Colors.white,
            icon: Icons.share_outlined,
            label: 'Teilen',
            borderRadius: BorderRadius.circular(8),
          ),
        ],
      ),
      child: Container(
        margin: EdgeInsets.only(bottom: 3.w),
        decoration: BoxDecoration(
          color: theme.cardColor,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: isDark ? const Color(0x1A000000) : const Color(0x0A000000),
              offset: const Offset(0, 1),
              blurRadius: 3,
              spreadRadius: 0,
            ),
          ],
        ),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(12),
          child: Padding(
            padding: EdgeInsets.all(4.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: EdgeInsets.all(2.w),
                      decoration: BoxDecoration(
                        color: AppTheme.lightTheme.colorScheme.primary
                            .withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: CustomIconWidget(
                        iconName: 'headphones_outlined',
                        color: AppTheme.lightTheme.colorScheme.primary,
                        size: 5.w,
                      ),
                    ),
                    SizedBox(width: 3.w),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Therapiesitzung',
                            style: theme.textTheme.titleSmall?.copyWith(
                              fontWeight: FontWeight.w600,
                              color: theme.colorScheme.onSurface,
                            ),
                          ),
                          SizedBox(height: 1.w),
                          Text(
                            date,
                            style: theme.textTheme.bodySmall?.copyWith(
                              color: theme.colorScheme.onSurfaceVariant,
                            ),
                          ),
                        ],
                      ),
                    ),
                    _buildEffectivenessRating(effectiveness, theme),
                  ],
                ),
                SizedBox(height: 3.w),

                // Session details
                Row(
                  children: [
                    Expanded(
                      child: _buildDetailItem(
                        'Dauer',
                        duration,
                        Icons.timer_outlined,
                        theme,
                      ),
                    ),
                    SizedBox(width: 4.w),
                    Expanded(
                      child: _buildDetailItem(
                        'Frequenz',
                        frequency,
                        Icons.graphic_eq_outlined,
                        theme,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 2.w),

                Row(
                  children: [
                    Expanded(
                      child: _buildDetailItem(
                        'Modus',
                        mode,
                        Icons.settings_outlined,
                        theme,
                      ),
                    ),
                    if (notes.isNotEmpty) ...[
                      SizedBox(width: 4.w),
                      Expanded(
                        child: Container(
                          padding: EdgeInsets.symmetric(
                            horizontal: 3.w,
                            vertical: 2.w,
                          ),
                          decoration: BoxDecoration(
                            color: theme.colorScheme.surfaceContainerHighest
                                .withValues(alpha: 0.3),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Row(
                            children: [
                              CustomIconWidget(
                                iconName: 'note_outlined',
                                color: theme.colorScheme.onSurfaceVariant,
                                size: 4.w,
                              ),
                              SizedBox(width: 2.w),
                              Expanded(
                                child: Text(
                                  notes,
                                  style: theme.textTheme.bodySmall?.copyWith(
                                    color: theme.colorScheme.onSurfaceVariant,
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDetailItem(
    String label,
    String value,
    IconData icon,
    ThemeData theme,
  ) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 2.w),
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.3),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          CustomIconWidget(
            iconName: _getIconName(icon),
            color: theme.colorScheme.onSurfaceVariant,
            size: 4.w,
          ),
          SizedBox(width: 2.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.onSurfaceVariant,
                    fontSize: 9.sp,
                  ),
                ),
                Text(
                  value,
                  style: theme.textTheme.bodySmall?.copyWith(
                    fontWeight: FontWeight.w500,
                    color: theme.colorScheme.onSurface,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEffectivenessRating(int rating, ThemeData theme) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.w),
      decoration: BoxDecoration(
        color: _getEffectivenessColor(rating).withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: _getEffectivenessColor(rating).withValues(alpha: 0.3),
          width: 1,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          CustomIconWidget(
            iconName: 'star',
            color: _getEffectivenessColor(rating),
            size: 3.w,
          ),
          SizedBox(width: 1.w),
          Text(
            '$rating/5',
            style: theme.textTheme.bodySmall?.copyWith(
              color: _getEffectivenessColor(rating),
              fontWeight: FontWeight.w600,
              fontSize: 10.sp,
            ),
          ),
        ],
      ),
    );
  }

  Color _getEffectivenessColor(int rating) {
    if (rating >= 4) {
      return AppTheme.lightTheme.colorScheme.tertiary; // Green for good
    } else if (rating >= 3) {
      return const Color(0xFFF4A261); // Amber for average
    } else {
      return AppTheme.lightTheme.colorScheme.error; // Red for poor
    }
  }

  String _getIconName(IconData icon) {
    if (icon == Icons.timer_outlined) return 'timer_outlined';
    if (icon == Icons.graphic_eq_outlined) return 'graphic_eq_outlined';
    if (icon == Icons.settings_outlined) return 'settings_outlined';
    if (icon == Icons.note_outlined) return 'note_outlined';
    return 'info_outline';
  }
}
