import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class SymptomSeverityTracker extends StatelessWidget {
  final List<Map<String, dynamic>> severityData;

  const SymptomSeverityTracker({
    super.key,
    required this.severityData,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: theme.cardColor,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: isDark ? const Color(0x1A000000) : const Color(0x0A000000),
            offset: const Offset(0, 1),
            blurRadius: 3,
            spreadRadius: 0,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CustomIconWidget(
                iconName: 'favorite_outline',
                color: AppTheme.lightTheme.colorScheme.error,
                size: 6.w,
              ),
              SizedBox(width: 3.w),
              Text(
                'Symptom-Schweregrad',
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: theme.colorScheme.onSurface,
                ),
              ),
            ],
          ),
          SizedBox(height: 4.w),

          // Severity scale legend
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildSeverityLegend('Niedrig', _getSeverityColor(1), theme),
              _buildSeverityLegend('Mittel', _getSeverityColor(5), theme),
              _buildSeverityLegend('Hoch', _getSeverityColor(8), theme),
              _buildSeverityLegend('Schwer', _getSeverityColor(10), theme),
            ],
          ),
          SizedBox(height: 4.w),

          // Timeline visualization
          SizedBox(
            height: 20.h,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: severityData.length,
              itemBuilder: (context, index) {
                final data = severityData[index];
                final severity = data['severity'] as int;
                final date = data['date'] as String;

                return Container(
                  width: 12.w,
                  margin: EdgeInsets.only(right: 2.w),
                  child: Column(
                    children: [
                      Expanded(
                        child: Container(
                          width: 8.w,
                          decoration: BoxDecoration(
                            color: theme.colorScheme.outline
                                .withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Container(
                                width: 8.w,
                                height: (severity / 10) * 15.h,
                                decoration: BoxDecoration(
                                  color: _getSeverityColor(severity),
                                  borderRadius: BorderRadius.circular(4),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(height: 2.w),
                      Text(
                        date,
                        style: theme.textTheme.bodySmall?.copyWith(
                          fontSize: 8.sp,
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
          SizedBox(height: 4.w),

          // Current status
          Container(
            width: double.infinity,
            padding: EdgeInsets.all(3.w),
            decoration: BoxDecoration(
              color: theme.colorScheme.primaryContainer.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: theme.colorScheme.primary.withValues(alpha: 0.2),
                width: 1,
              ),
            ),
            child: Row(
              children: [
                CustomIconWidget(
                  iconName: 'info_outline',
                  color: theme.colorScheme.primary,
                  size: 5.w,
                ),
                SizedBox(width: 3.w),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Aktueller Trend',
                        style: theme.textTheme.bodyMedium?.copyWith(
                          fontWeight: FontWeight.w500,
                          color: theme.colorScheme.primary,
                        ),
                      ),
                      SizedBox(height: 1.w),
                      Text(
                        _getTrendAnalysis(),
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSeverityLegend(String label, Color color, ThemeData theme) {
    return Column(
      children: [
        Container(
          width: 4.w,
          height: 4.w,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        SizedBox(height: 1.w),
        Text(
          label,
          style: theme.textTheme.bodySmall?.copyWith(
            fontSize: 8.sp,
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
      ],
    );
  }

  Color _getSeverityColor(int severity) {
    if (severity <= 3) {
      return AppTheme.lightTheme.colorScheme.tertiary; // Green for low
    } else if (severity <= 6) {
      return const Color(0xFFF4A261); // Amber for medium
    } else if (severity <= 8) {
      return const Color(0xFFE76F51); // Orange for high
    } else {
      return AppTheme.lightTheme.colorScheme.error; // Red for severe
    }
  }

  String _getTrendAnalysis() {
    if (severityData.length < 2) {
      return 'Nicht genügend Daten für Trendanalyse';
    }

    final recent = severityData.take(7).toList();
    final recentAvg =
        recent.map((e) => e['severity'] as int).reduce((a, b) => a + b) /
            recent.length;

    final older = severityData.skip(7).take(7).toList();
    if (older.isEmpty) {
      return 'Symptome werden überwacht';
    }

    final olderAvg =
        older.map((e) => e['severity'] as int).reduce((a, b) => a + b) /
            older.length;

    if (recentAvg < olderAvg - 0.5) {
      return 'Verbesserung der Symptome in den letzten Tagen';
    } else if (recentAvg > olderAvg + 0.5) {
      return 'Symptome haben sich leicht verschlechtert';
    } else {
      return 'Symptome bleiben stabil';
    }
  }
}
