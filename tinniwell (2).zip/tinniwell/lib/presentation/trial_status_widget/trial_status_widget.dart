import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../services/subscription_service.dart';
import '../../theme/app_theme.dart';

/// Trial Status Widget for persistent trial period awareness
/// Provides contextual information about trial status with adaptive presentation
class TrialStatusWidget extends StatefulWidget {
  final TrialStatusDisplayMode displayMode;
  final bool isDismissible;
  final VoidCallback? onTap;

  const TrialStatusWidget({
    super.key,
    this.displayMode = TrialStatusDisplayMode.banner,
    this.isDismissible = true,
    this.onTap,
  });

  @override
  State<TrialStatusWidget> createState() => _TrialStatusWidgetState();
}

class _TrialStatusWidgetState extends State<TrialStatusWidget>
    with SingleTickerProviderStateMixin {
  final SubscriptionService _subscriptionService = SubscriptionService.instance;

  Map<String, dynamic>? _subscriptionStatus;
  bool _isLoading = true;
  bool _isDismissed = false;
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));

    _loadSubscriptionStatus();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _loadSubscriptionStatus() async {
    try {
      final status = await _subscriptionService.getSubscriptionStatus();
      if (mounted) {
        setState(() {
          _subscriptionStatus = status;
          _isLoading = false;
        });
        _animationController.forward();
      }
    } catch (error) {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  void _handleTap() {
    HapticFeedback.lightImpact();

    if (widget.onTap != null) {
      widget.onTap!();
    } else {
      Navigator.pushNamed(context, '/premium-subscription-screen');
    }
  }

  void _handleDismiss() {
    if (widget.isDismissible) {
      setState(() {
        _isDismissed = true;
      });
      _animationController.reverse();
    }
  }

  bool _shouldShowWidget() {
    if (_isLoading || _isDismissed || _subscriptionStatus == null) {
      return false;
    }

    final status = _subscriptionStatus!['status'] as String? ?? '';
    final canAccess =
        _subscriptionStatus!['can_access_premium'] as bool? ?? false;

    // Show widget for trial users or expired users
    return status == 'trial' || status == 'trial_expired' || !canAccess;
  }

  Widget _buildTrialContent(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    if (_subscriptionStatus == null) return const SizedBox.shrink();

    final status = _subscriptionStatus!['status'] as String? ?? '';
    final remainingDays =
        _subscriptionStatus!['trial_remaining_days'] as int? ?? 0;
    final canAccess =
        _subscriptionStatus!['can_access_premium'] as bool? ?? false;

    // Determine content based on trial stage
    String title;
    String subtitle;
    IconData icon;
    Color backgroundColor;
    Color textColor;

    if (status == 'trial' && remainingDays > 7) {
      // Early trial - encourage usage
      title = 'Kostenloser Test aktiv';
      subtitle =
          'Noch $remainingDays Tage • Nutzen Sie alle Premium-Funktionen';
      icon = Icons.star;
      backgroundColor = isDark
          ? Colors.blue.withValues(alpha: 0.1)
          : Colors.blue.withValues(alpha: 0.1);
      textColor = Colors.blue;
    } else if (status == 'trial' && remainingDays > 0) {
      // Final week - urgent upgrade messaging
      title = 'Test läuft bald ab';
      subtitle = 'Nur noch $remainingDays Tage • Jetzt Premium sichern';
      icon = Icons.warning;
      backgroundColor = isDark
          ? Colors.orange.withValues(alpha: 0.1)
          : Colors.orange.withValues(alpha: 0.1);
      textColor = Colors.orange;
    } else {
      // Expired trial
      title = 'Testphase beendet';
      subtitle = 'Upgraden Sie zu Premium für vollen Zugang';
      icon = Icons.lock;
      backgroundColor = isDark
          ? Colors.red.withValues(alpha: 0.1)
          : Colors.red.withValues(alpha: 0.1);
      textColor = Colors.red;
    }

    switch (widget.displayMode) {
      case TrialStatusDisplayMode.banner:
        return _buildBannerWidget(
          context,
          title,
          subtitle,
          icon,
          backgroundColor,
          textColor,
          remainingDays,
        );
      case TrialStatusDisplayMode.card:
        return _buildCardWidget(
          context,
          title,
          subtitle,
          icon,
          backgroundColor,
          textColor,
          remainingDays,
        );
    }
  }

  Widget _buildBannerWidget(
    BuildContext context,
    String title,
    String subtitle,
    IconData icon,
    Color backgroundColor,
    Color textColor,
    int remainingDays,
  ) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Dismissible(
      key: const Key('trial_banner'),
      direction: widget.isDismissible
          ? DismissDirection.horizontal
          : DismissDirection.none,
      onDismissed: (_) => _handleDismiss(),
      child: GestureDetector(
        onTap: _handleTap,
        child: Container(
          margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
          padding: EdgeInsets.all(3.w),
          decoration: BoxDecoration(
            color: backgroundColor,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: textColor.withValues(alpha: 0.3),
            ),
          ),
          child: Row(
            children: [
              Icon(
                icon,
                color: textColor,
                size: 5.w,
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: theme.textTheme.titleSmall?.copyWith(
                        color: textColor,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Text(
                      subtitle,
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: isDark
                            ? AppTheme.textSecondaryDark
                            : AppTheme.textSecondaryLight,
                        height: 1.3,
                      ),
                    ),
                  ],
                ),
              ),
              if (remainingDays > 0) ...[
                SizedBox(width: 3.w),
                _buildProgressIndicator(remainingDays, 28),
              ],
              SizedBox(width: 2.w),
              Icon(
                Icons.arrow_forward_ios,
                color: textColor,
                size: 3.w,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCardWidget(
    BuildContext context,
    String title,
    String subtitle,
    IconData icon,
    Color backgroundColor,
    Color textColor,
    int remainingDays,
  ) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return GestureDetector(
      onTap: _handleTap,
      child: Container(
        margin: EdgeInsets.symmetric(vertical: 1.h),
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
          color: backgroundColor,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: textColor.withValues(alpha: 0.3),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: EdgeInsets.all(2.w),
                  decoration: BoxDecoration(
                    color: textColor.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    icon,
                    color: textColor,
                    size: 5.w,
                  ),
                ),
                SizedBox(width: 3.w),
                Expanded(
                  child: Text(
                    title,
                    style: theme.textTheme.titleMedium?.copyWith(
                      color: textColor,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                if (widget.isDismissible)
                  GestureDetector(
                    onTap: _handleDismiss,
                    child: Icon(
                      Icons.close,
                      color: isDark
                          ? AppTheme.textSecondaryDark
                          : AppTheme.textSecondaryLight,
                      size: 5.w,
                    ),
                  ),
              ],
            ),
            SizedBox(height: 2.h),
            Text(
              subtitle,
              style: theme.textTheme.bodyMedium?.copyWith(
                color: isDark
                    ? AppTheme.textSecondaryDark
                    : AppTheme.textSecondaryLight,
                height: 1.4,
              ),
            ),
            if (remainingDays > 0) ...[
              SizedBox(height: 2.h),
              Row(
                children: [
                  Expanded(child: _buildProgressBar(remainingDays, 28)),
                  SizedBox(width: 3.w),
                  Text(
                    '$remainingDays/\$28',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: textColor,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ],
            SizedBox(height: 2.h),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _handleTap,
                style: ElevatedButton.styleFrom(
                  backgroundColor: textColor,
                  foregroundColor: Colors.white,
                  padding: EdgeInsets.symmetric(vertical: 3.w),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: Text(
                  remainingDays > 0 ? 'Premium sichern' : 'Jetzt upgraden',
                  style: theme.textTheme.titleSmall?.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProgressIndicator(int current, int total) {
    return SizedBox(
      width: 10.w,
      height: 10.w,
      child: CircularProgressIndicator(
        value: current / total,
        strokeWidth: 2,
        valueColor: AlwaysStoppedAnimation<Color>(
          current > 7 ? Colors.blue : Colors.orange,
        ),
        backgroundColor: Colors.grey.withValues(alpha: 0.3),
      ),
    );
  }

  Widget _buildProgressBar(int current, int total) {
    final progress = current / total;
    final color = current > 7 ? Colors.blue : Colors.orange;

    return Container(
      height: 1.h,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(4),
        color: Colors.grey.withValues(alpha: 0.3),
      ),
      child: FractionallySizedBox(
        alignment: Alignment.centerLeft,
        widthFactor: progress,
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(4),
            color: color,
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (!_shouldShowWidget()) {
      return const SizedBox.shrink();
    }

    return FadeTransition(
      opacity: _fadeAnimation,
      child: _buildTrialContent(context),
    );
  }
}

enum TrialStatusDisplayMode {
  banner,
  card,
}
