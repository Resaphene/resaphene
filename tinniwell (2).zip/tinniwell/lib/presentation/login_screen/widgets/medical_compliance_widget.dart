import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

/// Medical compliance badges widget displaying trust signals
/// for German healthcare certifications and GDPR compliance
class MedicalComplianceWidget extends StatelessWidget {
  const MedicalComplianceWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(
        horizontal: 6.w,
        vertical: 3.h,
      ),
      child: Column(
        children: [
          // Compliance badges row
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              // GDPR Compliance badge
              _ComplianceBadge(
                icon: 'verified_user',
                label: 'DSGVO\nkonform',
                isDark: isDark,
              ),

              // German healthcare certification
              _ComplianceBadge(
                icon: 'local_hospital',
                label: 'Medizinisch\nvalidiert',
                isDark: isDark,
              ),

              // Data security badge
              _ComplianceBadge(
                icon: 'security',
                label: 'Sichere\nDaten',
                isDark: isDark,
              ),
            ],
          ),

          SizedBox(height: 2.h),

          // Compliance text
          Text(
            'Ihre Gesundheitsdaten sind sicher und werden gemäß deutschen Datenschutzbestimmungen verarbeitet.',
            style: theme.textTheme.bodySmall?.copyWith(
              color: isDark
                  ? AppTheme.textSecondaryDark.withValues(alpha: 0.8)
                  : AppTheme.textSecondaryLight.withValues(alpha: 0.8),
              height: 1.4,
            ),
            textAlign: TextAlign.center,
          ),

          SizedBox(height: 1.h),

          // Medical device compliance
          Container(
            padding: EdgeInsets.symmetric(
              horizontal: 3.w,
              vertical: 1.h,
            ),
            decoration: BoxDecoration(
              color: isDark
                  ? AppTheme.accentDark.withValues(alpha: 0.1)
                  : AppTheme.accentLight.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: isDark
                    ? AppTheme.accentDark.withValues(alpha: 0.3)
                    : AppTheme.accentLight.withValues(alpha: 0.3),
                width: 1,
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                CustomIconWidget(
                  iconName: 'medical_services',
                  color: isDark ? AppTheme.accentDark : AppTheme.accentLight,
                  size: 4.w,
                ),
                SizedBox(width: 2.w),
                Text(
                  'CE-Kennzeichnung für Medizinprodukte',
                  style: theme.textTheme.labelSmall?.copyWith(
                    color: isDark ? AppTheme.accentDark : AppTheme.accentLight,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Individual compliance badge widget
class _ComplianceBadge extends StatelessWidget {
  final String icon;
  final String label;
  final bool isDark;

  const _ComplianceBadge({
    required this.icon,
    required this.label,
    required this.isDark,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      width: 20.w,
      padding: EdgeInsets.symmetric(
        horizontal: 2.w,
        vertical: 1.5.h,
      ),
      decoration: BoxDecoration(
        color: isDark ? AppTheme.surfaceDark : AppTheme.surfaceLight,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isDark ? AppTheme.dividerDark : AppTheme.dividerLight,
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: isDark ? AppTheme.shadowDark : AppTheme.shadowLight,
            offset: const Offset(0, 1),
            blurRadius: 2,
            spreadRadius: 0,
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          CustomIconWidget(
            iconName: icon,
            color: isDark ? AppTheme.primaryDark : AppTheme.primaryLight,
            size: 5.w,
          ),
          SizedBox(height: 0.5.h),
          Text(
            label,
            style: theme.textTheme.labelSmall?.copyWith(
              color: isDark
                  ? AppTheme.textSecondaryDark
                  : AppTheme.textSecondaryLight,
              fontWeight: FontWeight.w500,
              height: 1.2,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
