import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

/// Therapy-focused logo widget for tinniwell application
/// Displays brand logo with clinical minimalism design
class TherapyLogoWidget extends StatelessWidget {
  const TherapyLogoWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(vertical: 4.h),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // Logo container with therapeutic design
          Container(
            width: 25.w,
            height: 25.w,
            decoration: BoxDecoration(
              color: isDark
                  ? AppTheme.primaryDark.withValues(alpha: 0.1)
                  : AppTheme.primaryLight.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: isDark
                    ? AppTheme.primaryDark.withValues(alpha: 0.3)
                    : AppTheme.primaryLight.withValues(alpha: 0.3),
                width: 1,
              ),
            ),
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Sound wave icon representing tinnitus therapy
                  CustomIconWidget(
                    iconName: 'graphic_eq',
                    color:
                        isDark ? AppTheme.primaryDark : AppTheme.primaryLight,
                    size: 8.w,
                  ),
                  SizedBox(height: 1.h),
                  // Medical cross overlay for therapy indication
                  CustomIconWidget(
                    iconName: 'healing',
                    color: isDark ? AppTheme.accentDark : AppTheme.accentLight,
                    size: 4.w,
                  ),
                ],
              ),
            ),
          ),

          SizedBox(height: 3.h),

          // App name with medical typography
          Text(
            'tinniwell',
            style: theme.textTheme.headlineMedium?.copyWith(
              color:
                  isDark ? AppTheme.textPrimaryDark : AppTheme.textPrimaryLight,
              fontWeight: FontWeight.w700,
              letterSpacing: -0.5,
            ),
          ),

          SizedBox(height: 1.h),

          // Therapeutic tagline
          Text(
            'Personalisierte Tinnitus-Therapie',
            style: theme.textTheme.bodyMedium?.copyWith(
              color: isDark
                  ? AppTheme.textSecondaryDark
                  : AppTheme.textSecondaryLight,
              fontWeight: FontWeight.w400,
              letterSpacing: 0.2,
            ),
            textAlign: TextAlign.center,
          ),

          SizedBox(height: 0.5.h),

          // Medical subtitle
          Text(
            'Medizinisch validierte Audiotherapie',
            style: theme.textTheme.bodySmall?.copyWith(
              color: isDark
                  ? AppTheme.textSecondaryDark.withValues(alpha: 0.8)
                  : AppTheme.textSecondaryLight.withValues(alpha: 0.8),
              fontWeight: FontWeight.w300,
              letterSpacing: 0.1,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
