import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../services/auth_service.dart';
import '../../services/subscription_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/custom_app_bar.dart';
import '../login_screen/widgets/medical_compliance_widget.dart';
import '../login_screen/widgets/therapy_logo_widget.dart';
import './widgets/registration_form_widget.dart';

/// Registration Screen for TinniWell with 4-week free trial
/// Provides secure registration with automatic trial activation
class RegistrationScreen extends StatefulWidget {
  const RegistrationScreen({super.key});

  @override
  State<RegistrationScreen> createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  final AuthService _authService = AuthService.instance;
  final SubscriptionService _subscriptionService = SubscriptionService.instance;

  bool _isLoading = false;
  String? _errorMessage;

  Future<void> _handleRegistration({
    required String email,
    required String password,
    required String fullName,
    required bool acceptedTerms,
  }) async {
    if (!acceptedTerms) {
      setState(() {
        _errorMessage = 'Bitte akzeptieren Sie die Nutzungsbedingungen';
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      // Register user with Supabase Auth
      await _authService.signUp(
        email: email,
        password: password,
        fullName: fullName,
        role: 'patient',
      );

      if (mounted) {
        HapticFeedback.mediumImpact();

        // Show success message with trial info
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  '🎉 Willkommen bei TinniWell!',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 4),
                const Text('Ihr 4-wöchiger kostenloser Test hat begonnen.'),
                const Text(
                  'Nutzen Sie alle Premium-Funktionen ohne Einschränkung.',
                ),
              ],
            ),
            backgroundColor: AppTheme.successLight,
            duration: const Duration(seconds: 4),
          ),
        );

        // Navigate to therapy dashboard to start trial
        Navigator.pushNamedAndRemoveUntil(
          context,
          '/therapy-dashboard',
          (route) => false,
        );
      }
    } catch (error) {
      if (mounted) {
        setState(() {
          _errorMessage = _formatErrorMessage(error.toString());
        });
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  String _formatErrorMessage(String error) {
    final cleanError = error.replaceAll('Exception: ', '');

    // More specific error handling
    if (cleanError.contains('Diese E-Mail-Adresse ist bereits registriert')) {
      return 'Diese E-Mail-Adresse ist bereits registriert. Bitte melden Sie sich an.';
    }
    if (cleanError.contains('E-Mail-Adresse ist erforderlich')) {
      return 'Bitte geben Sie eine gültige E-Mail-Adresse ein.';
    }
    if (cleanError.contains('Ungültige E-Mail-Adresse')) {
      return 'Bitte geben Sie eine gültige E-Mail-Adresse ein.';
    }
    if (cleanError.contains('Passwort ist erforderlich') ||
        cleanError.contains('Passwort muss mindestens')) {
      return 'Passwort muss mindestens 8 Zeichen lang sein und einen Groß-, Kleinbuchstaben sowie eine Zahl enthalten.';
    }
    if (cleanError.contains('Name ist erforderlich')) {
      return 'Bitte geben Sie Ihren vollständigen Namen ein.';
    }
    if (cleanError.contains('Zu viele Registrierungsversuche') ||
        cleanError.contains('Zu viele Versuche')) {
      return 'Zu viele Versuche. Bitte warten Sie einige Minuten und versuchen Sie es erneut.';
    }
    if (cleanError.contains('Zeitüberschreitung')) {
      return 'Verbindung unterbrochen. Bitte überprüfen Sie Ihr Internet und versuchen Sie es erneut.';
    }
    if (cleanError.contains('Netzwerkfehler') ||
        cleanError.contains('Network')) {
      return 'Netzwerkproblem. Bitte überprüfen Sie Ihre Internetverbindung.';
    }
    if (cleanError.contains('Datenbankfehler')) {
      return 'Temporärer Serverfehler. Bitte versuchen Sie es in wenigen Minuten erneut.';
    }

    // Generic fallback
    return 'Registrierung fehlgeschlagen. Bitte versuchen Sie es erneut oder kontaktieren Sie den Support.';
  }

  void _navigateToLogin() {
    Navigator.pushReplacementNamed(context, '/login-screen');
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Scaffold(
      backgroundColor:
          isDark ? AppTheme.backgroundDark : AppTheme.backgroundLight,
      appBar: CustomAppBar(title: '', showBackButton: true),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: 6.w, vertical: 2.h),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Therapy Logo
              const TherapyLogoWidget(),

              SizedBox(height: 3.h),

              // Welcome Text
              Text(
                'Kostenlosen Test starten',
                style: theme.textTheme.headlineSmall?.copyWith(
                  color:
                      isDark
                          ? AppTheme.textPrimaryDark
                          : AppTheme.textPrimaryLight,
                  fontWeight: FontWeight.w600,
                ),
                textAlign: TextAlign.center,
              ),

              SizedBox(height: 1.h),

              Text(
                '4 Wochen kostenlos testen • Jederzeit kündbar • Keine versteckten Kosten',
                style: theme.textTheme.bodyMedium?.copyWith(
                  color:
                      isDark
                          ? AppTheme.textSecondaryDark
                          : AppTheme.textSecondaryLight,
                  height: 1.4,
                ),
                textAlign: TextAlign.center,
              ),

              SizedBox(height: 3.h),

              // Trial Benefits
              Container(
                padding: EdgeInsets.all(4.w),
                decoration: BoxDecoration(
                  color:
                      isDark
                          ? AppTheme.primaryDark.withValues(alpha: 0.1)
                          : AppTheme.primaryLight.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color:
                        isDark
                            ? AppTheme.primaryDark.withValues(alpha: 0.3)
                            : AppTheme.primaryLight.withValues(alpha: 0.3),
                    width: 1,
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(
                          Icons.verified_user,
                          color:
                              isDark
                                  ? AppTheme.primaryDark
                                  : AppTheme.primaryLight,
                          size: 20,
                        ),
                        SizedBox(width: 2.w),
                        Text(
                          'In der Testversion enthalten:',
                          style: theme.textTheme.titleSmall?.copyWith(
                            color:
                                isDark
                                    ? AppTheme.primaryDark
                                    : AppTheme.primaryLight,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 2.h),
                    _buildBenefitItem(
                      context,
                      '✓ Alle Therapie-Modi ohne Einschränkung',
                    ),
                    _buildBenefitItem(
                      context,
                      '✓ Personalisierte Einstellungen',
                    ),
                    _buildBenefitItem(
                      context,
                      '✓ Fortschritts-Tracking und Statistiken',
                    ),
                    _buildBenefitItem(context, '✓ Export der Therapiedaten'),
                    _buildBenefitItem(context, '✓ Premium-Support per E-Mail'),
                    SizedBox(height: 1.h),
                    Text(
                      'Nach 28 Tagen: 9,99€/Monat oder jederzeit kündigen',
                      style: theme.textTheme.bodySmall?.copyWith(
                        color:
                            isDark
                                ? AppTheme.textSecondaryDark
                                : AppTheme.textSecondaryLight,
                        fontStyle: FontStyle.italic,
                      ),
                    ),
                  ],
                ),
              ),

              SizedBox(height: 3.h),

              // Error Message
              if (_errorMessage != null) ...[
                Container(
                  width: double.infinity,
                  padding: EdgeInsets.all(3.w),
                  decoration: BoxDecoration(
                    color: AppTheme.errorLight.withValues(alpha: 0.1),
                    border: Border.all(
                      color: AppTheme.errorLight.withValues(alpha: 0.3),
                    ),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    _errorMessage!,
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: AppTheme.errorLight,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
                SizedBox(height: 3.h),
              ],

              // Registration Form
              RegistrationFormWidget(
                onRegister: _handleRegistration,
                isLoading: _isLoading,
              ),

              SizedBox(height: 3.h),

              // Login Link
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'Bereits ein Konto? ',
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color:
                          isDark
                              ? AppTheme.textSecondaryDark
                              : AppTheme.textSecondaryLight,
                    ),
                  ),
                  GestureDetector(
                    onTap: _isLoading ? null : _navigateToLogin,
                    child: Text(
                      'Anmelden',
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color:
                            isDark
                                ? AppTheme.primaryDark
                                : AppTheme.primaryLight,
                        fontWeight: FontWeight.w600,
                        decoration: TextDecoration.underline,
                      ),
                    ),
                  ),
                ],
              ),

              SizedBox(height: 4.h),

              // Medical Compliance
              const MedicalComplianceWidget(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBenefitItem(BuildContext context, String text) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Padding(
      padding: EdgeInsets.only(bottom: 1.h),
      child: Text(
        text,
        style: theme.textTheme.bodyMedium?.copyWith(
          color:
              isDark ? AppTheme.textSecondaryDark : AppTheme.textSecondaryLight,
          height: 1.3,
        ),
      ),
    );
  }
}
