import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../theme/app_theme.dart';

class ConsentCheckboxesWidget extends StatelessWidget {
  final bool termsAccepted;
  final bool privacyAccepted;
  final bool trialAccepted;
  final Function(bool?) onTermsChanged;
  final Function(bool?) onPrivacyChanged;
  final Function(bool?) onTrialChanged;

  const ConsentCheckboxesWidget({
    super.key,
    required this.termsAccepted,
    required this.privacyAccepted,
    required this.trialAccepted,
    required this.onTermsChanged,
    required this.onPrivacyChanged,
    required this.onTrialChanged,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          'Zustimmung erforderlich',
          style: theme.textTheme.titleSmall?.copyWith(
            color:
                isDark ? AppTheme.textPrimaryDark : AppTheme.textPrimaryLight,
            fontWeight: FontWeight.w600,
          ),
        ),

        SizedBox(height: 2.h),

        // Terms and conditions
        _buildConsentItem(
          value: termsAccepted,
          onChanged: onTermsChanged,
          title: 'Allgemeine Geschäftsbedingungen',
          description:
              'Ich akzeptiere die Nutzungsbedingungen für die medizinische Tinnitus-Therapie.',
          isRequired: true,
          hasLink: true,
          onLinkTap: () => _showTermsDialog(context),
          isDark: isDark,
          theme: theme,
        ),

        SizedBox(height: 2.h),

        // Privacy policy
        _buildConsentItem(
          value: privacyAccepted,
          onChanged: onPrivacyChanged,
          title: 'Datenschutzerklärung (DSGVO)',
          description:
              'Ich stimme der Verarbeitung meiner Daten gemäß DSGVO zu.',
          isRequired: true,
          hasLink: true,
          onLinkTap: () => _showPrivacyDialog(context),
          isDark: isDark,
          theme: theme,
        ),

        SizedBox(height: 2.h),

        // Trial conditions
        _buildConsentItem(
          value: trialAccepted,
          onChanged: onTrialChanged,
          title: 'Testphase-Bedingungen',
          description:
              'Ich bestätige, dass ich die 4-wöchige Testphase starten möchte und nach Ablauf automatisch in Premium übergehe.',
          isRequired: true,
          hasLink: true,
          onLinkTap: () => _showTrialDialog(context),
          isDark: isDark,
          theme: theme,
        ),
      ],
    );
  }

  Widget _buildConsentItem({
    required bool value,
    required Function(bool?) onChanged,
    required String title,
    required String description,
    required bool isRequired,
    bool hasLink = false,
    VoidCallback? onLinkTap,
    required bool isDark,
    required ThemeData theme,
  }) {
    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: isDark
            ? AppTheme.backgroundDark.withValues(alpha: 0.5)
            : AppTheme.backgroundLight,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: value
              ? (isDark
                  ? AppTheme.primaryDark.withValues(alpha: 0.5)
                  : AppTheme.primaryLight.withValues(alpha: 0.5))
              : (isDark
                  ? AppTheme.textSecondaryDark.withValues(alpha: 0.3)
                  : AppTheme.textSecondaryLight.withValues(alpha: 0.3)),
          width: 1,
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Checkbox
          SizedBox(
            height: 6.w,
            width: 6.w,
            child: Checkbox(
              value: value,
              onChanged: onChanged,
              activeColor:
                  isDark ? AppTheme.primaryDark : AppTheme.primaryLight,
              checkColor: Colors.white,
              side: BorderSide(
                color: isDark
                    ? AppTheme.textSecondaryDark
                    : AppTheme.textSecondaryLight,
                width: 1,
              ),
            ),
          ),

          SizedBox(width: 3.w),

          // Content
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        title,
                        style: theme.textTheme.titleSmall?.copyWith(
                          color: isDark
                              ? AppTheme.textPrimaryDark
                              : AppTheme.textPrimaryLight,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    if (isRequired)
                      Container(
                        padding: EdgeInsets.symmetric(
                          horizontal: 2.w,
                          vertical: 0.5.h,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.red.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          'Pflicht',
                          style: theme.textTheme.labelSmall?.copyWith(
                            color: Colors.red,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                  ],
                ),
                SizedBox(height: 1.h),
                Text(
                  description,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: isDark
                        ? AppTheme.textSecondaryDark
                        : AppTheme.textSecondaryLight,
                    height: 1.4,
                  ),
                ),
                if (hasLink && onLinkTap != null) ...[
                  SizedBox(height: 1.h),
                  GestureDetector(
                    onTap: onLinkTap,
                    child: Text(
                      'Details anzeigen →',
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: isDark
                            ? AppTheme.primaryDark
                            : AppTheme.primaryLight,
                        fontWeight: FontWeight.w600,
                        decoration: TextDecoration.underline,
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _showTermsDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Allgemeine Geschäftsbedingungen'),
          content: const SingleChildScrollView(
            child: Text(
              'Hier würden die vollständigen Allgemeinen Geschäftsbedingungen für TinniWell stehen.\n\n'
              'Diese umfassen:\n'
              '• Nutzungsrechte und -pflichten\n'
              '• Haftungsausschlüsse\n'
              '• Medizinische Hinweise\n'
              '• Kündigungsbedingungen\n'
              '• Kontaktinformationen\n\n'
              'In einer echten Anwendung würde hier der vollständige Rechtstext stehen.',
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Schließen'),
            ),
          ],
        );
      },
    );
  }

  void _showPrivacyDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Datenschutzerklärung'),
          content: const SingleChildScrollView(
            child: Text(
              'Diese Datenschutzerklärung informiert über die Verarbeitung personenbezogener Daten bei TinniWell.\n\n'
              'Verarbeitete Daten:\n'
              '• E-Mail-Adresse (Anmeldung)\n'
              '• Therapiedaten (Sitzungen, Fortschritt)\n'
              '• Geräteinformationen (App-Nutzung)\n'
              '• Zahlungsdaten (verschlüsselt)\n\n'
              'Rechte der Nutzer:\n'
              '• Auskunftsrecht\n'
              '• Berichtigungsrecht\n'
              '• Löschungsrecht\n'
              '• Widerspruchsrecht\n\n'
              'Kontakt: datenschutz@tinniwell.de',
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Schließen'),
            ),
          ],
        );
      },
    );
  }

  void _showTrialDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Testphase-Bedingungen'),
          content: const SingleChildScrollView(
            child: Text(
              'Bedingungen der 4-wöchigen Testphase:\n\n'
              'Leistungen:\n'
              '• Vollzugang zu allen Therapiemodi\n'
              '• Unbegrenzte Sitzungen\n'
              '• Detaillierte Fortschrittsverfolgung\n'
              '• Personalisierte Empfehlungen\n\n'
              'Nach der Testphase:\n'
              '• Automatische Umstellung auf Premium (9,99€/Monat)\n'
              '• Jederzeit kündbar\n'
              '• Keine versteckten Kosten\n\n'
              'Kündigung:\n'
              '• In den App-Einstellungen\n'
              '• Per E-Mail an support@tinniwell.de\n'
              '• Bis 24h vor Ablauf der Testphase\n\n'
              'Bei Fragen: support@tinniwell.de',
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Schließen'),
            ),
          ],
        );
      },
    );
  }
}
