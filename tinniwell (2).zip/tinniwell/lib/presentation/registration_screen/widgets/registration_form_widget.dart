import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../theme/app_theme.dart';

class RegistrationFormWidget extends StatefulWidget {
  final Function({
    required String email,
    required String password,
    required String fullName,
    required bool acceptedTerms,
  })
  onRegister;
  final bool isLoading;

  const RegistrationFormWidget({
    super.key,
    required this.onRegister,
    required this.isLoading,
  });

  @override
  State<RegistrationFormWidget> createState() => _RegistrationFormWidgetState();
}

class _RegistrationFormWidgetState extends State<RegistrationFormWidget> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController =
      TextEditingController();

  bool _obscurePassword = true;
  bool _obscureConfirmPassword = true;
  bool _acceptedTerms = false;

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }

  String? _validateName(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Bitte geben Sie Ihren vollständigen Namen ein';
    }
    if (value.trim().length < 2) {
      return 'Name muss mindestens 2 Zeichen lang sein';
    }
    return null;
  }

  String? _validateEmail(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Bitte geben Sie Ihre E-Mail-Adresse ein';
    }

    // More comprehensive email validation
    final cleanValue = value.trim().toLowerCase();
    final emailRegex = RegExp(
      r'^[a-zA-Z0-9.!#$%&*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$',
    );
    if (!emailRegex.hasMatch(cleanValue)) {
      return 'Bitte geben Sie eine gültige E-Mail-Adresse ein';
    }

    // Check for common typos
    if (cleanValue.contains('..') ||
        cleanValue.startsWith('.') ||
        cleanValue.endsWith('.')) {
      return 'Ungültige E-Mail-Adresse Format';
    }

    return null;
  }

  String? _validatePassword(String? value) {
    if (value == null || value.isEmpty) {
      return 'Bitte geben Sie ein Passwort ein';
    }
    if (value.length < 8) {
      return 'Passwort muss mindestens 8 Zeichen lang sein';
    }
    if (value.length > 72) {
      // Supabase limit
      return 'Passwort darf maximal 72 Zeichen lang sein';
    }
    if (!RegExp(r'[A-Z]').hasMatch(value)) {
      return 'Passwort muss mindestens einen Großbuchstaben enthalten';
    }
    if (!RegExp(r'[a-z]').hasMatch(value)) {
      return 'Passwort muss mindestens einen Kleinbuchstaben enthalten';
    }
    if (!RegExp(r'[0-9]').hasMatch(value)) {
      return 'Passwort muss mindestens eine Zahl enthalten';
    }

    // Check for common weak patterns
    if (RegExp(r'^(.)\1{7,}$').hasMatch(value)) {
      return 'Passwort darf nicht nur aus wiederholten Zeichen bestehen';
    }

    return null;
  }

  String? _validateConfirmPassword(String? value) {
    if (value == null || value.isEmpty) {
      return 'Bitte bestätigen Sie Ihr Passwort';
    }
    if (value != _passwordController.text) {
      return 'Passwörter stimmen nicht überein';
    }
    return null;
  }

  void _handleSubmit() {
    // Add haptic feedback
    HapticFeedback.lightImpact();

    if (_formKey.currentState?.validate() ?? false) {
      if (!_acceptedTerms) {
        // Show terms error with haptic feedback
        HapticFeedback.heavyImpact();
        return;
      }

      widget.onRegister(
        email: _emailController.text.trim(),
        password: _passwordController.text,
        fullName: _nameController.text.trim(),
        acceptedTerms: _acceptedTerms,
      );
    } else {
      // Validation failed, provide haptic feedback
      HapticFeedback.heavyImpact();
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Full Name Field
          TextFormField(
            controller: _nameController,
            enabled: !widget.isLoading,
            textInputAction: TextInputAction.next,
            keyboardType: TextInputType.name,
            validator: _validateName,
            decoration: InputDecoration(
              labelText: 'Vollständiger Name',
              hintText: 'z.B. Max Mustermann',
              prefixIcon: Icon(
                Icons.person_outline,
                color:
                    isDark
                        ? AppTheme.textSecondaryDark
                        : AppTheme.textSecondaryLight,
              ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(
                  color: isDark ? AppTheme.dividerDark : AppTheme.dividerLight,
                ),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(
                  color: isDark ? AppTheme.dividerDark : AppTheme.dividerLight,
                ),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(
                  color: isDark ? AppTheme.primaryDark : AppTheme.primaryLight,
                  width: 2,
                ),
              ),
              errorBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: AppTheme.errorLight, width: 2),
              ),
              focusedErrorBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: AppTheme.errorLight, width: 2),
              ),
              filled: true,
              fillColor: isDark ? AppTheme.surfaceDark : AppTheme.surfaceLight,
            ),
          ),

          SizedBox(height: 2.h),

          // Email Field
          TextFormField(
            controller: _emailController,
            enabled: !widget.isLoading,
            textInputAction: TextInputAction.next,
            keyboardType: TextInputType.emailAddress,
            validator: _validateEmail,
            decoration: InputDecoration(
              labelText: 'E-Mail-Adresse',
              hintText: 'ihre.email@beispiel.de',
              prefixIcon: Icon(
                Icons.email_outlined,
                color:
                    isDark
                        ? AppTheme.textSecondaryDark
                        : AppTheme.textSecondaryLight,
              ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(
                  color: isDark ? AppTheme.dividerDark : AppTheme.dividerLight,
                ),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(
                  color: isDark ? AppTheme.dividerDark : AppTheme.dividerLight,
                ),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(
                  color: isDark ? AppTheme.primaryDark : AppTheme.primaryLight,
                  width: 2,
                ),
              ),
              errorBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: AppTheme.errorLight, width: 2),
              ),
              focusedErrorBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: AppTheme.errorLight, width: 2),
              ),
              filled: true,
              fillColor: isDark ? AppTheme.surfaceDark : AppTheme.surfaceLight,
            ),
          ),

          SizedBox(height: 2.h),

          // Password Field
          TextFormField(
            controller: _passwordController,
            enabled: !widget.isLoading,
            obscureText: _obscurePassword,
            textInputAction: TextInputAction.next,
            validator: _validatePassword,
            decoration: InputDecoration(
              labelText: 'Passwort',
              hintText: 'Mindestens 8 Zeichen',
              prefixIcon: Icon(
                Icons.lock_outline,
                color:
                    isDark
                        ? AppTheme.textSecondaryDark
                        : AppTheme.textSecondaryLight,
              ),
              suffixIcon: IconButton(
                onPressed: () {
                  setState(() {
                    _obscurePassword = !_obscurePassword;
                  });
                },
                icon: Icon(
                  _obscurePassword ? Icons.visibility : Icons.visibility_off,
                  color:
                      isDark
                          ? AppTheme.textSecondaryDark
                          : AppTheme.textSecondaryLight,
                ),
              ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(
                  color: isDark ? AppTheme.dividerDark : AppTheme.dividerLight,
                ),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(
                  color: isDark ? AppTheme.dividerDark : AppTheme.dividerLight,
                ),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(
                  color: isDark ? AppTheme.primaryDark : AppTheme.primaryLight,
                  width: 2,
                ),
              ),
              errorBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: AppTheme.errorLight, width: 2),
              ),
              focusedErrorBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: AppTheme.errorLight, width: 2),
              ),
              filled: true,
              fillColor: isDark ? AppTheme.surfaceDark : AppTheme.surfaceLight,
            ),
          ),

          SizedBox(height: 2.h),

          // Confirm Password Field
          TextFormField(
            controller: _confirmPasswordController,
            enabled: !widget.isLoading,
            obscureText: _obscureConfirmPassword,
            textInputAction: TextInputAction.done,
            validator: _validateConfirmPassword,
            onFieldSubmitted: (_) => _handleSubmit(),
            decoration: InputDecoration(
              labelText: 'Passwort bestätigen',
              hintText: 'Passwort erneut eingeben',
              prefixIcon: Icon(
                Icons.lock_outline,
                color:
                    isDark
                        ? AppTheme.textSecondaryDark
                        : AppTheme.textSecondaryLight,
              ),
              suffixIcon: IconButton(
                onPressed: () {
                  setState(() {
                    _obscureConfirmPassword = !_obscureConfirmPassword;
                  });
                },
                icon: Icon(
                  _obscureConfirmPassword
                      ? Icons.visibility
                      : Icons.visibility_off,
                  color:
                      isDark
                          ? AppTheme.textSecondaryDark
                          : AppTheme.textSecondaryLight,
                ),
              ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(
                  color: isDark ? AppTheme.dividerDark : AppTheme.dividerLight,
                ),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(
                  color: isDark ? AppTheme.dividerDark : AppTheme.dividerLight,
                ),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(
                  color: isDark ? AppTheme.primaryDark : AppTheme.primaryLight,
                  width: 2,
                ),
              ),
              errorBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: AppTheme.errorLight, width: 2),
              ),
              focusedErrorBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: AppTheme.errorLight, width: 2),
              ),
              filled: true,
              fillColor: isDark ? AppTheme.surfaceDark : AppTheme.surfaceLight,
            ),
          ),

          SizedBox(height: 3.h),

          // Terms Acceptance Checkbox
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Checkbox(
                value: _acceptedTerms,
                onChanged:
                    widget.isLoading
                        ? null
                        : (value) {
                          setState(() {
                            _acceptedTerms = value ?? false;
                          });
                        },
                activeColor:
                    isDark ? AppTheme.primaryDark : AppTheme.primaryLight,
                side: BorderSide(
                  color: isDark ? AppTheme.dividerDark : AppTheme.dividerLight,
                ),
              ),
              Expanded(
                child: GestureDetector(
                  onTap:
                      widget.isLoading
                          ? null
                          : () {
                            setState(() {
                              _acceptedTerms = !_acceptedTerms;
                            });
                          },
                  child: Padding(
                    padding: EdgeInsets.only(top: 3.w),
                    child: RichText(
                      text: TextSpan(
                        style: theme.textTheme.bodySmall?.copyWith(
                          color:
                              isDark
                                  ? AppTheme.textSecondaryDark
                                  : AppTheme.textSecondaryLight,
                          height: 1.4,
                        ),
                        children: [
                          const TextSpan(text: 'Ich akzeptiere die '),
                          TextSpan(
                            text: 'Nutzungsbedingungen',
                            style: TextStyle(
                              color:
                                  isDark
                                      ? AppTheme.primaryDark
                                      : AppTheme.primaryLight,
                              decoration: TextDecoration.underline,
                            ),
                          ),
                          const TextSpan(text: ' und die '),
                          TextSpan(
                            text: 'Datenschutzerklärung',
                            style: TextStyle(
                              color:
                                  isDark
                                      ? AppTheme.primaryDark
                                      : AppTheme.primaryLight,
                              decoration: TextDecoration.underline,
                            ),
                          ),
                          const TextSpan(
                            text:
                                '. Nach der 4-wöchigen Testphase wird das Abo automatisch für 9,99€/Monat verlängert, sofern nicht gekündigt wird.',
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),

          SizedBox(height: 4.h),

          // Register Button
          ElevatedButton(
            onPressed: widget.isLoading ? null : _handleSubmit,
            style: ElevatedButton.styleFrom(
              backgroundColor:
                  isDark ? AppTheme.primaryDark : AppTheme.primaryLight,
              foregroundColor: Colors.white,
              padding: EdgeInsets.symmetric(vertical: 4.w),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              elevation: 2,
            ),
            child:
                widget.isLoading
                    ? SizedBox(
                      height: 5.w,
                      width: 5.w,
                      child: const CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                      ),
                    )
                    : Text(
                      'Kostenlosen Test starten',
                      style: theme.textTheme.titleMedium?.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
          ),
        ],
      ),
    );
  }
}