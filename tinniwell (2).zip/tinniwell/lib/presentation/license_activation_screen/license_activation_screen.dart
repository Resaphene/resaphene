import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../widgets/custom_app_bar.dart';
import './widgets/activation_button_widget.dart';
import './widgets/compliance_info_widget.dart';
import './widgets/license_input_widget.dart';
import './widgets/progress_indicator_widget.dart';
import './widgets/qr_scanner_button_widget.dart';
import './widgets/validation_status_widget.dart';

class LicenseActivationScreen extends StatefulWidget {
  const LicenseActivationScreen({super.key});

  @override
  State<LicenseActivationScreen> createState() =>
      _LicenseActivationScreenState();
}

class _LicenseActivationScreenState extends State<LicenseActivationScreen>
    with TickerProviderStateMixin {
  String _licenseKey = '';
  ValidationStatus _validationStatus = ValidationStatus.idle;
  ActivationStep _currentStep = ActivationStep.input;
  String? _errorMessage;
  bool _isLoading = false;
  late AnimationController _successAnimationController;
  late Animation<double> _successAnimation;

  // Mock valid license keys for demonstration
  final List<String> _validLicenseKeys = [
    'TINN2025WELL0001',
    'DEMO2025TEST0001',
    'EVAL2025DEMO0001',
  ];

  @override
  void initState() {
    super.initState();
    _successAnimationController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );
    _successAnimation = CurvedAnimation(
      parent: _successAnimationController,
      curve: Curves.elasticOut,
    );
  }

  @override
  void dispose() {
    _successAnimationController.dispose();
    super.dispose();
  }

  void _onLicenseChanged(String license) {
    setState(() {
      _licenseKey = license;
      _errorMessage = null;
      _validationStatus = ValidationStatus.idle;
      _currentStep = ActivationStep.input;
    });
  }

  void _onQrCodeScanned(String qrCode) {
    // Extract license key from QR code (assuming it contains just the license key)
    String extractedKey =
        qrCode.replaceAll(RegExp(r'[^A-Za-z0-9]'), '').toUpperCase();
    if (extractedKey.length >= 16) {
      extractedKey = extractedKey.substring(0, 16);
      setState(() {
        _licenseKey = extractedKey;
        _errorMessage = null;
        _validationStatus = ValidationStatus.idle;
        _currentStep = ActivationStep.input;
      });

      // Auto-trigger validation after QR scan
      Future.delayed(const Duration(milliseconds: 500), () {
        _activateLicense();
      });
    } else {
      setState(() {
        _errorMessage = 'QR-Code enthält keinen gültigen Lizenzschlüssel';
      });
    }
  }

  Future<void> _activateLicense() async {
    if (_licenseKey.length != 16 || _isLoading) return;

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _validationStatus = ValidationStatus.checking;
      _currentStep = ActivationStep.validation;
    });

    try {
      // Step 1: Check license format and validity
      await Future.delayed(const Duration(seconds: 2));

      if (!_validLicenseKeys.contains(_licenseKey)) {
        throw Exception('invalid_license');
      }

      // Step 2: Verify medical compliance
      setState(() {
        _validationStatus = ValidationStatus.verifying;
      });
      await Future.delayed(const Duration(seconds: 2));

      // Step 3: Activate therapy features
      setState(() {
        _validationStatus = ValidationStatus.activating;
        _currentStep = ActivationStep.activation;
      });
      await Future.delayed(const Duration(seconds: 2));

      // Step 4: Success
      setState(() {
        _validationStatus = ValidationStatus.success;
        _currentStep = ActivationStep.complete;
        _isLoading = false;
      });

      // Play success animation
      _successAnimationController.forward();
      HapticFeedback.lightImpact();

      // Navigate to therapy dashboard after success
      Future.delayed(const Duration(seconds: 3), () {
        if (mounted) {
          Navigator.pushNamedAndRemoveUntil(
            context,
            '/therapy-dashboard',
            (route) => false,
          );
        }
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
        _validationStatus = ValidationStatus.error;
        _currentStep = ActivationStep.input;
        _errorMessage = _getErrorMessage(e.toString());
      });
      HapticFeedback.heavyImpact();
    }
  }

  String _getErrorMessage(String error) {
    switch (error) {
      case 'Exception: invalid_license':
        return 'Ungültiger Lizenzschlüssel. Bitte überprüfen Sie Ihre Eingabe.';
      case 'Exception: expired_license':
        return 'Dieser Lizenzschlüssel ist abgelaufen. Kontaktieren Sie den Support.';
      case 'Exception: already_activated':
        return 'Dieser Lizenzschlüssel wurde bereits aktiviert.';
      case 'Exception: network_error':
        return 'Netzwerkfehler. Bitte überprüfen Sie Ihre Internetverbindung.';
      default:
        return 'Ein unerwarteter Fehler ist aufgetreten. Bitte versuchen Sie es erneut.';
    }
  }

  String? _getValidationMessage() {
    switch (_validationStatus) {
      case ValidationStatus.checking:
        return 'Lizenzformat wird überprüft...';
      case ValidationStatus.verifying:
        return 'Medizinische Zulassung wird verifiziert...';
      case ValidationStatus.activating:
        return 'Therapie-Module werden freigeschaltet...';
      case ValidationStatus.success:
        return 'Alle Therapie-Features sind jetzt verfügbar';
      case ValidationStatus.error:
        return null;
      default:
        return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Scaffold(
      backgroundColor:
          isDark ? AppTheme.backgroundDark : AppTheme.backgroundLight,
      appBar: CustomAppBar.licenseActivation(context),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: 6.w, vertical: 2.h),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header with progress indicator
              ProgressIndicatorWidget(currentStep: _currentStep),

              SizedBox(height: 3.h),

              // Welcome text
              Text(
                'Willkommen bei TinniWell',
                style: theme.textTheme.headlineMedium?.copyWith(
                  fontWeight: FontWeight.w700,
                  color: isDark
                      ? AppTheme.textPrimaryDark
                      : AppTheme.textPrimaryLight,
                ),
              ),

              SizedBox(height: 1.h),

              Text(
                'Aktivieren Sie Ihre Lizenz, um Zugang zu personalisierten Tinnitus-Therapien zu erhalten.',
                style: theme.textTheme.bodyLarge?.copyWith(
                  color: isDark
                      ? AppTheme.textSecondaryDark
                      : AppTheme.textSecondaryLight,
                  height: 1.4,
                ),
              ),

              SizedBox(height: 4.h),

              // License input
              LicenseInputWidget(
                onLicenseChanged: _onLicenseChanged,
                errorMessage: _errorMessage,
                isLoading: _isLoading,
              ),

              SizedBox(height: 3.h),

              // QR scanner button
              Center(
                child: QrScannerButtonWidget(
                  onQrCodeScanned: _onQrCodeScanned,
                  isEnabled: !_isLoading,
                ),
              ),

              // Validation status
              ValidationStatusWidget(
                status: _validationStatus,
                message: _getValidationMessage(),
              ),

              // Activation button
              ActivationButtonWidget(
                onPressed: _activateLicense,
                isLoading: _isLoading,
                isEnabled: !_isLoading,
                licenseKey: _licenseKey,
              ),

              // Compliance information
              const ComplianceInfoWidget(),

              SizedBox(height: 2.h),

              // Support information
              Container(
                padding: EdgeInsets.all(4.w),
                decoration: BoxDecoration(
                  color: (isDark ? AppTheme.primaryDark : AppTheme.primaryLight)
                      .withValues(alpha: 0.05),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color:
                        (isDark ? AppTheme.primaryDark : AppTheme.primaryLight)
                            .withValues(alpha: 0.1),
                    width: 1,
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        CustomIconWidget(
                          iconName: 'support_agent',
                          color: isDark
                              ? AppTheme.primaryDark
                              : AppTheme.primaryLight,
                          size: 20,
                        ),
                        SizedBox(width: 3.w),
                        Text(
                          'Benötigen Sie Hilfe?',
                          style: theme.textTheme.titleSmall?.copyWith(
                            fontWeight: FontWeight.w600,
                            color: isDark
                                ? AppTheme.textPrimaryDark
                                : AppTheme.textPrimaryLight,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 2.h),
                    Text(
                      'Bei Problemen mit der Lizenzaktivierung kontaktieren Sie unseren Support unter support@tinniwell.de oder +49 (0) 800 123 4567.',
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: isDark
                            ? AppTheme.textSecondaryDark
                            : AppTheme.textSecondaryLight,
                        height: 1.4,
                      ),
                    ),
                  ],
                ),
              ),

              SizedBox(height: 4.h),
            ],
          ),
        ),
      ),
    );
  }
}