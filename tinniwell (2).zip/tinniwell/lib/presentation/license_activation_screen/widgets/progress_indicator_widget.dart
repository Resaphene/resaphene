import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

enum ActivationStep {
  input,
  validation,
  activation,
  complete,
}

class ProgressIndicatorWidget extends StatelessWidget {
  final ActivationStep currentStep;

  const ProgressIndicatorWidget({
    super.key,
    required this.currentStep,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    final steps = [
      _StepData('Eingabe', 'Lizenzschlüssel eingeben', 'edit'),
      _StepData('Validierung', 'Lizenz überprüfen', 'verified_user'),
      _StepData('Aktivierung', 'Features freischalten', 'settings'),
      _StepData('Abschluss', 'Therapie bereit', 'check_circle'),
    ];

    return Container(
      margin: EdgeInsets.symmetric(vertical: 2.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Aktivierungsfortschritt',
            style: theme.textTheme.titleSmall?.copyWith(
              fontWeight: FontWeight.w600,
              color:
                  isDark ? AppTheme.textPrimaryDark : AppTheme.textPrimaryLight,
            ),
          ),
          SizedBox(height: 2.h),
          Row(
            children: steps.asMap().entries.map((entry) {
              final index = entry.key;
              final step = entry.value;
              final isActive = index <= currentStep.index;
              final isCurrent = index == currentStep.index;

              return Expanded(
                child: Row(
                  children: [
                    Expanded(
                      child: _buildStepItem(
                        context,
                        step,
                        isActive,
                        isCurrent,
                        isDark,
                      ),
                    ),
                    if (index < steps.length - 1)
                      _buildConnector(isActive, isDark),
                  ],
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildStepItem(
    BuildContext context,
    _StepData step,
    bool isActive,
    bool isCurrent,
    bool isDark,
  ) {
    final theme = Theme.of(context);

    final activeColor = isDark ? AppTheme.primaryDark : AppTheme.primaryLight;
    final inactiveColor =
        isDark ? AppTheme.textDisabledDark : AppTheme.textDisabledLight;
    final currentColor = isDark ? AppTheme.accentDark : AppTheme.accentLight;

    return Column(
      children: [
        Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: isCurrent
                ? currentColor.withValues(alpha: 0.1)
                : isActive
                    ? activeColor.withValues(alpha: 0.1)
                    : inactiveColor.withValues(alpha: 0.1),
            border: Border.all(
              color: isCurrent
                  ? currentColor
                  : isActive
                      ? activeColor
                      : inactiveColor,
              width: isCurrent ? 2 : 1,
            ),
            borderRadius: BorderRadius.circular(20),
          ),
          child: isCurrent
              ? SizedBox(
                  width: 20,
                  height: 20,
                  child: Center(
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      valueColor: AlwaysStoppedAnimation<Color>(currentColor),
                    ),
                  ),
                )
              : Center(
                  child: CustomIconWidget(
                    iconName: step.iconName,
                    color: isCurrent
                        ? currentColor
                        : isActive
                            ? activeColor
                            : inactiveColor,
                    size: 20,
                  ),
                ),
        ),
        SizedBox(height: 1.h),
        Text(
          step.title,
          textAlign: TextAlign.center,
          style: theme.textTheme.bodySmall?.copyWith(
            fontWeight: isCurrent ? FontWeight.w600 : FontWeight.w500,
            color: isCurrent
                ? currentColor
                : isActive
                    ? (isDark
                        ? AppTheme.textPrimaryDark
                        : AppTheme.textPrimaryLight)
                    : inactiveColor,
          ),
        ),
      ],
    );
  }

  Widget _buildConnector(bool isActive, bool isDark) {
    return Container(
      width: 4.w,
      height: 2,
      margin: EdgeInsets.only(bottom: 4.h),
      decoration: BoxDecoration(
        color: isActive
            ? (isDark ? AppTheme.primaryDark : AppTheme.primaryLight)
            : (isDark ? AppTheme.dividerDark : AppTheme.dividerLight),
        borderRadius: BorderRadius.circular(1),
      ),
    );
  }
}

class _StepData {
  final String title;
  final String description;
  final String iconName;

  const _StepData(this.title, this.description, this.iconName);
}
