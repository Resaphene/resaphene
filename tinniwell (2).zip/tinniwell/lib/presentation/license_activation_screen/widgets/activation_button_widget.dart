import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class ActivationButtonWidget extends StatelessWidget {
  final VoidCallback? onPressed;
  final bool isLoading;
  final bool isEnabled;
  final String? licenseKey;

  const ActivationButtonWidget({
    super.key,
    this.onPressed,
    this.isLoading = false,
    this.isEnabled = true,
    this.licenseKey,
  });

  bool get _canActivate {
    return isEnabled &&
        !isLoading &&
        licenseKey != null &&
        licenseKey!.length == 16;
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Container(
      width: double.infinity,
      margin: EdgeInsets.symmetric(vertical: 2.h),
      child: ElevatedButton(
        onPressed: _canActivate
            ? () {
                HapticFeedback.mediumImpact();
                onPressed?.call();
              }
            : null,
        style: ElevatedButton.styleFrom(
          backgroundColor: _canActivate
              ? (isDark ? AppTheme.primaryDark : AppTheme.primaryLight)
              : (isDark
                  ? AppTheme.textDisabledDark
                  : AppTheme.textDisabledLight),
          foregroundColor: _canActivate
              ? Colors.white
              : (isDark
                  ? AppTheme.textSecondaryDark
                  : AppTheme.textSecondaryLight),
          padding: EdgeInsets.symmetric(vertical: 3.h),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          elevation: _canActivate ? 2 : 0,
          shadowColor: isDark ? AppTheme.shadowDark : AppTheme.shadowLight,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (isLoading) ...[
              SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  valueColor: const AlwaysStoppedAnimation<Color>(Colors.white),
                ),
              ),
              SizedBox(width: 3.w),
            ] else if (_canActivate) ...[
              CustomIconWidget(
                iconName: 'lock_open',
                color: Colors.white,
                size: 20,
              ),
              SizedBox(width: 3.w),
            ],
            Text(
              isLoading
                  ? 'Wird aktiviert...'
                  : _canActivate
                      ? 'Lizenz aktivieren'
                      : 'Lizenzschlüssel eingeben',
              style: theme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
                color: _canActivate
                    ? Colors.white
                    : (isDark
                        ? AppTheme.textSecondaryDark
                        : AppTheme.textSecondaryLight),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
