import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class LicenseInputWidget extends StatefulWidget {
  final Function(String) onLicenseChanged;
  final String? errorMessage;
  final bool isLoading;

  const LicenseInputWidget({
    super.key,
    required this.onLicenseChanged,
    this.errorMessage,
    this.isLoading = false,
  });

  @override
  State<LicenseInputWidget> createState() => _LicenseInputWidgetState();
}

class _LicenseInputWidgetState extends State<LicenseInputWidget> {
  final TextEditingController _controller = TextEditingController();
  final FocusNode _focusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    _controller.addListener(_onTextChanged);
  }

  @override
  void dispose() {
    _controller.removeListener(_onTextChanged);
    _controller.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  void _onTextChanged() {
    String text = _controller.text;
    String formatted = _formatLicenseKey(text);

    if (formatted != text) {
      _controller.value = TextEditingValue(
        text: formatted,
        selection: TextSelection.collapsed(offset: formatted.length),
      );
    }

    widget.onLicenseChanged(formatted.replaceAll('-', ''));

    // Haptic feedback when complete
    if (formatted.length == 19) {
      // XXXX-XXXX-XXXX-XXXX
      HapticFeedback.lightImpact();
    }
  }

  String _formatLicenseKey(String input) {
    // Remove all non-alphanumeric characters
    String cleaned =
        input.replaceAll(RegExp(r'[^A-Za-z0-9]'), '').toUpperCase();

    // Limit to 16 characters
    if (cleaned.length > 16) {
      cleaned = cleaned.substring(0, 16);
    }

    // Add hyphens every 4 characters
    String formatted = '';
    for (int i = 0; i < cleaned.length; i++) {
      if (i > 0 && i % 4 == 0) {
        formatted += '-';
      }
      formatted += cleaned[i];
    }

    return formatted;
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Lizenzschlüssel eingeben',
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
            color:
                isDark ? AppTheme.textPrimaryDark : AppTheme.textPrimaryLight,
          ),
        ),
        SizedBox(height: 2.h),
        Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: widget.errorMessage != null
                  ? (isDark ? AppTheme.errorDark : AppTheme.errorLight)
                  : _focusNode.hasFocus
                      ? (isDark ? AppTheme.primaryDark : AppTheme.primaryLight)
                      : (isDark ? AppTheme.dividerDark : AppTheme.dividerLight),
              width: _focusNode.hasFocus ? 2.0 : 1.0,
            ),
            color: isDark ? AppTheme.surfaceDark : AppTheme.surfaceLight,
          ),
          child: TextField(
            controller: _controller,
            focusNode: _focusNode,
            keyboardType: TextInputType.text,
            textCapitalization: TextCapitalization.characters,
            textAlign: TextAlign.center,
            enabled: !widget.isLoading,
            style: theme.textTheme.headlineSmall?.copyWith(
              fontWeight: FontWeight.w600,
              letterSpacing: 2.0,
              color:
                  isDark ? AppTheme.textPrimaryDark : AppTheme.textPrimaryLight,
            ),
            decoration: InputDecoration(
              hintText: 'XXXX-XXXX-XXXX-XXXX',
              hintStyle: theme.textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.w400,
                letterSpacing: 2.0,
                color: isDark
                    ? AppTheme.textDisabledDark
                    : AppTheme.textDisabledLight,
              ),
              border: InputBorder.none,
              contentPadding: EdgeInsets.symmetric(
                horizontal: 4.w,
                vertical: 3.h,
              ),
            ),
            inputFormatters: [
              FilteringTextInputFormatter.allow(RegExp(r'[A-Za-z0-9\-]')),
              LengthLimitingTextInputFormatter(19), // XXXX-XXXX-XXXX-XXXX
            ],
          ),
        ),
        if (widget.errorMessage != null) ...[
          SizedBox(height: 1.h),
          Row(
            children: [
              CustomIconWidget(
                iconName: 'error_outline',
                color: isDark ? AppTheme.errorDark : AppTheme.errorLight,
                size: 16,
              ),
              SizedBox(width: 2.w),
              Expanded(
                child: Text(
                  widget.errorMessage!,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: isDark ? AppTheme.errorDark : AppTheme.errorLight,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
        ],
        SizedBox(height: 1.h),
        Text(
          'Geben Sie Ihren 16-stelligen Lizenzschlüssel ein',
          style: theme.textTheme.bodySmall?.copyWith(
            color: isDark
                ? AppTheme.textSecondaryDark
                : AppTheme.textSecondaryLight,
          ),
        ),
      ],
    );
  }
}
