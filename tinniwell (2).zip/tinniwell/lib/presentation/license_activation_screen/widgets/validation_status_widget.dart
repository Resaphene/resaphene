import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

enum ValidationStatus {
  idle,
  checking,
  verifying,
  activating,
  success,
  error,
}

class ValidationStatusWidget extends StatelessWidget {
  final ValidationStatus status;
  final String? message;

  const ValidationStatusWidget({
    super.key,
    required this.status,
    this.message,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    if (status == ValidationStatus.idle) {
      return const SizedBox.shrink();
    }

    return Container(
      margin: EdgeInsets.symmetric(vertical: 2.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: _getBackgroundColor(isDark),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: _getBorderColor(isDark),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          _buildStatusIcon(isDark),
          SizedBox(width: 3.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _getStatusTitle(),
                  style: theme.textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: _getTextColor(isDark),
                  ),
                ),
                if (message != null) ...[
                  SizedBox(height: 0.5.h),
                  Text(
                    message!,
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: _getSecondaryTextColor(isDark),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusIcon(bool isDark) {
    switch (status) {
      case ValidationStatus.checking:
      case ValidationStatus.verifying:
      case ValidationStatus.activating:
        return SizedBox(
          width: 20,
          height: 20,
          child: CircularProgressIndicator(
            strokeWidth: 2,
            valueColor: AlwaysStoppedAnimation<Color>(
              isDark ? AppTheme.primaryDark : AppTheme.primaryLight,
            ),
          ),
        );
      case ValidationStatus.success:
        return Container(
          padding: const EdgeInsets.all(2),
          decoration: BoxDecoration(
            color: isDark ? AppTheme.successDark : AppTheme.successLight,
            shape: BoxShape.circle,
          ),
          child: CustomIconWidget(
            iconName: 'check',
            color: Colors.white,
            size: 16,
          ),
        );
      case ValidationStatus.error:
        return Container(
          padding: const EdgeInsets.all(2),
          decoration: BoxDecoration(
            color: isDark ? AppTheme.errorDark : AppTheme.errorLight,
            shape: BoxShape.circle,
          ),
          child: CustomIconWidget(
            iconName: 'close',
            color: Colors.white,
            size: 16,
          ),
        );
      default:
        return const SizedBox.shrink();
    }
  }

  String _getStatusTitle() {
    switch (status) {
      case ValidationStatus.checking:
        return 'Lizenz wird überprüft...';
      case ValidationStatus.verifying:
        return 'Medizinische Compliance wird verifiziert...';
      case ValidationStatus.activating:
        return 'Therapie-Features werden aktiviert...';
      case ValidationStatus.success:
        return 'Lizenz erfolgreich aktiviert';
      case ValidationStatus.error:
        return 'Aktivierung fehlgeschlagen';
      default:
        return '';
    }
  }

  Color _getBackgroundColor(bool isDark) {
    switch (status) {
      case ValidationStatus.success:
        return (isDark ? AppTheme.successDark : AppTheme.successLight)
            .withValues(alpha: 0.1);
      case ValidationStatus.error:
        return (isDark ? AppTheme.errorDark : AppTheme.errorLight)
            .withValues(alpha: 0.1);
      default:
        return (isDark ? AppTheme.primaryDark : AppTheme.primaryLight)
            .withValues(alpha: 0.1);
    }
  }

  Color _getBorderColor(bool isDark) {
    switch (status) {
      case ValidationStatus.success:
        return (isDark ? AppTheme.successDark : AppTheme.successLight)
            .withValues(alpha: 0.3);
      case ValidationStatus.error:
        return (isDark ? AppTheme.errorDark : AppTheme.errorLight)
            .withValues(alpha: 0.3);
      default:
        return (isDark ? AppTheme.primaryDark : AppTheme.primaryLight)
            .withValues(alpha: 0.3);
    }
  }

  Color _getTextColor(bool isDark) {
    switch (status) {
      case ValidationStatus.success:
        return isDark ? AppTheme.successDark : AppTheme.successLight;
      case ValidationStatus.error:
        return isDark ? AppTheme.errorDark : AppTheme.errorLight;
      default:
        return isDark ? AppTheme.textPrimaryDark : AppTheme.textPrimaryLight;
    }
  }

  Color _getSecondaryTextColor(bool isDark) {
    return isDark ? AppTheme.textSecondaryDark : AppTheme.textSecondaryLight;
  }
}
