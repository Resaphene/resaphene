import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class QrScannerButtonWidget extends StatefulWidget {
  final Function(String) onQrCodeScanned;
  final bool isEnabled;

  const QrScannerButtonWidget({
    super.key,
    required this.onQrCodeScanned,
    this.isEnabled = true,
  });

  @override
  State<QrScannerButtonWidget> createState() => _QrScannerButtonWidgetState();
}

class _QrScannerButtonWidgetState extends State<QrScannerButtonWidget> {
  bool _isScanning = false;

  Future<void> _startQrScanning() async {
    if (!widget.isEnabled || _isScanning) return;

    // Request camera permission
    final permission = await Permission.camera.request();
    if (!permission.isGranted) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Kamera-Berechtigung erforderlich für QR-Code-Scan'),
            duration: Duration(seconds: 3),
          ),
        );
      }
      return;
    }

    setState(() => _isScanning = true);
    HapticFeedback.lightImpact();

    try {
      final result = await Navigator.push<String>(
        context,
        MaterialPageRoute(
          builder: (context) => _QrScannerScreen(
            onCodeScanned: (code) {
              Navigator.pop(context, code);
            },
          ),
        ),
      );

      if (result != null && result.isNotEmpty) {
        widget.onQrCodeScanned(result);
        HapticFeedback.mediumImpact();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('QR-Code-Scanner konnte nicht geöffnet werden'),
            duration: Duration(seconds: 3),
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isScanning = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return OutlinedButton.icon(
      onPressed: widget.isEnabled && !_isScanning ? _startQrScanning : null,
      icon: _isScanning
          ? SizedBox(
              width: 20,
              height: 20,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                valueColor: AlwaysStoppedAnimation<Color>(
                  isDark ? AppTheme.primaryDark : AppTheme.primaryLight,
                ),
              ),
            )
          : CustomIconWidget(
              iconName: 'qr_code_scanner',
              color: widget.isEnabled
                  ? (isDark ? AppTheme.primaryDark : AppTheme.primaryLight)
                  : (isDark
                      ? AppTheme.textDisabledDark
                      : AppTheme.textDisabledLight),
              size: 20,
            ),
      label: Text(
        _isScanning ? 'Scanner wird geöffnet...' : 'QR-Code scannen',
        style: theme.textTheme.bodyMedium?.copyWith(
          fontWeight: FontWeight.w500,
          color: widget.isEnabled
              ? (isDark ? AppTheme.primaryDark : AppTheme.primaryLight)
              : (isDark
                  ? AppTheme.textDisabledDark
                  : AppTheme.textDisabledLight),
        ),
      ),
      style: OutlinedButton.styleFrom(
        padding: EdgeInsets.symmetric(horizontal: 6.w, vertical: 2.h),
        side: BorderSide(
          color: widget.isEnabled
              ? (isDark ? AppTheme.primaryDark : AppTheme.primaryLight)
              : (isDark ? AppTheme.dividerDark : AppTheme.dividerLight),
          width: 1.5,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
    );
  }
}

class _QrScannerScreen extends StatefulWidget {
  final Function(String) onCodeScanned;

  const _QrScannerScreen({required this.onCodeScanned});

  @override
  State<_QrScannerScreen> createState() => _QrScannerScreenState();
}

class _QrScannerScreenState extends State<_QrScannerScreen> {
  MobileScannerController? _controller;
  bool _hasScanned = false;

  @override
  void initState() {
    super.initState();
    _controller = MobileScannerController();
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  void _onDetect(BarcodeCapture capture) {
    if (_hasScanned) return;

    final List<Barcode> barcodes = capture.barcodes;
    for (final barcode in barcodes) {
      if (barcode.rawValue != null) {
        setState(() => _hasScanned = true);
        HapticFeedback.mediumImpact();
        widget.onCodeScanned(barcode.rawValue!);
        break;
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text(
          'QR-Code scannen',
          style: theme.textTheme.titleLarge?.copyWith(
            color: Colors.white,
            fontWeight: FontWeight.w600,
          ),
        ),
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        leading: IconButton(
          icon: const Icon(Icons.close, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Stack(
        children: [
          MobileScanner(
            controller: _controller,
            onDetect: _onDetect,
          ),
          // Overlay with scanning frame
          Container(
            decoration: BoxDecoration(
              color: Colors.black.withValues(alpha: 0.5),
            ),
            child: Center(
              child: Container(
                width: 60.w,
                height: 60.w,
                decoration: BoxDecoration(
                  border: Border.all(
                    color:
                        isDark ? AppTheme.primaryDark : AppTheme.primaryLight,
                    width: 3,
                  ),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(9),
                  child: Container(
                    color: Colors.transparent,
                  ),
                ),
              ),
            ),
          ),
          // Instructions
          Positioned(
            bottom: 15.h,
            left: 0,
            right: 0,
            child: Container(
              margin: EdgeInsets.symmetric(horizontal: 8.w),
              padding: EdgeInsets.all(4.w),
              decoration: BoxDecoration(
                color: Colors.black.withValues(alpha: 0.7),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                'Richten Sie die Kamera auf den QR-Code Ihres Lizenzschlüssels',
                textAlign: TextAlign.center,
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: Colors.white,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}