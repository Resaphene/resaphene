import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../theme/app_theme.dart';

class FeatureComparisonWidget extends StatelessWidget {
  const FeatureComparisonWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    final features = [
      {
        'name': 'Therapiesitzungen',
        'free': '5 pro Tag',
        'premium': 'Unbegrenzt',
        'icon': Icons.headphones,
      },
      {
        'name': 'Fortschrittsanalyse',
        'free': 'Basis',
        'premium': 'Detailliert',
        'icon': Icons.analytics,
      },
      {
        'name': 'Audio-Personalisierung',
        'free': 'Standard',
        'premium': 'Individuell',
        'icon': Icons.tune,
      },
      {
        'name': 'Audiologie-Reports',
        'free': '✗',
        'premium': '✓',
        'icon': Icons.description,
      },
      {
        'name': 'Priority-Support',
        'free': '✗',
        'premium': '✓',
        'icon': Icons.support_agent,
      },
      {
        'name': 'Offline-Funktionen',
        'free': 'Begrenzt',
        'premium': 'Vollständig',
        'icon': Icons.offline_pin,
      },
    ];

    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: isDark
            ? AppTheme.backgroundDark.withValues(alpha: 0.5)
            : AppTheme.backgroundLight,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isDark
              ? AppTheme.textSecondaryDark.withValues(alpha: 0.3)
              : AppTheme.textSecondaryLight.withValues(alpha: 0.3),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            'Was ist in Premium enthalten?',
            style: theme.textTheme.titleLarge?.copyWith(
              color:
                  isDark ? AppTheme.textPrimaryDark : AppTheme.textPrimaryLight,
              fontWeight: FontWeight.w600,
            ),
            textAlign: TextAlign.center,
          ),

          SizedBox(height: 3.h),

          // Table header
          Container(
            padding: EdgeInsets.symmetric(vertical: 2.h),
            decoration: BoxDecoration(
              color: isDark
                  ? AppTheme.textSecondaryDark.withValues(alpha: 0.1)
                  : AppTheme.textSecondaryLight.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              children: [
                Expanded(
                  flex: 2,
                  child: Text(
                    'Funktion',
                    style: theme.textTheme.titleSmall?.copyWith(
                      color: isDark
                          ? AppTheme.textPrimaryDark
                          : AppTheme.textPrimaryLight,
                      fontWeight: FontWeight.w600,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
                Expanded(
                  child: Text(
                    'Kostenlos',
                    style: theme.textTheme.titleSmall?.copyWith(
                      color: isDark
                          ? AppTheme.textPrimaryDark
                          : AppTheme.textPrimaryLight,
                      fontWeight: FontWeight.w600,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
                Expanded(
                  child: Text(
                    'Premium',
                    style: theme.textTheme.titleSmall?.copyWith(
                      color:
                          isDark ? AppTheme.primaryDark : AppTheme.primaryLight,
                      fontWeight: FontWeight.w600,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
          ),

          SizedBox(height: 1.h),

          // Feature rows
          ...features.asMap().entries.map((entry) {
            final index = entry.key;
            final feature = entry.value;
            final isLastItem = index == features.length - 1;

            return Column(
              children: [
                Container(
                  padding: EdgeInsets.symmetric(vertical: 2.h),
                  child: Row(
                    children: [
                      // Feature name with icon
                      Expanded(
                        flex: 2,
                        child: Row(
                          children: [
                            Icon(
                              feature['icon'] as IconData,
                              color: isDark
                                  ? AppTheme.textSecondaryDark
                                  : AppTheme.textSecondaryLight,
                              size: 4.w,
                            ),
                            SizedBox(width: 2.w),
                            Expanded(
                              child: Text(
                                feature['name'] as String,
                                style: theme.textTheme.bodyMedium?.copyWith(
                                  color: isDark
                                      ? AppTheme.textPrimaryDark
                                      : AppTheme.textPrimaryLight,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),

                      // Free tier
                      Expanded(
                        child: _buildFeatureCell(
                          feature['free'] as String,
                          false,
                          isDark,
                          theme,
                        ),
                      ),

                      // Premium tier
                      Expanded(
                        child: _buildFeatureCell(
                          feature['premium'] as String,
                          true,
                          isDark,
                          theme,
                        ),
                      ),
                    ],
                  ),
                ),
                if (!isLastItem)
                  Divider(
                    color: isDark
                        ? AppTheme.textSecondaryDark.withValues(alpha: 0.2)
                        : AppTheme.textSecondaryLight.withValues(alpha: 0.2),
                    height: 0,
                  ),
              ],
            );
          }),

          SizedBox(height: 3.h),

          // Premium highlight
          Container(
            padding: EdgeInsets.all(3.w),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: isDark
                    ? [
                        AppTheme.primaryDark.withValues(alpha: 0.2),
                        AppTheme.primaryDark.withValues(alpha: 0.1),
                      ]
                    : [
                        AppTheme.primaryLight.withValues(alpha: 0.15),
                        AppTheme.primaryLight.withValues(alpha: 0.05),
                      ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                Icon(
                  Icons.star,
                  color: isDark ? AppTheme.primaryDark : AppTheme.primaryLight,
                  size: 6.w,
                ),
                SizedBox(width: 3.w),
                Expanded(
                  child: Text(
                    'Mit Premium erhalten Sie die bestmögliche Tinnitus-Therapie ohne Einschränkungen',
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: isDark
                          ? AppTheme.textPrimaryDark
                          : AppTheme.textPrimaryLight,
                      fontWeight: FontWeight.w500,
                      height: 1.4,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFeatureCell(
    String text,
    bool isPremium,
    bool isDark,
    ThemeData theme,
  ) {
    Color textColor;
    FontWeight fontWeight = FontWeight.w500;

    if (text == '✓') {
      textColor = Colors.green;
      fontWeight = FontWeight.w600;
    } else if (text == '✗') {
      textColor = Colors.red;
      fontWeight = FontWeight.w600;
    } else if (isPremium) {
      textColor = isDark ? AppTheme.primaryDark : AppTheme.primaryLight;
      fontWeight = FontWeight.w600;
    } else {
      textColor =
          isDark ? AppTheme.textSecondaryDark : AppTheme.textSecondaryLight;
    }

    return Text(
      text,
      style: theme.textTheme.bodyMedium?.copyWith(
        color: textColor,
        fontWeight: fontWeight,
      ),
      textAlign: TextAlign.center,
    );
  }
}
