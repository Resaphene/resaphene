import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../theme/app_theme.dart';

class SubscriptionPlansWidget extends StatelessWidget {
  final String? selectedPlan;
  final Function(String) onPlanSelected;

  const SubscriptionPlansWidget({
    super.key,
    required this.selectedPlan,
    required this.onPlanSelected,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          'Premium-Pläne',
          style: theme.textTheme.titleLarge?.copyWith(
            color:
                isDark ? AppTheme.textPrimaryDark : AppTheme.textPrimaryLight,
            fontWeight: FontWeight.w600,
          ),
        ),

        SizedBox(height: 2.h),

        // Monthly plan
        _buildPlanCard(
          planId: 'monthly',
          title: 'Monatlich',
          price: '9,99€',
          period: 'pro Monat',
          savings: null,
          isPopular: false,
          features: [
            'Vollzugang zu allen Therapiefunktionen',
            'Unbegrenzte Sitzungen',
            'Detaillierte Fortschrittsverfolgung',
            'Jederzeit kündbar',
          ],
          isDark: isDark,
          theme: theme,
        ),

        SizedBox(height: 2.h),

        // Annual plan
        _buildPlanCard(
          planId: 'annual',
          title: 'Jährlich',
          price: '79,99€',
          period: 'pro Jahr',
          savings: 'Sparen Sie 39,89€',
          isPopular: true,
          features: [
            'Vollzugang zu allen Therapiefunktionen',
            'Unbegrenzte Sitzungen',
            'Detaillierte Fortschrittsverfolgung',
            'Premium-Support',
            'Audiologie-Reports',
          ],
          isDark: isDark,
          theme: theme,
        ),
      ],
    );
  }

  Widget _buildPlanCard({
    required String planId,
    required String title,
    required String price,
    required String period,
    String? savings,
    required bool isPopular,
    required List<String> features,
    required bool isDark,
    required ThemeData theme,
  }) {
    final isSelected = selectedPlan == planId;

    return GestureDetector(
      onTap: () => onPlanSelected(planId),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
          gradient: isSelected
              ? LinearGradient(
                  colors: isDark
                      ? [
                          AppTheme.primaryDark.withValues(alpha: 0.2),
                          AppTheme.primaryDark.withValues(alpha: 0.1),
                        ]
                      : [
                          AppTheme.primaryLight.withValues(alpha: 0.15),
                          AppTheme.primaryLight.withValues(alpha: 0.05),
                        ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                )
              : null,
          color: !isSelected
              ? (isDark
                  ? AppTheme.backgroundDark.withValues(alpha: 0.5)
                  : AppTheme.backgroundLight)
              : null,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected
                ? (isDark ? AppTheme.primaryDark : AppTheme.primaryLight)
                : (isDark
                    ? AppTheme.textSecondaryDark.withValues(alpha: 0.3)
                    : AppTheme.textSecondaryLight.withValues(alpha: 0.3)),
            width: isSelected ? 2 : 1,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header with popular badge
            Row(
              children: [
                Expanded(
                  child: Text(
                    title,
                    style: theme.textTheme.titleLarge?.copyWith(
                      color: isDark
                          ? AppTheme.textPrimaryDark
                          : AppTheme.textPrimaryLight,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                if (isPopular)
                  Container(
                    padding: EdgeInsets.symmetric(
                      horizontal: 3.w,
                      vertical: 1.h,
                    ),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Colors.orange,
                          Colors.deepOrange,
                        ],
                      ),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      'Beliebt',
                      style: theme.textTheme.labelMedium?.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
              ],
            ),

            SizedBox(height: 2.h),

            // Price section
            Row(
              crossAxisAlignment: CrossAxisAlignment.baseline,
              textBaseline: TextBaseline.alphabetic,
              children: [
                Text(
                  price,
                  style: theme.textTheme.headlineMedium?.copyWith(
                    color:
                        isDark ? AppTheme.primaryDark : AppTheme.primaryLight,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                SizedBox(width: 2.w),
                Text(
                  period,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: isDark
                        ? AppTheme.textSecondaryDark
                        : AppTheme.textSecondaryLight,
                  ),
                ),
              ],
            ),

            // Savings indicator
            if (savings != null) ...[
              SizedBox(height: 1.h),
              Container(
                padding: EdgeInsets.symmetric(
                  horizontal: 2.w,
                  vertical: 0.5.h,
                ),
                decoration: BoxDecoration(
                  color: Colors.green.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  savings,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: Colors.green,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],

            SizedBox(height: 3.h),

            // Features list
            ...features.map((feature) => Padding(
                  padding: EdgeInsets.only(bottom: 1.5.h),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(
                        Icons.check_circle,
                        color: Colors.green,
                        size: 4.w,
                      ),
                      SizedBox(width: 3.w),
                      Expanded(
                        child: Text(
                          feature,
                          style: theme.textTheme.bodyMedium?.copyWith(
                            color: isDark
                                ? AppTheme.textPrimaryDark
                                : AppTheme.textPrimaryLight,
                            height: 1.3,
                          ),
                        ),
                      ),
                    ],
                  ),
                )),

            // Additional benefits for annual
            if (planId == 'annual') ...[
              SizedBox(height: 1.h),
              Container(
                padding: EdgeInsets.all(3.w),
                decoration: BoxDecoration(
                  color: isDark
                      ? Colors.green.withValues(alpha: 0.1)
                      : Colors.green.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    Icon(
                      Icons.savings,
                      color: Colors.green,
                      size: 5.w,
                    ),
                    SizedBox(width: 3.w),
                    Expanded(
                      child: Text(
                        'Entspricht nur 6,67€ pro Monat',
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: Colors.green.shade700,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],

            // Selection indicator
            SizedBox(height: 2.h),
            AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: double.infinity,
              padding: EdgeInsets.symmetric(vertical: 2.h),
              decoration: BoxDecoration(
                color: isSelected
                    ? (isDark ? AppTheme.primaryDark : AppTheme.primaryLight)
                    : Colors.transparent,
                borderRadius: BorderRadius.circular(8),
                border: !isSelected
                    ? Border.all(
                        color: isDark
                            ? AppTheme.textSecondaryDark.withValues(alpha: 0.3)
                            : AppTheme.textSecondaryLight
                                .withValues(alpha: 0.3),
                      )
                    : null,
              ),
              child: Text(
                isSelected ? 'Ausgewählt' : 'Auswählen',
                style: theme.textTheme.titleSmall?.copyWith(
                  color: isSelected
                      ? Colors.white
                      : (isDark
                          ? AppTheme.textSecondaryDark
                          : AppTheme.textSecondaryLight),
                  fontWeight: FontWeight.w600,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
