import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../theme/app_theme.dart';

class TrialStatusCardWidget extends StatelessWidget {
  final Map<String, dynamic> trialStatus;

  const TrialStatusCardWidget({
    super.key,
    required this.trialStatus,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    final status = trialStatus['status'] as String? ?? 'unknown';
    final remainingDays =
        (trialStatus['trial_remaining_days'] as num?)?.toInt() ?? 0;
    final hasSubscription = trialStatus['has_subscription'] as bool? ?? false;

    // Determine card colors and content based on status
    Color cardColor;
    Color accentColor;
    String statusText;
    String message;
    IconData statusIcon;

    if (status == 'trial' && remainingDays > 0) {
      cardColor = Colors.blue;
      accentColor = Colors.blue.shade100;
      statusText = 'Testphase läuft';
      message =
          'Noch $remainingDays ${remainingDays == 1 ? 'Tag' : 'Tage'} kostenlos';
      statusIcon = Icons.access_time;
    } else if (status == 'expired' ||
        (status == 'trial' && remainingDays <= 0)) {
      cardColor = Colors.orange;
      accentColor = Colors.orange.shade100;
      statusText = 'Testphase abgelaufen';
      message = 'Aktivieren Sie Premium für weiterhin vollständigen Zugang';
      statusIcon = Icons.warning;
    } else if (status == 'active') {
      cardColor = Colors.green;
      accentColor = Colors.green.shade100;
      statusText = 'Premium aktiv';
      message = 'Sie haben vollständigen Zugang zu allen Funktionen';
      statusIcon = Icons.check_circle;
    } else {
      cardColor = Colors.grey;
      accentColor = Colors.grey.shade100;
      statusText = 'Status unbekannt';
      message = 'Bitte wenden Sie sich an den Support';
      statusIcon = Icons.help;
    }

    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            cardColor.withValues(alpha: 0.1),
            cardColor.withValues(alpha: 0.05),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: cardColor.withValues(alpha: 0.3),
          width: 1,
        ),
      ),
      child: Column(
        children: [
          // Status header
          Row(
            children: [
              Container(
                padding: EdgeInsets.all(2.w),
                decoration: BoxDecoration(
                  color: cardColor.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(
                  statusIcon,
                  color: cardColor,
                  size: 5.w,
                ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      statusText,
                      style: theme.textTheme.titleMedium?.copyWith(
                        color: isDark
                            ? AppTheme.textPrimaryDark
                            : AppTheme.textPrimaryLight,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(height: 0.5.h),
                    Text(
                      message,
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: isDark
                            ? AppTheme.textSecondaryDark
                            : AppTheme.textSecondaryLight,
                        height: 1.3,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),

          // Progress bar for trial
          if (status == 'trial') ...[
            SizedBox(height: 2.h),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Fortschritt der Testphase',
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: isDark
                            ? AppTheme.textSecondaryDark
                            : AppTheme.textSecondaryLight,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Text(
                      '${28 - remainingDays}/28 Tage',
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: cardColor,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 1.h),
                LinearProgressIndicator(
                  value: (28 - remainingDays) / 28,
                  backgroundColor: isDark
                      ? cardColor.withValues(alpha: 0.2)
                      : cardColor.withValues(alpha: 0.3),
                  valueColor: AlwaysStoppedAnimation<Color>(cardColor),
                  minHeight: 1.5.w,
                ),
              ],
            ),
          ],

          // Usage statistics (mock data)
          if (status == 'trial' || status == 'active') ...[
            SizedBox(height: 3.h),
            Container(
              padding: EdgeInsets.all(3.w),
              decoration: BoxDecoration(
                color: isDark
                    ? Colors.white.withValues(alpha: 0.05)
                    : Colors.white.withValues(alpha: 0.5),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                children: [
                  Text(
                    'Ihre Fortschritte',
                    style: theme.textTheme.titleSmall?.copyWith(
                      color: isDark
                          ? AppTheme.textPrimaryDark
                          : AppTheme.textPrimaryLight,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  SizedBox(height: 2.h),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _buildStatItem(
                        '47',
                        'Sitzungen',
                        Icons.headphones,
                        isDark,
                        theme,
                      ),
                      _buildStatItem(
                        '12',
                        'Tage aktiv',
                        Icons.calendar_today,
                        isDark,
                        theme,
                      ),
                      _buildStatItem(
                        '73%',
                        'Besserung',
                        Icons.trending_up,
                        isDark,
                        theme,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildStatItem(
    String value,
    String label,
    IconData icon,
    bool isDark,
    ThemeData theme,
  ) {
    return Column(
      children: [
        Icon(
          icon,
          color:
              isDark ? AppTheme.textSecondaryDark : AppTheme.textSecondaryLight,
          size: 5.w,
        ),
        SizedBox(height: 1.h),
        Text(
          value,
          style: theme.textTheme.titleMedium?.copyWith(
            color:
                isDark ? AppTheme.textPrimaryDark : AppTheme.textPrimaryLight,
            fontWeight: FontWeight.w700,
          ),
        ),
        Text(
          label,
          style: theme.textTheme.bodySmall?.copyWith(
            color: isDark
                ? AppTheme.textSecondaryDark
                : AppTheme.textSecondaryLight,
          ),
        ),
      ],
    );
  }
}
