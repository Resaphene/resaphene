import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../services/subscription_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/custom_app_bar.dart';
import './widgets/payment_section_widget.dart';
import './widgets/subscription_benefits_list.dart';
import './widgets/subscription_plan_card.dart';

/// Premium Subscription Screen for TinniWell
/// Handles upgrade from trial to premium subscription
class PremiumSubscriptionScreen extends StatefulWidget {
  const PremiumSubscriptionScreen({super.key});

  @override
  State<PremiumSubscriptionScreen> createState() =>
      _PremiumSubscriptionScreenState();
}

class _PremiumSubscriptionScreenState extends State<PremiumSubscriptionScreen> {
  final SubscriptionService _subscriptionService = SubscriptionService.instance;

  bool _isLoading = false;
  Map<String, dynamic>? _subscriptionStatus;
  String _selectedPlan = 'monthly';

  @override
  void initState() {
    super.initState();
    _loadSubscriptionStatus();
  }

  Future<void> _loadSubscriptionStatus() async {
    try {
      final status = await _subscriptionService.getSubscriptionStatus();
      if (mounted) {
        setState(() {
          _subscriptionStatus = status;
        });
      }
    } catch (error) {
      // Handle silently
    }
  }

  Future<void> _handleSubscriptionUpgrade() async {
    setState(() {
      _isLoading = true;
    });

    try {
      // Simulate payment processing
      await Future.delayed(const Duration(seconds: 2));

      // In a real app, integrate with payment provider (Stripe, etc.)
      // For now, we'll simulate successful payment
      await _subscriptionService.upgradeToPremium();

      if (mounted) {
        HapticFeedback.mediumImpact();

        // Show success message
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  '🎉 Willkommen im Premium-Abo!',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 4),
                const Text('Ihre Zahlung wurde erfolgreich verarbeitet.'),
                const Text(
                    'Sie haben jetzt unbegrenzten Zugang zu allen Funktionen.'),
              ],
            ),
            backgroundColor: AppTheme.successLight,
            duration: const Duration(seconds: 4),
          ),
        );

        // Navigate back to therapy dashboard
        Navigator.pushNamedAndRemoveUntil(
          context,
          '/therapy-dashboard',
          (route) => false,
        );
      }
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Fehler beim Upgrade: ${error.toString()}'),
            backgroundColor: AppTheme.errorLight,
            duration: const Duration(seconds: 3),
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  String _getTrialStatusText() {
    if (_subscriptionStatus == null) return '';

    final status = _subscriptionStatus!['status'] as String? ?? '';
    final remainingDays =
        _subscriptionStatus!['trial_remaining_days'] as int? ?? 0;

    switch (status) {
      case 'trial':
        if (remainingDays > 0) {
          return 'Ihr kostenloser Test läuft noch $remainingDays Tage';
        } else {
          return 'Ihr kostenloser Test ist abgelaufen';
        }
      case 'trial_expired':
        return 'Ihr kostenloser Test ist abgelaufen';
      default:
        return 'Upgrade zu Premium für unbegrenzten Zugang';
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Scaffold(
      backgroundColor:
          isDark ? AppTheme.backgroundDark : AppTheme.backgroundLight,
      appBar: CustomAppBar(
        title: 'Premium Upgrade',
        showBackButton: true,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: 6.w, vertical: 2.h),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Premium Icon
              Container(
                padding: EdgeInsets.all(4.w),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      isDark ? AppTheme.primaryDark : AppTheme.primaryLight,
                      isDark
                          ? AppTheme.primaryDark.withValues(alpha: 0.7)
                          : AppTheme.primaryLight.withValues(alpha: 0.8),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  Icons.workspace_premium,
                  size: 15.w,
                  color: Colors.white,
                ),
              ),

              SizedBox(height: 3.h),

              // Title
              Text(
                'TinniWell Premium',
                style: theme.textTheme.headlineMedium?.copyWith(
                  color: isDark
                      ? AppTheme.textPrimaryDark
                      : AppTheme.textPrimaryLight,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),

              SizedBox(height: 1.h),

              // Subtitle with trial status
              if (_subscriptionStatus != null) ...[
                Text(
                  _getTrialStatusText(),
                  style: theme.textTheme.titleMedium?.copyWith(
                    color: isDark
                        ? AppTheme.textSecondaryDark
                        : AppTheme.textSecondaryLight,
                  ),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 3.h),
              ],

              // Benefits List
              const SubscriptionBenefitsList(),

              SizedBox(height: 4.h),

              // Plan Selection Cards
              Text(
                'Wählen Sie Ihren Plan',
                style: theme.textTheme.titleLarge?.copyWith(
                  color: isDark
                      ? AppTheme.textPrimaryDark
                      : AppTheme.textPrimaryLight,
                  fontWeight: FontWeight.w600,
                ),
              ),

              SizedBox(height: 2.h),

              // Monthly Plan
              SubscriptionPlanCard(
                title: 'Monatlich',
                price: '9,99€',
                period: 'pro Monat',
                features: const [
                  'Alle Premium-Funktionen',
                  'Jederzeit kündbar',
                  'Sofortiger Zugang',
                ],
                isSelected: _selectedPlan == 'monthly',
                isPopular: false,
                onTap: () {
                  setState(() {
                    _selectedPlan = 'monthly';
                  });
                },
              ),

              SizedBox(height: 2.h),

              // Annual Plan
              SubscriptionPlanCard(
                title: 'Jährlich',
                price: '99,99€',
                period: 'pro Jahr',
                originalPrice: '119,88€',
                features: const [
                  'Alle Premium-Funktionen',
                  '2 Monate kostenlos',
                  'Bester Preis',
                  'Priority Support',
                ],
                isSelected: _selectedPlan == 'annual',
                isPopular: true,
                onTap: () {
                  setState(() {
                    _selectedPlan = 'annual';
                  });
                },
              ),

              SizedBox(height: 4.h),

              // Payment Section
              PaymentSectionWidget(
                selectedPlan: _selectedPlan,
                isLoading: _isLoading,
                onUpgrade: _handleSubscriptionUpgrade,
              ),

              SizedBox(height: 3.h),

              // Terms and Guarantee
              Container(
                padding: EdgeInsets.all(3.w),
                decoration: BoxDecoration(
                  color: isDark
                      ? AppTheme.surfaceDark.withValues(alpha: 0.5)
                      : AppTheme.surfaceLight.withValues(alpha: 0.5),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: isDark ? AppTheme.dividerDark : AppTheme.dividerLight,
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(
                          Icons.shield_outlined,
                          color: isDark
                              ? AppTheme.primaryDark
                              : AppTheme.primaryLight,
                          size: 18,
                        ),
                        SizedBox(width: 2.w),
                        Text(
                          '30-Tage Geld-zurück-Garantie',
                          style: theme.textTheme.titleSmall?.copyWith(
                            color: isDark
                                ? AppTheme.primaryDark
                                : AppTheme.primaryLight,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 1.h),
                    Text(
                      '• Sicher verschlüsselte Zahlung\n• Jederzeit kündbar\n• Keine versteckten Kosten\n• Vollständige Rückerstattung bei Unzufriedenheit',
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: isDark
                            ? AppTheme.textSecondaryDark
                            : AppTheme.textSecondaryLight,
                        height: 1.4,
                      ),
                    ),
                  ],
                ),
              ),

              SizedBox(height: 2.h),
            ],
          ),
        ),
      ),
    );
  }
}