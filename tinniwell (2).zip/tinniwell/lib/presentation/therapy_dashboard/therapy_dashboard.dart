import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../services/audio_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/custom_app_bar.dart';
import '../../widgets/custom_bottom_bar.dart';
import '../trial_status_widget/trial_status_widget.dart';
import './widgets/frequency_control_card.dart';
import './widgets/quick_settings_panel.dart';
import './widgets/session_timer_card.dart';
import './widgets/simple_music_player_widget.dart';
import './widgets/therapy_mode_selector.dart';

/// Therapy Dashboard for TinniWell tinnitus therapy application
/// Provides access to all therapy modes and patient management tools
class TherapyDashboard extends StatefulWidget {
  const TherapyDashboard({super.key});

  @override
  State<TherapyDashboard> createState() => _TherapyDashboardState();
}

class _TherapyDashboardState extends State<TherapyDashboard>
    with TickerProviderStateMixin {
  // Therapy state
  String _selectedTherapyMode = 'ausblendung';
  double _leftFrequency = 4000.0;
  double _rightFrequency = 4200.0;
  bool _leftNotchFilter = false;
  bool _rightNotchFilter = true;
  bool _isTherapyActive = false;

  // Session data
  Duration _lastSessionDuration = Duration(minutes: 25);
  double _weeklyProgress = 68.0;
  int _totalSessions = 12;

  // Quick settings
  bool _quickSettingsExpanded = false;
  double _masterVolume = 0.7;
  double _leftVolume = 0.8;
  double _rightVolume = 0.75;
  bool _headphonesDetected = true;
  String _audioRoute = 'headphones';

  // Mock therapy data
  final List<Map<String, dynamic>> _therapyHistory = [
    {
      'date': DateTime.now().subtract(Duration(days: 1)),
      'duration': Duration(minutes: 30),
      'mode': 'ausblendung',
      'leftFreq': 4000.0,
      'rightFreq': 4200.0,
      'quality': 0.85,
    },
    {
      'date': DateTime.now().subtract(Duration(days: 2)),
      'duration': Duration(minutes: 20),
      'mode': 'ueberlagerung',
      'leftFreq': 3800.0,
      'rightFreq': 4100.0,
      'quality': 0.78,
    },
    {
      'date': DateTime.now().subtract(Duration(days: 3)),
      'duration': Duration(minutes: 35),
      'mode': 'gegentakt',
      'leftFreq': 4200.0,
      'rightFreq': 4000.0,
      'quality': 0.92,
    },
  ];

  @override
  void initState() {
    super.initState();
    // Clamp frequencies to new range (20Hz - 15000Hz)
    _leftFrequency = _leftFrequency.clamp(20.0, 15000.0);
    _rightFrequency = _rightFrequency.clamp(20.0, 15000.0);

    // Initialize audio service
    _initializeAudioService();
  }

  /// Initialize audio service for therapy sessions
  Future<void> _initializeAudioService() async {
    try {
      await AudioService.instance.initialize();
    } catch (error) {
      print('Failed to initialize audio service: $error');
    }
  }

  @override
  void dispose() {
    // Dispose audio service when leaving screen
    AudioService.instance.dispose();
    super.dispose();
  }

  Future<void> _refreshData() async {
    // Simulate data refresh
    await Future.delayed(Duration(seconds: 1));

    setState(() {
      _weeklyProgress = (_weeklyProgress + 5).clamp(0, 100);
      _totalSessions += 1;
    });

    HapticFeedback.lightImpact();
  }

  /// Handle therapy state changes from music player
  void _onTherapyStateChanged() {
    setState(() {
      _isTherapyActive = AudioService.instance.isPlaying;
    });
  }

  void _toggleSettings() {
    setState(() {
      _quickSettingsExpanded = !_quickSettingsExpanded;
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Scaffold(
      backgroundColor:
          isDark ? AppTheme.backgroundDark : AppTheme.backgroundLight,
      appBar: CustomAppBar(
        title: 'tinniwell Therapie',
        showBackButton: false,
        actions: [
          IconButton(
            onPressed: _toggleSettings,
            icon: Icon(
              Icons.settings,
              color:
                  isDark ? AppTheme.textPrimaryDark : AppTheme.textPrimaryLight,
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          child: Column(
            children: [
              // Trial Status Widget - persistent banner
              const TrialStatusWidget(
                displayMode: TrialStatusDisplayMode.banner,
                isDismissible: true,
              ),

              // Replace MusicPlayerWidget with SimpleMusicPlayerWidget
              SimpleMusicPlayerWidget(
                onTherapyStateChanged: () {
                  // Update therapy state if needed
                  setState(() {
                    // Any state updates for therapy session
                  });
                },
              ),

              // Therapy mode selector
              TherapyModeSelector(
                selectedMode: _selectedTherapyMode,
                onModeChanged: (mode) {
                  setState(() => _selectedTherapyMode = mode);
                  HapticFeedback.lightImpact();
                },
              ),

              SizedBox(height: 3.h),

              // Enhanced frequency control card
              FrequencyControlCard(
                leftFrequency: _leftFrequency,
                rightFrequency: _rightFrequency,
                leftNotchFilter: _leftNotchFilter,
                rightNotchFilter: _rightNotchFilter,
                onLeftFrequencyChanged: (freq) {
                  setState(() => _leftFrequency = freq.clamp(20.0, 15000.0));
                },
                onRightFrequencyChanged: (freq) {
                  setState(() => _rightFrequency = freq.clamp(20.0, 15000.0));
                },
                onLeftNotchFilterToggled: (enabled) {
                  setState(() => _leftNotchFilter = enabled);
                },
                onRightNotchFilterToggled: (enabled) {
                  setState(() => _rightNotchFilter = enabled);
                },
              ),

              SizedBox(height: 3.h),

              // Session timer card (contains Therapie Verlauf section)
              SessionTimerCard(
                lastSessionDuration: _lastSessionDuration,
                weeklyProgress: _weeklyProgress,
                totalSessions: _totalSessions,
              ),

              SizedBox(height: 3.h),

              // Quick settings panel
              QuickSettingsPanel(
                isExpanded: _quickSettingsExpanded,
                masterVolume: _masterVolume,
                leftVolume: _leftVolume,
                rightVolume: _rightVolume,
                headphonesDetected: _headphonesDetected,
                audioRoute: _audioRoute,
                onMasterVolumeChanged: (volume) {
                  setState(() => _masterVolume = volume);
                  // Update audio service volume
                  AudioService.instance.setVolume(volume);
                },
                onLeftVolumeChanged: (volume) {
                  setState(() => _leftVolume = volume);
                },
                onRightVolumeChanged: (volume) {
                  setState(() => _rightVolume = volume);
                },
                onAudioRouteChanged: (route) {
                  setState(() => _audioRoute = route);
                },
                onToggleExpanded: () {
                  setState(
                    () => _quickSettingsExpanded = !_quickSettingsExpanded,
                  );
                },
              ),

              SizedBox(height: 3.h), // Bottom padding
            ],
          ),
        ),
      ),
      bottomNavigationBar: CustomBottomBar(
        currentIndex: CustomBottomBarExtension.getIndexForRoute(
          '/therapy-dashboard',
        ),
        onTap: (index) {
          // Navigation handled by CustomBottomBar
        },
      ),
    );
  }
}
