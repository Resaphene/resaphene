import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../theme/app_theme.dart';

/// Enhanced frequency control card with L/R ear selection and dual slider controls
class FrequencyControlCard extends StatefulWidget {
  final double leftFrequency;
  final double rightFrequency;
  final bool leftNotchFilter;
  final bool rightNotchFilter;
  final Function(double) onLeftFrequencyChanged;
  final Function(double) onRightFrequencyChanged;
  final Function(bool) onLeftNotchFilterToggled;
  final Function(bool) onRightNotchFilterToggled;

  const FrequencyControlCard({
    super.key,
    required this.leftFrequency,
    required this.rightFrequency,
    required this.leftNotchFilter,
    required this.rightNotchFilter,
    required this.onLeftFrequencyChanged,
    required this.onRightFrequencyChanged,
    required this.onLeftNotchFilterToggled,
    required this.onRightNotchFilterToggled,
  });

  @override
  State<FrequencyControlCard> createState() => _FrequencyControlCardState();
}

class _FrequencyControlCardState extends State<FrequencyControlCard> {
  String _selectedEar = 'L'; // 'L' for Left, 'R' for Right

  double get _currentFrequency =>
      _selectedEar == 'L' ? widget.leftFrequency : widget.rightFrequency;

  bool get _currentNotchFilter =>
      _selectedEar == 'L' ? widget.leftNotchFilter : widget.rightNotchFilter;

  void _updateFrequency(double frequency) {
    if (_selectedEar == 'L') {
      widget.onLeftFrequencyChanged(frequency);
    } else {
      widget.onRightFrequencyChanged(frequency);
    }
  }

  void _toggleNotchFilter(bool enabled) {
    if (_selectedEar == 'L') {
      widget.onLeftNotchFilterToggled(enabled);
    } else {
      widget.onRightNotchFilterToggled(enabled);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: AppTheme.lightTheme.colorScheme.primary.withValues(alpha: 0.3),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: AppTheme.lightTheme.colorScheme.shadow,
            offset: Offset(0, 2),
            blurRadius: 8,
            spreadRadius: 0,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header with ear selection and notch filter
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // L/R Ear selection buttons
              Row(
                children: [
                  Text(
                    'Ohr:',
                    style: AppTheme.lightTheme.textTheme.labelMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                      color: AppTheme.lightTheme.colorScheme.onSurface,
                    ),
                  ),
                  SizedBox(width: 2.w),
                  _buildEarSelectionButton('L'),
                  SizedBox(width: 1.w),
                  _buildEarSelectionButton('R'),
                ],
              ),
              // Notch filter toggle
              Row(
                children: [
                  Text(
                    'Notch',
                    style: AppTheme.lightTheme.textTheme.labelSmall?.copyWith(
                      color: AppTheme.lightTheme.colorScheme.onSurface
                          .withValues(alpha: 0.7),
                    ),
                  ),
                  SizedBox(width: 1.w),
                  Switch(
                    value: _currentNotchFilter,
                    onChanged: (value) {
                      HapticFeedback.lightImpact();
                      _toggleNotchFilter(value);
                    },
                    materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  ),
                ],
              ),
            ],
          ),
          SizedBox(height: 3.h),

          // Frequency display
          Center(
            child: Column(
              children: [
                Text(
                  '${_currentFrequency.toInt()}',
                  style: AppTheme.lightTheme.textTheme.headlineLarge?.copyWith(
                    fontWeight: FontWeight.w700,
                    color: _selectedEar == 'L'
                        ? AppTheme.lightTheme.colorScheme.primary
                        : AppTheme.lightTheme.colorScheme.secondary,
                    height: 1.0,
                  ),
                ),
                Text(
                  'Hz',
                  style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                    color: AppTheme.lightTheme.colorScheme.onSurface
                        .withValues(alpha: 0.7),
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 3.h),

          // Waveform visualization
          Container(
            width: double.infinity,
            height: 8.h,
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.surface
                  .withValues(alpha: 0.5),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: AppTheme.lightTheme.colorScheme.outline
                    .withValues(alpha: 0.3),
                width: 1,
              ),
            ),
            child: CustomPaint(
              painter: WaveformPainter(
                frequency: _currentFrequency,
                color: _selectedEar == 'L'
                    ? AppTheme.lightTheme.colorScheme.primary
                    : AppTheme.lightTheme.colorScheme.secondary,
                notchEnabled: _currentNotchFilter,
              ),
            ),
          ),
          SizedBox(height: 3.h),

          // Coarse adjustment slider (100 Hz steps)
          Text(
            'Grobeinstellung (100 Hz Schritte)',
            style: AppTheme.lightTheme.textTheme.labelMedium?.copyWith(
              fontWeight: FontWeight.w600,
              color: AppTheme.lightTheme.colorScheme.onSurface,
            ),
          ),
          SizedBox(height: 1.h),
          SliderTheme(
            data: SliderTheme.of(context).copyWith(
              trackHeight: 6,
              thumbShape: RoundSliderThumbShape(enabledThumbRadius: 12),
              activeTrackColor: _selectedEar == 'L'
                  ? AppTheme.lightTheme.colorScheme.primary
                  : AppTheme.lightTheme.colorScheme.secondary,
              thumbColor: _selectedEar == 'L'
                  ? AppTheme.lightTheme.colorScheme.primary
                  : AppTheme.lightTheme.colorScheme.secondary,
            ),
            child: Slider(
              value: _currentFrequency,
              min: 20.0,
              max: 15000.0,
              divisions: 149, // (15000-20)/100 = 149.8 ≈ 149
              onChanged: (value) {
                final roundedValue = (value / 100).round() * 100.0;
                _updateFrequency(roundedValue.clamp(20.0, 15000.0));
                HapticFeedback.lightImpact();
              },
            ),
          ),
          SizedBox(height: 2.h),

          // Fine adjustment slider (1 Hz steps)
          Text(
            'Feineinstellung (1 Hz Schritte)',
            style: AppTheme.lightTheme.textTheme.labelMedium?.copyWith(
              fontWeight: FontWeight.w600,
              color: AppTheme.lightTheme.colorScheme.onSurface,
            ),
          ),
          SizedBox(height: 1.h),
          SliderTheme(
            data: SliderTheme.of(context).copyWith(
              trackHeight: 4,
              thumbShape: RoundSliderThumbShape(enabledThumbRadius: 10),
              activeTrackColor: (_selectedEar == 'L'
                      ? AppTheme.lightTheme.colorScheme.primary
                      : AppTheme.lightTheme.colorScheme.secondary)
                  .withValues(alpha: 0.7),
              thumbColor: _selectedEar == 'L'
                  ? AppTheme.lightTheme.colorScheme.primary
                  : AppTheme.lightTheme.colorScheme.secondary,
            ),
            child: Slider(
              value: _currentFrequency,
              min: ((_currentFrequency / 100).floor() * 100.0)
                  .clamp(20.0, 14900.0),
              max: (((_currentFrequency / 100).floor() + 1) * 100.0)
                  .clamp(120.0, 15000.0),
              divisions: 100,
              onChanged: (value) {
                _updateFrequency(value.clamp(20.0, 15000.0));
                HapticFeedback.lightImpact();
              },
            ),
          ),
          SizedBox(height: 2.h),
        ],
      ),
    );
  }

  Widget _buildEarSelectionButton(String ear) {
    final isSelected = _selectedEar == ear;
    final isLeft = ear == 'L';

    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedEar = ear;
        });
        HapticFeedback.lightImpact();
      },
      child: Container(
        width: 12.w,
        height: 5.h,
        decoration: BoxDecoration(
          color: isSelected
              ? (isLeft
                  ? AppTheme.lightTheme.colorScheme.primary
                  : AppTheme.lightTheme.colorScheme.secondary)
              : AppTheme.lightTheme.colorScheme.surface,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: isLeft
                ? AppTheme.lightTheme.colorScheme.primary
                : AppTheme.lightTheme.colorScheme.secondary,
            width: isSelected ? 2 : 1,
          ),
        ),
        child: Center(
          child: Text(
            ear,
            style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w700,
              color: isSelected
                  ? AppTheme.lightTheme.colorScheme.onPrimary
                  : (isLeft
                      ? AppTheme.lightTheme.colorScheme.primary
                      : AppTheme.lightTheme.colorScheme.secondary),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildQuickAdjustButton(String label, VoidCallback onPressed) {
    return Container(
      width: 15.w,
      height: 5.h,
      decoration: BoxDecoration(
        color: (_selectedEar == 'L'
                ? AppTheme.lightTheme.colorScheme.primary
                : AppTheme.lightTheme.colorScheme.secondary)
            .withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: (_selectedEar == 'L'
                  ? AppTheme.lightTheme.colorScheme.primary
                  : AppTheme.lightTheme.colorScheme.secondary)
              .withValues(alpha: 0.3),
          width: 1,
        ),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () {
            onPressed();
            HapticFeedback.lightImpact();
          },
          borderRadius: BorderRadius.circular(8),
          child: Center(
            child: Text(
              label,
              style: AppTheme.lightTheme.textTheme.labelMedium?.copyWith(
                fontWeight: FontWeight.w600,
                color: _selectedEar == 'L'
                    ? AppTheme.lightTheme.colorScheme.primary
                    : AppTheme.lightTheme.colorScheme.secondary,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Custom painter for waveform visualization
class WaveformPainter extends CustomPainter {
  final double frequency;
  final Color color;
  final bool notchEnabled;

  WaveformPainter({
    required this.frequency,
    required this.color,
    required this.notchEnabled,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color.withValues(alpha: 0.7)
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;

    final path = Path();
    final centerY = size.height / 2;
    final amplitude = size.height * 0.3;
    final wavelength =
        size.width / (frequency / 1000); // Simplified visualization

    path.moveTo(0, centerY);

    for (double x = 0; x <= size.width; x += 1) {
      double y = centerY;
      if (!notchEnabled || (x < size.width * 0.4 || x > size.width * 0.6)) {
        y = centerY + amplitude * math.sin((x / wavelength) * 2 * math.pi);
      }
      path.lineTo(x, y);
    }

    canvas.drawPath(path, paint);

    // Draw notch indicator if enabled
    if (notchEnabled) {
      final notchPaint = Paint()
        ..color = color.withValues(alpha: 0.3)
        ..style = PaintingStyle.fill;

      canvas.drawRect(
        Rect.fromLTWH(size.width * 0.4, 0, size.width * 0.2, size.height),
        notchPaint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
