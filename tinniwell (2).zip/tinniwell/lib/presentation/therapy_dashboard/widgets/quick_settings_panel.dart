import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

/// Quick settings panel for volume controls and audio routing
class QuickSettingsPanel extends StatelessWidget {
  final bool isExpanded;
  final double masterVolume;
  final double leftVolume;
  final double rightVolume;
  final bool headphonesDetected;
  final String audioRoute;
  final Function(double) onMasterVolumeChanged;
  final Function(double) onLeftVolumeChanged;
  final Function(double) onRightVolumeChanged;
  final Function(String) onAudioRouteChanged;
  final VoidCallback onToggleExpanded;

  const QuickSettingsPanel({
    super.key,
    required this.isExpanded,
    required this.masterVolume,
    required this.leftVolume,
    required this.rightVolume,
    required this.headphonesDetected,
    required this.audioRoute,
    required this.onMasterVolumeChanged,
    required this.onLeftVolumeChanged,
    required this.onRightVolumeChanged,
    required this.onAudioRouteChanged,
    required this.onToggleExpanded,
  });

  static const List<Map<String, dynamic>> audioRoutes = [
    {
      'id': 'headphones',
      'title': 'Kopfhörer',
      'icon': 'headphones',
      'available': true,
    },
    {
      'id': 'speaker',
      'title': 'Lautsprecher',
      'icon': 'speaker',
      'available': true,
    },
    {
      'id': 'bluetooth',
      'title': 'Bluetooth',
      'icon': 'bluetooth_audio',
      'available': false,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: AppTheme.lightTheme.colorScheme.shadow,
            offset: Offset(0, 2),
            blurRadius: 8,
            spreadRadius: 0,
          ),
        ],
      ),
      child: Column(
        children: [
          // Header with toggle
          GestureDetector(
            onTap: () {
              HapticFeedback.lightImpact();
              onToggleExpanded();
            },
            child: Container(
              width: double.infinity,
              padding: EdgeInsets.all(4.w),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      CustomIconWidget(
                        iconName: 'tune',
                        color: AppTheme.lightTheme.colorScheme.primary,
                        size: 20,
                      ),
                      SizedBox(width: 2.w),
                      Text(
                        'Schnelleinstellungen',
                        style:
                            AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w600,
                          color: AppTheme.lightTheme.colorScheme.onSurface,
                        ),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      // Headphone detection indicator
                      Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 2.w, vertical: 0.5.h),
                        decoration: BoxDecoration(
                          color: headphonesDetected
                              ? AppTheme.lightTheme.colorScheme.tertiary
                                  .withValues(alpha: 0.1)
                              : AppTheme.lightTheme.colorScheme.outline
                                  .withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            CustomIconWidget(
                              iconName: headphonesDetected
                                  ? 'headphones'
                                  : 'headphones_off',
                              color: headphonesDetected
                                  ? AppTheme.lightTheme.colorScheme.tertiary
                                  : AppTheme.lightTheme.colorScheme.outline,
                              size: 12,
                            ),
                            SizedBox(width: 1.w),
                            Text(
                              headphonesDetected ? 'Verbunden' : 'Getrennt',
                              style: AppTheme.lightTheme.textTheme.labelSmall
                                  ?.copyWith(
                                color: headphonesDetected
                                    ? AppTheme.lightTheme.colorScheme.tertiary
                                    : AppTheme.lightTheme.colorScheme.outline,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(width: 2.w),
                      AnimatedRotation(
                        turns: isExpanded ? 0.5 : 0,
                        duration: Duration(milliseconds: 200),
                        child: CustomIconWidget(
                          iconName: 'keyboard_arrow_down',
                          color: AppTheme.lightTheme.colorScheme.onSurface
                              .withValues(alpha: 0.7),
                          size: 20,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),

          // Expandable content
          AnimatedContainer(
            duration: Duration(milliseconds: 300),
            curve: Curves.easeInOut,
            height: isExpanded ? null : 0,
            child: isExpanded ? _buildExpandedContent() : SizedBox.shrink(),
          ),
        ],
      ),
    );
  }

  Widget _buildExpandedContent() {
    return Container(
      padding: EdgeInsets.fromLTRB(4.w, 0, 4.w, 4.w),
      child: Column(
        children: [
          Divider(
            color:
                AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.2),
            height: 1,
          ),
          SizedBox(height: 3.h),

          // Volume controls
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Lautstärke',
                style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: AppTheme.lightTheme.colorScheme.onSurface,
                ),
              ),
              SizedBox(height: 2.h),

              // Master volume
              _buildVolumeSlider(
                'Master',
                masterVolume,
                onMasterVolumeChanged,
                'volume_up',
                AppTheme.lightTheme.colorScheme.primary,
              ),
              SizedBox(height: 2.h),

              // Left/Right volume
              Row(
                children: [
                  Expanded(
                    child: _buildVolumeSlider(
                      'Links',
                      leftVolume,
                      onLeftVolumeChanged,
                      'hearing',
                      AppTheme.lightTheme.colorScheme.primary,
                    ),
                  ),
                  SizedBox(width: 4.w),
                  Expanded(
                    child: _buildVolumeSlider(
                      'Rechts',
                      rightVolume,
                      onRightVolumeChanged,
                      'hearing_disabled',
                      AppTheme.lightTheme.colorScheme.secondary,
                    ),
                  ),
                ],
              ),
            ],
          ),

          SizedBox(height: 4.h),

          // Audio routing
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Audio-Ausgang',
                style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: AppTheme.lightTheme.colorScheme.onSurface,
                ),
              ),
              SizedBox(height: 2.h),
              Row(
                children: audioRoutes.map((route) {
                  final isSelected = audioRoute == route['id'];
                  final isAvailable = route['available'] as bool;

                  return Expanded(
                    child: GestureDetector(
                      onTap: isAvailable
                          ? () {
                              HapticFeedback.lightImpact();
                              onAudioRouteChanged(route['id'] as String);
                            }
                          : null,
                      child: Container(
                        margin: EdgeInsets.symmetric(horizontal: 1.w),
                        padding: EdgeInsets.symmetric(
                            vertical: 2.h, horizontal: 2.w),
                        decoration: BoxDecoration(
                          color: isSelected
                              ? AppTheme.lightTheme.colorScheme.primary
                                  .withValues(alpha: 0.1)
                              : AppTheme.lightTheme.colorScheme.surface
                                  .withValues(alpha: 0.5),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color: isSelected
                                ? AppTheme.lightTheme.colorScheme.primary
                                : AppTheme.lightTheme.colorScheme.outline
                                    .withValues(alpha: 0.3),
                            width: isSelected ? 2 : 1,
                          ),
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            CustomIconWidget(
                              iconName: route['icon'] as String,
                              color: isAvailable
                                  ? (isSelected
                                      ? AppTheme.lightTheme.colorScheme.primary
                                      : AppTheme
                                          .lightTheme.colorScheme.onSurface
                                          .withValues(alpha: 0.7))
                                  : AppTheme.lightTheme.colorScheme.onSurface
                                      .withValues(alpha: 0.3),
                              size: 20,
                            ),
                            SizedBox(height: 1.h),
                            Text(
                              route['title'] as String,
                              style: AppTheme.lightTheme.textTheme.labelSmall
                                  ?.copyWith(
                                color: isAvailable
                                    ? (isSelected
                                        ? AppTheme
                                            .lightTheme.colorScheme.primary
                                        : AppTheme
                                            .lightTheme.colorScheme.onSurface)
                                    : AppTheme.lightTheme.colorScheme.onSurface
                                        .withValues(alpha: 0.3),
                                fontWeight: isSelected
                                    ? FontWeight.w600
                                    : FontWeight.w400,
                              ),
                              textAlign: TextAlign.center,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildVolumeSlider(
    String label,
    double value,
    Function(double) onChanged,
    String iconName,
    Color color,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            CustomIconWidget(
              iconName: iconName,
              color: color,
              size: 16,
            ),
            SizedBox(width: 2.w),
            Text(
              label,
              style: AppTheme.lightTheme.textTheme.labelMedium?.copyWith(
                color: AppTheme.lightTheme.colorScheme.onSurface
                    .withValues(alpha: 0.7),
                fontWeight: FontWeight.w500,
              ),
            ),
            Spacer(),
            Text(
              '${(value * 100).toInt()}%',
              style: AppTheme.lightTheme.textTheme.labelMedium?.copyWith(
                color: color,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
        SizedBox(height: 1.h),
        SliderTheme(
          data: SliderThemeData(
            activeTrackColor: color,
            thumbColor: color,
            overlayColor: color.withValues(alpha: 0.1),
            inactiveTrackColor: color.withValues(alpha: 0.2),
            trackHeight: 3,
            thumbShape: RoundSliderThumbShape(enabledThumbRadius: 8),
            overlayShape: RoundSliderOverlayShape(overlayRadius: 16),
          ),
          child: Slider(
            value: value,
            onChanged: (newValue) {
              HapticFeedback.lightImpact();
              onChanged(newValue);
            },
            min: 0.0,
            max: 1.0,
            divisions: 100,
          ),
        ),
      ],
    );
  }
}