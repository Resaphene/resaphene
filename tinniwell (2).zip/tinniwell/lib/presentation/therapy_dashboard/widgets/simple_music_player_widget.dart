import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../theme/app_theme.dart';
import '../../../services/simple_audio_service.dart';

/// Simple Music Player Widget - Storage-Only System
/// Just upload songs to therapy-audio bucket and they appear automatically!
/// No database management, no admin controls needed
class SimpleMusicPlayerWidget extends StatefulWidget {
  final VoidCallback? onTherapyStateChanged;

  const SimpleMusicPlayerWidget({
    super.key,
    this.onTherapyStateChanged,
  });

  @override
  State<SimpleMusicPlayerWidget> createState() =>
      _SimpleMusicPlayerWidgetState();
}

class _SimpleMusicPlayerWidgetState extends State<SimpleMusicPlayerWidget>
    with TickerProviderStateMixin {
  late AnimationController _pulseAnimationController;

  String? _currentTrackTitle;
  Duration _currentPosition = Duration.zero;
  Duration? _currentDuration;
  bool _isPlaying = false;
  bool _isLoading = false;
  String? _errorMessage;
  int _currentTrackIndex = 0;
  int _totalTracks = 0;

  @override
  void initState() {
    super.initState();
    _setupAnimations();
    _setupAudioListeners();
  }

  void _setupAnimations() {
    _pulseAnimationController = AnimationController(
      duration: Duration(milliseconds: 1500),
      vsync: this,
    );
  }

  void _setupAudioListeners() {
    // Listen to track title changes
    SimpleAudioService.instance.trackTitleStream.listen((title) {
      if (mounted) {
        setState(() {
          _currentTrackTitle = title;
          _currentTrackIndex = SimpleAudioService.instance.currentTrackIndex;
          _totalTracks = SimpleAudioService.instance.totalTracks;
        });
      }
    });

    // Listen to position changes
    SimpleAudioService.instance.positionStream.listen((position) {
      if (mounted) {
        setState(() {
          _currentPosition = position;
        });
      }
    });

    // Listen to duration changes
    SimpleAudioService.instance.durationStream.listen((duration) {
      if (mounted) {
        setState(() {
          _currentDuration = duration;
        });
      }
    });

    // Listen to playing state changes
    SimpleAudioService.instance.playingStream.listen((playing) {
      if (mounted) {
        setState(() {
          _isPlaying = playing;
        });

        // Update animations based on playing state
        if (_isPlaying) {
          _pulseAnimationController.repeat();
        } else {
          _pulseAnimationController.stop();
        }
      }
    });
  }

  /// Start therapy session - loads songs from storage automatically
  Future<void> _startTherapySession() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final result = await SimpleAudioService.instance.startTherapySession();

      setState(() {
        _isLoading = false;
      });

      if (result['error'] != true) {
        final String title = result['title'] ?? 'Unbekannter Track';
        final int index = result['index'] ?? 1;
        final int total = result['total'] ?? 0;

        setState(() {
          _currentTrackTitle = title;
          _currentTrackIndex = index;
          _totalTracks = total;
        });

        widget.onTherapyStateChanged?.call();

        HapticFeedback.mediumImpact();
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Therapie-Sitzung gestartet: $title'),
              backgroundColor: AppTheme.lightTheme.colorScheme.tertiary,
              duration: Duration(seconds: 2),
            ),
          );
        }
      } else {
        setState(() {
          _errorMessage = result['message'];
        });

        if (mounted) {
          String errorMessage =
              result['message'] ?? 'Keine Audio-Dateien verfügbar';

          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Audio-Dateien nicht gefunden',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 4),
                  Text(errorMessage),
                  SizedBox(height: 8),
                  Text(
                    'Laden Sie MP3-Dateien in den "therapy-audio" Storage-Bucket hoch.',
                    style: TextStyle(fontSize: 12, fontStyle: FontStyle.italic),
                  ),
                ],
              ),
              backgroundColor: AppTheme.lightTheme.colorScheme.error,
              duration: Duration(seconds: 5),
              action: SnackBarAction(
                label: 'Erneut laden',
                textColor: Colors.white,
                onPressed: () {
                  Future.delayed(Duration(milliseconds: 500), () {
                    if (mounted) {
                      _startTherapySession();
                    }
                  });
                },
              ),
            ),
          );
        }
      }
    } catch (error) {
      setState(() {
        _isLoading = false;
        _errorMessage = 'Fehler beim Laden der Audio-Dateien';
      });

      print('Exception in _startTherapySession: $error');

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Storage-Fehler',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 4),
                Text('Fehler beim Zugriff auf den Audio-Storage.'),
                SizedBox(height: 8),
                Text(
                  'Stellen Sie sicher, dass der "therapy-audio" Bucket existiert und Audio-Dateien enthält.',
                  style: TextStyle(fontSize: 12, fontStyle: FontStyle.italic),
                ),
              ],
            ),
            backgroundColor: AppTheme.lightTheme.colorScheme.error,
            duration: Duration(seconds: 5),
          ),
        );
      }
    }
  }

  /// Toggle play/pause
  Future<void> _togglePlayPause() async {
    await SimpleAudioService.instance.togglePlayPause();
  }

  /// Stop playback
  Future<void> _stopPlayback() async {
    await SimpleAudioService.instance.stop();
    widget.onTherapyStateChanged?.call();

    setState(() {
      _currentTrackTitle = null;
      _currentTrackIndex = 0;
      _totalTracks = 0;
    });

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Therapie-Sitzung beendet'),
          backgroundColor: AppTheme.lightTheme.colorScheme.secondary,
          duration: Duration(seconds: 2),
        ),
      );
    }
  }

  /// Seek to position
  Future<void> _seekToPosition(double value) async {
    if (_currentDuration != null) {
      final position = Duration(
        milliseconds: (value * _currentDuration!.inMilliseconds).round(),
      );
      await SimpleAudioService.instance.seek(position);
    }
  }

  /// Format duration for display
  String _formatDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    String minutes = twoDigits(duration.inMinutes.remainder(60));
    String seconds = twoDigits(duration.inSeconds.remainder(60));
    return '$minutes:$seconds';
  }

  /// Get progress value (0.0 to 1.0)
  double get _progressValue {
    if (_currentDuration == null || _currentDuration!.inMilliseconds == 0) {
      return 0.0;
    }
    return _currentPosition.inMilliseconds / _currentDuration!.inMilliseconds;
  }

  /// Skip to next track
  Future<void> _skipToNext() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final result = await SimpleAudioService.instance.skipToNext();

      setState(() {
        _isLoading = false;
      });

      if (result['error'] != true) {
        final String title = result['title'] ?? 'Unbekannter Track';
        final int index = result['index'] ?? 1;

        setState(() {
          _currentTrackTitle = title;
          _currentTrackIndex = index;
        });

        HapticFeedback.mediumImpact();
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Nächster Track: $title'),
              backgroundColor: AppTheme.lightTheme.colorScheme.tertiary,
              duration: Duration(seconds: 2),
            ),
          );
        }
      } else {
        final String errorMessage =
            result['message'] ?? 'Kein nächster Track verfügbar';
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(errorMessage),
              backgroundColor: AppTheme.lightTheme.colorScheme.error,
              duration: Duration(seconds: 2),
            ),
          );
        }
      }
    } catch (error) {
      setState(() {
        _isLoading = false;
      });

      print('Exception in _skipToNext: $error');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Fehler beim Wechsel zum nächsten Track'),
            backgroundColor: AppTheme.lightTheme.colorScheme.error,
            duration: Duration(seconds: 2),
          ),
        );
      }
    }
  }

  /// Skip to previous track
  Future<void> _skipToPrevious() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final result = await SimpleAudioService.instance.skipToPrevious();

      setState(() {
        _isLoading = false;
      });

      if (result['error'] != true) {
        final String title = result['title'] ?? 'Unbekannter Track';
        final int index = result['index'] ?? 1;

        setState(() {
          _currentTrackTitle = title;
          _currentTrackIndex = index;
        });

        HapticFeedback.mediumImpact();
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Vorheriger Track: $title'),
              backgroundColor: AppTheme.lightTheme.colorScheme.tertiary,
              duration: Duration(seconds: 2),
            ),
          );
        }
      } else {
        final String errorMessage =
            result['message'] ?? 'Kein vorheriger Track verfügbar';
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(errorMessage),
              backgroundColor: AppTheme.lightTheme.colorScheme.error,
              duration: Duration(seconds: 2),
            ),
          );
        }
      }
    } catch (error) {
      setState(() {
        _isLoading = false;
      });

      print('Exception in _skipToPrevious: $error');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Fehler beim Wechsel zum vorherigen Track'),
            backgroundColor: AppTheme.lightTheme.colorScheme.error,
            duration: Duration(seconds: 2),
          ),
        );
      }
    }
  }

  @override
  void dispose() {
    _pulseAnimationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: isDark ? AppTheme.cardDark : AppTheme.cardLight,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: (isDark ? Colors.black : Colors.grey).withValues(alpha: 0.1),
            blurRadius: 10,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header with simplified info
          Row(
            children: [
              AnimatedBuilder(
                animation: _pulseAnimationController,
                builder: (context, child) {
                  return Transform.scale(
                    scale: _isPlaying
                        ? 1.0 + (_pulseAnimationController.value * 0.1)
                        : 1.0,
                    child: Icon(
                      Icons.music_note,
                      color: _isPlaying
                          ? AppTheme.lightTheme.colorScheme.primary
                          : (isDark
                              ? AppTheme.textSecondaryDark
                              : AppTheme.textSecondaryLight),
                      size: 24,
                    ),
                  );
                },
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Einfache Therapie Audio',
                      style:
                          AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                        color: isDark
                            ? AppTheme.textPrimaryDark
                            : AppTheme.textPrimaryLight,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    if (_totalTracks > 0)
                      Text(
                        '${_currentTrackIndex} von ${_totalTracks} Tracks',
                        style:
                            AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                          color: isDark
                              ? AppTheme.textSecondaryDark
                              : AppTheme.textSecondaryLight,
                        ),
                      ),
                  ],
                ),
              ),
              if (_isLoading)
                SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    valueColor: AlwaysStoppedAnimation(
                      AppTheme.lightTheme.colorScheme.primary,
                    ),
                  ),
                ),
            ],
          ),

          SizedBox(height: 2.h),

          // Simple explanation
          Container(
            padding: EdgeInsets.all(3.w),
            decoration: BoxDecoration(
              color: Colors.green.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: Colors.green.withValues(alpha: 0.3),
              ),
            ),
            child: Row(
              children: [
                Icon(
                  Icons.info_outline,
                  color: Colors.green,
                  size: 20,
                ),
                SizedBox(width: 2.w),
                Expanded(
                  child: Text(
                    'Laden Sie einfach Audio-Dateien in den "therapy-audio" Storage hoch - sie erscheinen automatisch hier!',
                    style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                      color: Colors.green[700],
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
          ),

          SizedBox(height: 3.h),

          // Track info or start button
          if (_currentTrackTitle != null) ...[
            // Current track display
            Container(
              padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 2.h),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.primary
                    .withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  Icon(
                    Icons.audiotrack,
                    color: AppTheme.lightTheme.colorScheme.primary,
                    size: 20,
                  ),
                  SizedBox(width: 2.w),
                  Expanded(
                    child: Text(
                      _currentTrackTitle!,
                      style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                        color: isDark
                            ? AppTheme.textPrimaryDark
                            : AppTheme.textPrimaryLight,
                        fontWeight: FontWeight.w500,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),

            SizedBox(height: 3.h),

            // Progress bar and time
            Column(
              children: [
                SliderTheme(
                  data: SliderTheme.of(context).copyWith(
                    trackHeight: 4,
                    thumbShape: RoundSliderThumbShape(enabledThumbRadius: 8),
                    overlayShape: RoundSliderOverlayShape(overlayRadius: 16),
                    activeTrackColor: AppTheme.lightTheme.colorScheme.primary,
                    inactiveTrackColor: AppTheme.lightTheme.colorScheme.primary
                        .withValues(alpha: 0.3),
                    thumbColor: AppTheme.lightTheme.colorScheme.primary,
                  ),
                  child: Slider(
                    value: _progressValue,
                    onChanged: _seekToPosition,
                    min: 0.0,
                    max: 1.0,
                  ),
                ),

                // Time display
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 2.w),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        _formatDuration(_currentPosition),
                        style:
                            AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                          color: isDark
                              ? AppTheme.textSecondaryDark
                              : AppTheme.textSecondaryLight,
                        ),
                      ),
                      Text(
                        _formatDuration(_currentDuration ?? Duration.zero),
                        style:
                            AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                          color: isDark
                              ? AppTheme.textSecondaryDark
                              : AppTheme.textSecondaryLight,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),

            SizedBox(height: 3.h),

            // Simple player controls
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Skip Previous button
                Container(
                  decoration: BoxDecoration(
                    color: AppTheme.lightTheme.colorScheme.secondary,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: AppTheme.lightTheme.colorScheme.secondary
                            .withValues(alpha: 0.3),
                        blurRadius: 6,
                        offset: Offset(0, 3),
                      ),
                    ],
                  ),
                  child: IconButton(
                    onPressed: _skipToPrevious,
                    icon: Icon(
                      Icons.skip_previous,
                      color: Colors.white,
                      size: 20,
                    ),
                    iconSize: 20,
                  ),
                ),

                SizedBox(width: 3.w),

                // Play/Pause button
                Container(
                  decoration: BoxDecoration(
                    color: AppTheme.lightTheme.colorScheme.primary,
                    borderRadius: BorderRadius.circular(25),
                    boxShadow: [
                      BoxShadow(
                        color: AppTheme.lightTheme.colorScheme.primary
                            .withValues(alpha: 0.3),
                        blurRadius: 8,
                        offset: Offset(0, 4),
                      ),
                    ],
                  ),
                  child: IconButton(
                    onPressed: _togglePlayPause,
                    icon: Icon(
                      _isPlaying ? Icons.pause : Icons.play_arrow,
                      color: Colors.white,
                      size: 28,
                    ),
                    iconSize: 28,
                  ),
                ),

                SizedBox(width: 3.w),

                // Skip Next button
                Container(
                  decoration: BoxDecoration(
                    color: AppTheme.lightTheme.colorScheme.secondary,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: AppTheme.lightTheme.colorScheme.secondary
                            .withValues(alpha: 0.3),
                        blurRadius: 6,
                        offset: Offset(0, 3),
                      ),
                    ],
                  ),
                  child: IconButton(
                    onPressed: _skipToNext,
                    icon: Icon(
                      Icons.skip_next,
                      color: Colors.white,
                      size: 20,
                    ),
                    iconSize: 20,
                  ),
                ),

                SizedBox(width: 4.w),

                // Stop button
                Container(
                  decoration: BoxDecoration(
                    color: AppTheme.lightTheme.colorScheme.error,
                    borderRadius: BorderRadius.circular(25),
                    boxShadow: [
                      BoxShadow(
                        color: AppTheme.lightTheme.colorScheme.error
                            .withValues(alpha: 0.3),
                        blurRadius: 8,
                        offset: Offset(0, 4),
                      ),
                    ],
                  ),
                  child: IconButton(
                    onPressed: _stopPlayback,
                    icon: Icon(
                      Icons.stop,
                      color: Colors.white,
                      size: 24,
                    ),
                    iconSize: 24,
                  ),
                ),
              ],
            ),
          ] else ...[
            // Start therapy button
            SizedBox(
              width: double.infinity,
              height: 6.h,
              child: ElevatedButton(
                onPressed: _isLoading ? null : _startTherapySession,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.lightTheme.colorScheme.primary,
                  foregroundColor: Colors.white,
                  elevation: 4,
                  shadowColor: AppTheme.lightTheme.colorScheme.primary
                      .withValues(alpha: 0.4),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  disabledBackgroundColor: AppTheme
                      .lightTheme.colorScheme.primary
                      .withValues(alpha: 0.5),
                ),
                child: _isLoading
                    ? Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              valueColor: AlwaysStoppedAnimation(Colors.white),
                            ),
                          ),
                          SizedBox(width: 2.w),
                          Text(
                            'Lädt Songs...',
                            style: AppTheme.lightTheme.textTheme.titleMedium
                                ?.copyWith(
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      )
                    : Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.play_arrow,
                            size: 24,
                            color: Colors.white,
                          ),
                          SizedBox(width: 2.w),
                          Text(
                            'Songs aus Storage laden',
                            style: AppTheme.lightTheme.textTheme.titleMedium
                                ?.copyWith(
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
              ),
            ),

            // Error message if any
            if (_errorMessage != null) ...[
              SizedBox(height: 2.h),
              Container(
                padding: EdgeInsets.all(3.w),
                decoration: BoxDecoration(
                  color: AppTheme.lightTheme.colorScheme.error
                      .withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: AppTheme.lightTheme.colorScheme.error
                        .withValues(alpha: 0.3),
                  ),
                ),
                child: Row(
                  children: [
                    Icon(
                      Icons.cloud_upload_outlined,
                      color: AppTheme.lightTheme.colorScheme.error,
                      size: 20,
                    ),
                    SizedBox(width: 2.w),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            _errorMessage!,
                            style: AppTheme.lightTheme.textTheme.bodySmall
                                ?.copyWith(
                              color: AppTheme.lightTheme.colorScheme.error,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          SizedBox(height: 0.5.h),
                          Text(
                            'Tipp: Laden Sie MP3, WAV oder M4A Dateien in den Supabase Storage hoch.',
                            style: AppTheme.lightTheme.textTheme.bodySmall
                                ?.copyWith(
                              color: AppTheme.lightTheme.colorScheme.error
                                  .withValues(alpha: 0.7),
                              fontSize: 11.sp,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ],
      ),
    );
  }
}
