import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../theme/app_theme.dart';
import '../../../services/audio_service.dart';

/// Music Player Widget for therapy sessions
/// Displays play/pause/stop controls with track title and progress
class MusicPlayerWidget extends StatefulWidget {
  final bool isTherapyActive;
  final VoidCallback? onTherapyStateChanged;

  const MusicPlayerWidget({
    super.key,
    this.isTherapyActive = false,
    this.onTherapyStateChanged,
  });

  @override
  State<MusicPlayerWidget> createState() => _MusicPlayerWidgetState();
}

class _MusicPlayerWidgetState extends State<MusicPlayerWidget>
    with TickerProviderStateMixin {
  late AnimationController _progressAnimationController;
  late AnimationController _pulseAnimationController;

  String? _currentTrackTitle;
  Duration _currentPosition = Duration.zero;
  Duration? _currentDuration;
  bool _isPlaying = false;
  bool _isLoading = false;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _setupAnimations();
    _setupAudioListeners();
  }

  void _setupAnimations() {
    _progressAnimationController = AnimationController(
      duration: Duration(milliseconds: 300),
      vsync: this,
    );

    _pulseAnimationController = AnimationController(
      duration: Duration(milliseconds: 1500),
      vsync: this,
    );
  }

  void _setupAudioListeners() {
    // Listen to track title changes
    AudioService.instance.trackTitleStream.listen((title) {
      if (mounted) {
        setState(() {
          _currentTrackTitle = title;
        });
      }
    });

    // Listen to position changes
    AudioService.instance.positionStream.listen((position) {
      if (mounted) {
        setState(() {
          _currentPosition = position;
        });
      }
    });

    // Listen to duration changes
    AudioService.instance.durationStream.listen((duration) {
      if (mounted) {
        setState(() {
          _currentDuration = duration;
        });
      }
    });

    // Listen to player state changes
    AudioService.instance.playerStateStream.listen((playerState) {
      if (mounted) {
        setState(() {
          _isPlaying = AudioService.instance.isPlaying;
          _isLoading = playerState == AudioPlayerState.loading ||
              playerState == AudioPlayerState.buffering;
        });

        // Update animations based on playing state
        if (_isPlaying) {
          _pulseAnimationController.repeat();
        } else {
          _pulseAnimationController.stop();
        }
      }
    });
  }

  /// Start therapy session - called when "Therapie starten" button is tapped
  Future<void> _startTherapySession() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      // Start therapy session using the new public method
      final result = await AudioService.instance.startTherapySession();

      if (result['error'] != true) {
        // Success - session started successfully
        final String title = result['title'];

        // Update local state
        setState(() {
          _currentTrackTitle = title;
          _isLoading = false;
        });

        // Notify parent widget about state change
        widget.onTherapyStateChanged?.call();

        // Show success feedback
        HapticFeedback.mediumImpact();
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Therapie-Sitzung gestartet: $title'),
              backgroundColor: AppTheme.lightTheme.colorScheme.tertiary,
              duration: Duration(seconds: 2),
            ),
          );
        }
      } else {
        // Error - show toast message with more detailed feedback
        setState(() {
          _isLoading = false;
          _errorMessage = result['message'];
        });

        if (mounted) {
          String errorMessage =
              result['message'] ?? 'Therapie-Inhalt nicht verfügbar';

          // Show user-friendly error message
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Fehler beim Laden des Therapie-Inhalts',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 4),
                  Text(errorMessage),
                  SizedBox(height: 8),
                  Text(
                    'Versuchen Sie es in wenigen Sekunden erneut.',
                    style: TextStyle(fontSize: 12, fontStyle: FontStyle.italic),
                  ),
                ],
              ),
              backgroundColor: AppTheme.lightTheme.colorScheme.error,
              duration: Duration(seconds: 4),
              action: SnackBarAction(
                label: 'Erneut versuchen',
                textColor: Colors.white,
                onPressed: () {
                  // Retry automatically after a short delay
                  Future.delayed(Duration(milliseconds: 500), () {
                    if (mounted) {
                      _startTherapySession();
                    }
                  });
                },
              ),
            ),
          );
        }
      }
    } catch (error) {
      setState(() {
        _isLoading = false;
        _errorMessage = 'Unerwarteter Fehler beim Laden';
      });

      print('Exception in _startTherapySession: $error');

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Technischer Fehler',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 4),
                Text('Die Therapie-Funktion ist momentan nicht verfügbar.'),
                SizedBox(height: 8),
                Text(
                  'Bitte kontaktieren Sie den Support oder versuchen Sie es später erneut.',
                  style: TextStyle(fontSize: 12, fontStyle: FontStyle.italic),
                ),
              ],
            ),
            backgroundColor: AppTheme.lightTheme.colorScheme.error,
            duration: Duration(seconds: 5),
          ),
        );
      }
    }
  }

  /// Toggle play/pause
  Future<void> _togglePlayPause() async {
    await AudioService.instance.togglePlayPause();
  }

  /// Stop playback
  Future<void> _stopPlayback() async {
    await AudioService.instance.stop();
    widget.onTherapyStateChanged?.call();

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Therapie-Sitzung beendet'),
          backgroundColor: AppTheme.lightTheme.colorScheme.secondary,
          duration: Duration(seconds: 2),
        ),
      );
    }
  }

  /// Seek to position
  Future<void> _seekToPosition(double value) async {
    if (_currentDuration != null) {
      final position = Duration(
        milliseconds: (value * _currentDuration!.inMilliseconds).round(),
      );
      await AudioService.instance.seek(position);
    }
  }

  /// Format duration for display
  String _formatDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    String minutes = twoDigits(duration.inMinutes.remainder(60));
    String seconds = twoDigits(duration.inSeconds.remainder(60));
    return '$minutes:$seconds';
  }

  /// Get progress value (0.0 to 1.0)
  double get _progressValue {
    if (_currentDuration == null || _currentDuration!.inMilliseconds == 0) {
      return 0.0;
    }
    return _currentPosition.inMilliseconds / _currentDuration!.inMilliseconds;
  }

  /// Skip to next track
  Future<void> _skipToNext() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final result = await AudioService.instance.skipToNextTrack();

      setState(() {
        _isLoading = false;
      });

      if (result['error'] != true) {
        final String title = result['title'];

        setState(() {
          _currentTrackTitle = title;
        });

        // Show success feedback
        HapticFeedback.mediumImpact();
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Nächster Track: $title'),
              backgroundColor: AppTheme.lightTheme.colorScheme.tertiary,
              duration: Duration(seconds: 2),
            ),
          );
        }
      } else {
        // Show error message
        final String errorMessage =
            result['message'] ?? 'Kein nächster Track verfügbar';
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(errorMessage),
              backgroundColor: AppTheme.lightTheme.colorScheme.error,
              duration: Duration(seconds: 2),
            ),
          );
        }
      }
    } catch (error) {
      setState(() {
        _isLoading = false;
      });

      print('Exception in _skipToNext: $error');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Fehler beim Wechsel zum nächsten Track'),
            backgroundColor: AppTheme.lightTheme.colorScheme.error,
            duration: Duration(seconds: 2),
          ),
        );
      }
    }
  }

  /// Skip to previous track
  Future<void> _skipToPrevious() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final result = await AudioService.instance.skipToPreviousTrack();

      setState(() {
        _isLoading = false;
      });

      if (result['error'] != true) {
        final String title = result['title'];

        setState(() {
          _currentTrackTitle = title;
        });

        // Show success feedback
        HapticFeedback.mediumImpact();
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Vorheriger Track: $title'),
              backgroundColor: AppTheme.lightTheme.colorScheme.tertiary,
              duration: Duration(seconds: 2),
            ),
          );
        }
      } else {
        // Show error message
        final String errorMessage =
            result['message'] ?? 'Kein vorheriger Track verfügbar';
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(errorMessage),
              backgroundColor: AppTheme.lightTheme.colorScheme.error,
              duration: Duration(seconds: 2),
            ),
          );
        }
      }
    } catch (error) {
      setState(() {
        _isLoading = false;
      });

      print('Exception in _skipToPrevious: $error');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Fehler beim Wechsel zum vorherigen Track'),
            backgroundColor: AppTheme.lightTheme.colorScheme.error,
            duration: Duration(seconds: 2),
          ),
        );
      }
    }
  }

  @override
  void dispose() {
    _progressAnimationController.dispose();
    _pulseAnimationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: isDark ? AppTheme.cardDark : AppTheme.cardLight,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: (isDark ? Colors.black : Colors.grey).withValues(alpha: 0.1),
            blurRadius: 10,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              AnimatedBuilder(
                animation: _pulseAnimationController,
                builder: (context, child) {
                  return Transform.scale(
                    scale: _isPlaying
                        ? 1.0 + (_pulseAnimationController.value * 0.1)
                        : 1.0,
                    child: Icon(
                      Icons.music_note,
                      color: _isPlaying
                          ? AppTheme.lightTheme.colorScheme.primary
                          : (isDark
                              ? AppTheme.textSecondaryDark
                              : AppTheme.textSecondaryLight),
                      size: 24,
                    ),
                  );
                },
              ),
              SizedBox(width: 3.w),
              Text(
                'Therapie Audio',
                style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                  color: isDark
                      ? AppTheme.textPrimaryDark
                      : AppTheme.textPrimaryLight,
                  fontWeight: FontWeight.w600,
                ),
              ),
              Spacer(),
              if (_isLoading)
                SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    valueColor: AlwaysStoppedAnimation(
                      AppTheme.lightTheme.colorScheme.primary,
                    ),
                  ),
                ),
            ],
          ),

          SizedBox(height: 3.h),

          // Track title or start button
          if (_currentTrackTitle != null) ...[
            // Current track info
            Container(
              padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 2.h),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.primary
                    .withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  Icon(
                    Icons.audiotrack,
                    color: AppTheme.lightTheme.colorScheme.primary,
                    size: 20,
                  ),
                  SizedBox(width: 2.w),
                  Expanded(
                    child: Text(
                      _currentTrackTitle!,
                      style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                        color: isDark
                            ? AppTheme.textPrimaryDark
                            : AppTheme.textPrimaryLight,
                        fontWeight: FontWeight.w500,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),

            SizedBox(height: 3.h),

            // Progress bar and time
            Column(
              children: [
                SliderTheme(
                  data: SliderTheme.of(context).copyWith(
                    trackHeight: 4,
                    thumbShape: RoundSliderThumbShape(enabledThumbRadius: 8),
                    overlayShape: RoundSliderOverlayShape(overlayRadius: 16),
                    activeTrackColor: AppTheme.lightTheme.colorScheme.primary,
                    inactiveTrackColor: AppTheme.lightTheme.colorScheme.primary
                        .withValues(alpha: 0.3),
                    thumbColor: AppTheme.lightTheme.colorScheme.primary,
                  ),
                  child: Slider(
                    value: _progressValue,
                    onChanged: _seekToPosition,
                    min: 0.0,
                    max: 1.0,
                  ),
                ),

                // Time display
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 2.w),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        _formatDuration(_currentPosition),
                        style:
                            AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                          color: isDark
                              ? AppTheme.textSecondaryDark
                              : AppTheme.textSecondaryLight,
                        ),
                      ),
                      Text(
                        _formatDuration(_currentDuration ?? Duration.zero),
                        style:
                            AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                          color: isDark
                              ? AppTheme.textSecondaryDark
                              : AppTheme.textSecondaryLight,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),

            SizedBox(height: 3.h),

            // Player controls
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Skip Previous button
                Container(
                  decoration: BoxDecoration(
                    color: AppTheme.lightTheme.colorScheme.secondary,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: AppTheme.lightTheme.colorScheme.secondary
                            .withValues(alpha: 0.3),
                        blurRadius: 6,
                        offset: Offset(0, 3),
                      ),
                    ],
                  ),
                  child: IconButton(
                    onPressed: _skipToPrevious,
                    icon: Icon(
                      Icons.skip_previous,
                      color: Colors.white,
                      size: 20,
                    ),
                    iconSize: 20,
                  ),
                ),

                SizedBox(width: 3.w),

                // Play/Pause button
                Container(
                  decoration: BoxDecoration(
                    color: AppTheme.lightTheme.colorScheme.primary,
                    borderRadius: BorderRadius.circular(25),
                    boxShadow: [
                      BoxShadow(
                        color: AppTheme.lightTheme.colorScheme.primary
                            .withValues(alpha: 0.3),
                        blurRadius: 8,
                        offset: Offset(0, 4),
                      ),
                    ],
                  ),
                  child: IconButton(
                    onPressed: _togglePlayPause,
                    icon: Icon(
                      _isPlaying ? Icons.pause : Icons.play_arrow,
                      color: Colors.white,
                      size: 28,
                    ),
                    iconSize: 28,
                  ),
                ),

                SizedBox(width: 3.w),

                // Skip Next button
                Container(
                  decoration: BoxDecoration(
                    color: AppTheme.lightTheme.colorScheme.secondary,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: AppTheme.lightTheme.colorScheme.secondary
                            .withValues(alpha: 0.3),
                        blurRadius: 6,
                        offset: Offset(0, 3),
                      ),
                    ],
                  ),
                  child: IconButton(
                    onPressed: _skipToNext,
                    icon: Icon(
                      Icons.skip_next,
                      color: Colors.white,
                      size: 20,
                    ),
                    iconSize: 20,
                  ),
                ),

                SizedBox(width: 4.w),

                // Stop button
                Container(
                  decoration: BoxDecoration(
                    color: AppTheme.lightTheme.colorScheme.error,
                    borderRadius: BorderRadius.circular(25),
                    boxShadow: [
                      BoxShadow(
                        color: AppTheme.lightTheme.colorScheme.error
                            .withValues(alpha: 0.3),
                        blurRadius: 8,
                        offset: Offset(0, 4),
                      ),
                    ],
                  ),
                  child: IconButton(
                    onPressed: _stopPlayback,
                    icon: Icon(
                      Icons.stop,
                      color: Colors.white,
                      size: 24,
                    ),
                    iconSize: 24,
                  ),
                ),
              ],
            ),
          ] else ...[
            // Start therapy button
            SizedBox(
              width: double.infinity,
              height: 6.h,
              child: ElevatedButton(
                onPressed: _isLoading ? null : _startTherapySession,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.lightTheme.colorScheme.primary,
                  foregroundColor: Colors.white,
                  elevation: 4,
                  shadowColor: AppTheme.lightTheme.colorScheme.primary
                      .withValues(alpha: 0.4),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  disabledBackgroundColor: AppTheme
                      .lightTheme.colorScheme.primary
                      .withValues(alpha: 0.5),
                ),
                child: _isLoading
                    ? Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              valueColor: AlwaysStoppedAnimation(Colors.white),
                            ),
                          ),
                          SizedBox(width: 2.w),
                          Text(
                            'Lädt...',
                            style: AppTheme.lightTheme.textTheme.titleMedium
                                ?.copyWith(
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      )
                    : Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.play_arrow,
                            size: 24,
                            color: Colors.white,
                          ),
                          SizedBox(width: 2.w),
                          Text(
                            'Therapie starten',
                            style: AppTheme.lightTheme.textTheme.titleMedium
                                ?.copyWith(
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
              ),
            ),

            // Error message if any
            if (_errorMessage != null) ...[
              SizedBox(height: 2.h),
              Container(
                padding: EdgeInsets.all(3.w),
                decoration: BoxDecoration(
                  color: AppTheme.lightTheme.colorScheme.error
                      .withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: AppTheme.lightTheme.colorScheme.error
                        .withValues(alpha: 0.3),
                  ),
                ),
                child: Row(
                  children: [
                    Icon(
                      Icons.info_outline,
                      color: AppTheme.lightTheme.colorScheme.error,
                      size: 20,
                    ),
                    SizedBox(width: 2.w),
                    Expanded(
                      child: Text(
                        _errorMessage!,
                        style:
                            AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                          color: AppTheme.lightTheme.colorScheme.error,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ],
      ),
    );
  }
}
