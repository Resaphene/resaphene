import 'package:flutter/material.dart';
import '../presentation/license_activation_screen/license_activation_screen.dart';
import '../presentation/main_dashboard/main_dashboard.dart';
import '../presentation/therapy_dashboard/therapy_dashboard.dart';
import '../presentation/user_profile_screen/user_profile_screen.dart';
import '../presentation/progress_tracking_screen/progress_tracking_screen.dart';
import '../presentation/login_screen/login_screen.dart';
import '../presentation/registration_screen/registration_screen.dart';
import '../presentation/premium_subscription_screen/premium_subscription_screen.dart';

class AppRoutes {
  // TODO: Add your routes here
  static const String initial = '/';
  static const String licenseActivation = '/license-activation-screen';
  static const String mainDashboard = '/main-dashboard';
  static const String therapyDashboard = '/therapy-dashboard';
  static const String userProfile = '/user-profile-screen';
  static const String progressTracking = '/progress-tracking-screen';
  static const String login = '/login-screen';
  static const String registrationScreen = '/registration-screen';
  static const String premiumSubscriptionScreen =
      '/premium-subscription-screen';

  static Map<String, WidgetBuilder> routes = {
    initial: (context) => const LoginScreen(),
    licenseActivation: (context) => const LicenseActivationScreen(),
    mainDashboard: (context) => const MainDashboard(),
    therapyDashboard: (context) => const TherapyDashboard(),
    userProfile: (context) => const UserProfileScreen(),
    progressTracking: (context) => const ProgressTrackingScreen(),
    login: (context) => const LoginScreen(),
    registrationScreen: (context) => const RegistrationScreen(),
    premiumSubscriptionScreen: (context) => const PremiumSubscriptionScreen(),
    // TODO: Add your other routes here
  };
}
